# mmBERT Scores v4.1：快速开始指南

本指南对应 `mmbert_scores_v4_1` 项目，面向以下任务：

- 输入：场景描述、痛点分析、解决方案。
- 输出：`novelty_score`、`demand_score`、`quality_score` 三个维度。
- 每个维度只能取 `0、2、4、6、8、10` 六档。
- 数据：约 20 万条大模型自动评分，以及几百条人类专家评分。
- 推荐策略：先用自动标签训练，再用专家标签校正；是否采用校正模型由专家验证集决定。

> **重要：** 本指南主要介绍专家对齐流程。项目还保留普通单数据源训练流程，见项目内 `GETTING_STARTED.md`。更完整的算法说明、数据隔离规则和实验注意事项见 `EXPERT_ALIGNMENT.md`。

---

## 1. 解压项目并准备环境

在服务器上解压代码包，进入项目根目录：

```bash
unzip mmbert_scores_v4_1.zip
cd mmbert_scores_v4_1
```

建议优先复用原来能够正常运行 PyTorch、Transformers 和 CUDA 的 Python 环境：

```bash
python -m pip install -r requirements.txt -r requirements-excel.txt
python -c "import torch; print('torch:', torch.__version__); print('cuda_available:', torch.cuda.is_available())"
```

正式 GPU 训练前应确认 `cuda_available: True`。CUDA 版 PyTorch 必须与服务器驱动兼容。代码包不包含 mmBERT 预训练权重、真实业务训练数据或训练完成的模型。

如果只做 Excel/CSV 转换、不训练模型，可以只安装：

```bash
python -m pip install -r requirements-excel.txt
```

## 2. 准备两份原始数据

建议将两份数据分别保存为：

```text
/data/llm_scores.xlsx       # 大模型自动评分，约 20 万条
/data/expert_scores.xlsx   # 专家评分，几百条
```

两份表格都需要包含模型输入字段：

- `scene_description`
- `pain_analysis`
- `solution`

以及三列评分：

- `novelty_score`
- `demand_score`
- `quality_score`

每个评分只能是 `0、2、4、6、8、10`。合法的 `[0, 0, 0]` 必须保留；缺失或非法评分不会自动填充或取整。

如果专家表使用独立列名 `expert_novelty_score`、`expert_demand_score`、`expert_quality_score`，第 3 步转换专家表时使用项目提供的 `configs/convert_expert_columns.yaml`。

### 2.1 推荐增加案例分组 ID

如果同一个项目/案例有多个版本、改写或近似记录，建议在两份表中增加相同含义的 `group_id` 列，并在对应转换配置中设置：

```yaml
conversion:
  group_column: group_id
```

这样数据准备时可以按组切分，避免同一案例的变体跨越训练集、验证集和测试集。若两份表确实共享同一个案例 ID，也可按 `EXPERT_ALIGNMENT.md` 的说明配置共享 ID。不要默认把两张表各自从 1 开始的 `row_id` 当作跨表 ID。

## 3. 转换 Excel/CSV 为标准 JSONL

先转换大模型自动评分数据：

```bash
python convert_data.py \
  --input /data/llm_scores.xlsx \
  --config configs/train.yaml \
  --output-dir converted/pseudo
```

再转换专家评分数据。若专家表评分列名与自动评分表一致：

```bash
python convert_data.py \
  --input /data/expert_scores.xlsx \
  --config configs/train.yaml \
  --output-dir converted/expert
```

若专家表使用 `expert_*` 三列评分名称：

```bash
python convert_data.py \
  --input /data/expert_scores.xlsx \
  --config configs/convert_expert_columns.yaml \
  --output-dir converted/expert
```

CSV 文件只需将输入扩展名替换为 `.csv`。转换完成后，先检查：

```text
converted/pseudo/report.json
converted/pseudo/rejected.jsonl
converted/expert/report.json
converted/expert/rejected.jsonl
```

确认接受数量、拒绝数量及拒绝原因符合预期。不要忽略被拒绝的数据，也不要把缺失评分手动填成 0。

## 4. 切分专家数据、排除自动标签重叠

运行：

```bash
python prepare_alignment_data.py \
  --expert-input converted/expert/labeled.jsonl \
  --pseudo-input converted/pseudo/labeled.jsonl \
  --config configs/train.yaml \
  --output-dir data/alignment
```

默认生成：

| 文件 | 默认用途 |
|---|---|
| `expert_train.jsonl` | 专家阶段训练，按独立组约 70% |
| `expert_validation.jsonl` | 专家阶段早停与模型选择，约 15% |
| `expert_test.jsonl` | 最终独立验收，约 15% |
| `pseudo_train.jsonl` | 第一阶段自动标签训练，约 95% |
| `pseudo_validation.jsonl` | 第一阶段自动标签验证，约 5% |
| `replay_train.jsonl` | 可选自动标签回放，最多抽取 5,000 条 |
| `report.json` | 数据数量、去重、剔除原因和标签分布 |
| `alignment_manifest.json` | 数据分片指纹、来源和评分模式记录 |

程序会先将专家案例及其关联组从自动标签池剔除，再执行训练/验证/测试切分。没有可靠 `group_id` 时，只能按规范化后的完整文本检查重叠，无法保证识别所有语义相近改写。请检查 `data/alignment/report.json` 和 manifest，确认数量、分组及剔除结果合理。

专家数据默认按独立组切分，70/15/15 是近似比例，不保证每个集合都包含全部六档分数。几百条数据可能导致某些档位在验证集或测试集中缺失，应查看报告中的各维度分数支持数。

## 5. 运行推荐方案：自动标签预训练 + 专家微调

默认配置位于 `configs/alignment.yaml`。先执行主方案：

```bash
CUDA_VISIBLE_DEVICES=0 python run_alignment.py \
  --config configs/alignment.yaml \
  --data-dir data/alignment \
  --method staged \
  --text-template-file converted/pseudo/text_template.json \
  --output-dir outputs/alignment-staged
```

如果 mmBERT-small 权重已经下载到服务器本地，增加模型路径：

```bash
  --model /models/mmBERT-small
```

完整命令示例：

```bash
CUDA_VISIBLE_DEVICES=0 python run_alignment.py \
  --config configs/alignment.yaml \
  --data-dir data/alignment \
  --method staged \
  --model /models/mmBERT-small \
  --text-template-file converted/pseudo/text_template.json \
  --output-dir outputs/alignment-staged
```

该流程包含两个阶段：

1. **自动标签阶段**：用 `pseudo_train.jsonl` 训练，用 `pseudo_validation.jsonl` 选择第一阶段模型。
2. **专家校正阶段**：加载第一阶段模型，默认冻结编码器、只训练三维分类头；使用专家训练集训练、专家验证集早停和选模。

专家阶段会创建新的优化器和学习率调度器，不是继续第一阶段的优化器状态。默认先冻结编码器是小样本下的保守设置，不保证一定优于解冻；后续可以复制 `configs/alignment.yaml`，将 `expert.training.freeze_backbone` 改为 `false`，另跑解冻对照。

## 6. 跑两个对照方案

### 6.1 只用专家数据训练

```bash
CUDA_VISIBLE_DEVICES=0 python run_alignment.py \
  --config configs/alignment.yaml \
  --data-dir data/alignment \
  --method expert_only \
  --text-template-file converted/pseudo/text_template.json \
  --output-dir outputs/alignment-expert-only
```

该方案从 mmBERT 底座开始，只用专家训练集训练，作为小样本基线。

### 6.2 两阶段训练 + 少量自动标签回放

先确保 `staged` 已完成，再复用它的第一阶段模型，不必重新训练 20 万条自动标签：

```bash
CUDA_VISIBLE_DEVICES=0 python run_alignment.py \
  --config configs/alignment.yaml \
  --data-dir data/alignment \
  --method staged_replay \
  --source-model outputs/alignment-staged/stage1/final \
  --text-template-file converted/pseudo/text_template.json \
  --output-dir outputs/alignment-replay
```

回放默认最多使用 5,000 条自动标签训练样本，权重为 `0.1`。它是待验证的对照参数，不代表已经证明最优。回放数据不包含自动验证集、专家验证集或专家测试集。

## 7. 比较三种方案并确定候选模型

三个方案都完成后运行：

```bash
python compare_alignment.py \
  --run-dirs \
    outputs/alignment-staged \
    outputs/alignment-expert-only \
    outputs/alignment-replay \
  --output-dir outputs/alignment-comparison
```

主要结果：

```text
outputs/alignment-comparison/comparison.md
outputs/alignment-comparison/comparison.json
outputs/alignment-comparison/summary.csv
outputs/alignment-comparison/selected_model.json
```

选择依据默认是专家验证集上的三维逐维精确 `accuracy`，再比较整条记录三维全部正确的 `row_exact_match`。如果指标打平，保留第一阶段基线。**不要根据专家测试集挑选方法或反复调参。**

读取实际选中的模型路径：

```bash
MODEL_DIR=$(python -c 'import json; print(json.load(open("outputs/alignment-comparison/selected_model.json"))["model_path"])')
echo "$MODEL_DIR"
```

`selected_model.json` 可能指向第一阶段模型，也可能指向专家微调模型。不要直接假设 `expert/final` 一定是最终胜出的模型；保留它引用的模型输出目录。

## 8. 用独立专家测试集做最终验收

只有在三种方法和超参数都确定后，才运行最终测试：

```bash
python evaluate.py \
  --model "$MODEL_DIR" \
  --data data/alignment/expert_test.jsonl \
  --output outputs/final_expert_test_metrics.json \
  --predictions-output outputs/final_expert_test_predictions.csv \
  --device cuda
```

重点查看：

- 三维全部一致率（整条记录完全匹配）。
- `novelty_score`、`demand_score`、`quality_score` 各自的精确一致率。
- 每个分数档位的支持数。
- 每维 6×6 混淆矩阵。
- MAE、QWK 等辅助指标。

与大模型标签的一致率不能替代与专家标签的一致率。若专家测试集样本很少，结果不确定性会比较大；不要仅凭几条样本的涨跌宣称对齐成功。

## 9. 批量预测并导出 CSV

```bash
python predict.py \
  --model "$MODEL_DIR" \
  --input /data/to_predict.csv \
  --output outputs/aligned_predictions.csv \
  --device cuda \
  --include-probabilities
```

输出保留原始字段，并追加三列预测：

- `pred_novelty_score`
- `pred_demand_score`
- `pred_quality_score`

最终预测只会是 `0、2、4、6、8、10`。`pred_expected_*` 若存在，是基于概率计算的连续期望值，仅供诊断，不是正式分类分数。

训练与推理必须使用相同的文本模板。若原始输入是 Excel，可先另存为 CSV；预测不需要标签列。

## 10. 运行软件自检

安装测试依赖并运行：

```bash
python -m pip install -r requirements-dev.txt
python -m pytest -q
python scripts/smoke_alignment.py --work-dir /tmp/mmbert-v41-alignment-smoke
```

自检会使用合成数据和本地随机小型模型验证程序链路，不会证明真实业务数据上的专家一致率，也不代表 GPU 吞吐性能。

---

## 常见注意事项

1. **不要把专家训练、验证、测试数据混在一起。** 测试集只能在方案确定后用于最终验收。
2. **不要把 20 万条自动标签与几百条专家标签简单拼接后等权训练。** 自动标签可能淹没专家监督。
3. **不要默认 `row_id` 是跨文件共享 ID。** 只有两张表确实使用同一 ID 体系时，才配置共享 ID 去重。
4. **不要把缺失标签补成 0。** 0 是合法分数，缺失是数据问题，两者必须区分。
5. **不要把旧七维、1–5 分模型直接当作本任务模型。** 维度和评分标尺必须一致。
6. **不要把阶段切换当成断点续训。** 专家校正是新的训练阶段；`--resume-from-checkpoint` 只用于继续同一训练 run。
7. **代码包不包含真实数据和模型权重。** 正式训练前请确认数据路径、底座模型路径、GPU 环境和磁盘空间。

## 进一步阅读

- `README.md`：项目整体说明。
- `GETTING_STARTED.md`：普通三维六分类数据转换、训练和推理流程。
- `EXPERT_ALIGNMENT.md`：专家对齐方法、数据隔离、三种方案和实验解释。
- `configs/alignment.yaml`：两阶段训练、专家微调、回放和模型选择配置。
- `VALIDATION.md`：软件测试和 CPU 端到端验证记录。
