#!/usr/bin/env python3
"""Stream CSV or JSONL through a saved scoring model and publish predictions.

CSV output preserves the source columns and appends pred_* columns. Raw source
fields use the converter's text template; standardized text inputs are accepted
directly. Teacher labels and scoring status never filter inference rows.
"""

from __future__ import annotations

import argparse
import csv
import json
import os
import sys
import tempfile
from pathlib import Path
from typing import TYPE_CHECKING, Any, Iterator, Mapping

from five_scores.excel import build_text_from_template, normalize_headers, resolve_settings
from five_scores.schema import DEFAULT_DIMENSION_NAMES, LEGACY_SCORE_VALUES, validate_score_values

if TYPE_CHECKING:
    from five_scores.inference import ScorePredictor


def iter_rows(path: Path, text_column: str) -> Iterator[tuple[int, dict[str, Any]]]:
    """Original JSONL text-only reader, also used by benchmark.py."""
    for row_number, row in iter_prediction_rows(path, input_format="jsonl"):
        text = row.get(text_column)
        if not isinstance(text, str) or not text.strip():
            raise ValueError(f"{path}, line {row_number}: {text_column!r} must be a nonempty string")
        yield row_number, row


def _read_csv_header(
    reader: Any, path: Path, header_row: int, *, template: Mapping[str, Any] | None = None,
    text_column: str = "text", text_mode: str = "auto",
) -> list[str]:
    header = None
    for _ in range(header_row):
        header = next(reader, None)
        if header is None:
            raise ValueError(f"{path}: missing CSV header record {header_row}")
    if not header or any(not name.strip() for name in header):
        raise ValueError(f"{path}: CSV needs nonempty column names")
    standardized = text_mode == "text" or (text_mode == "auto" and text_column in {name.strip() for name in header})
    if template is not None and template.get("header_overrides") and not standardized:
        normalized = normalize_headers(header, template, str(path), require_columns=False)
        positions = {int(position) for position in template["header_overrides"]}
        # Preserve other source names/values; only the explicitly configured
        # duplicate header is renamed (D: novelty_score -> solution).
        header = [normalized[index] if index + 1 in positions else name
                  for index, name in enumerate(header)]
    if len(set(name.strip() for name in header)) != len(header):
        raise ValueError(f"{path}: CSV needs unique column names after trimming whitespace")
    return header


def iter_prediction_rows(
    path: Path, *, input_format: str, encoding: str = "utf-8-sig", delimiter: str = ",", header_row: int = 1,
    template: Mapping[str, Any] | None = None, text_column: str = "text", text_mode: str = "auto",
) -> Iterator[tuple[int, dict[str, Any]]]:
    """Read every inference record without inspecting or filtering labels."""
    if input_format == "jsonl":
        with path.open("r", encoding="utf-8-sig") as stream:
            for line_number, line in enumerate(stream, 1):
                if not line.strip():
                    continue
                try:
                    row = json.loads(line)
                except json.JSONDecodeError as exc:
                    raise ValueError(f"{path}, line {line_number}: invalid JSON ({exc.msg})") from exc
                if not isinstance(row, dict):
                    raise ValueError(f"{path}, line {line_number}: expected a JSON object")
                yield line_number, row
        return
    if input_format != "csv":
        raise ValueError("input_format must be csv or jsonl")
    previous_limit = csv.field_size_limit()
    csv.field_size_limit(max(previous_limit, 100 * 1024 * 1024))
    try:
        with path.open("r", encoding=encoding, newline="") as stream:
            reader = csv.reader(stream, delimiter=delimiter, strict=True)
            header = _read_csv_header(reader, path, header_row, template=template,
                                      text_column=text_column, text_mode=text_mode)
            for row_number, cells in enumerate(reader, header_row + 1):
                if len(cells) != len(header):
                    raise ValueError(f"{path}: CSV record {row_number} has {len(cells)} cells; expected {len(header)}")
                yield row_number, dict(zip(header, cells, strict=True))
    finally:
        csv.field_size_limit(previous_limit)


def add_inference_arguments(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--model", type=Path, required=True, help="Saved trained checkpoint directory")
    parser.add_argument("--device", default="cuda", help="cuda, cuda:N, or cpu")
    parser.add_argument("--precision", choices=["auto", "bf16", "fp16", "fp32"], default="auto")
    parser.add_argument("--max-length", type=int, help="Override the training token limit, including special tokens")
    parser.add_argument("--attn-implementation", choices=["sdpa", "eager", "flash_attention_2"], default="sdpa")
    parser.add_argument("--compile", dest="compile_model", action="store_true", help="Optional torch.compile; allow warmup")
    parser.add_argument("--max-text-chars", type=int, default=100_000)
    parser.add_argument("--batch-size", type=int, default=32)
    parser.add_argument("--include-probabilities", action="store_true")
    parser.add_argument("--reject-truncation", action="store_true", help="Fail if any input exceeds max_length")


def predictor_from_args(args: argparse.Namespace) -> ScorePredictor:
    from five_scores.inference import ScorePredictor

    return ScorePredictor(
        args.model, device=args.device, precision=args.precision,
        max_length=args.max_length, attn_implementation=args.attn_implementation,
        compile_model=args.compile_model, max_text_chars=args.max_text_chars,
    )


def commit_output(temporary: Path, destination: Path, overwrite: bool) -> None:
    """Publish a complete file; a failed run leaves the previous output intact."""
    if overwrite:
        os.replace(temporary, destination)
    else:
        # Both paths are in the same directory/filesystem. link() creates the
        # final name atomically and refuses even a concurrent existing file.
        os.link(temporary, destination)
        temporary.unlink()


def _format_from_path(path: Path, explicit: str) -> str:
    if explicit != "auto":
        return explicit
    return "csv" if path.suffix.lower() == ".csv" else "jsonl"


def _template_from_file(path: Path) -> dict[str, Any]:
    value = json.loads(path.expanduser().read_text(encoding="utf-8-sig"))
    if not isinstance(value, dict):
        raise ValueError(f"{path}: text template must be a JSON object")
    return value


def prediction_input_settings(args: argparse.Namespace, predictor: Any) -> dict[str, Any]:
    """Resolve explicit input settings, saved training template, then defaults."""
    # Default field rendering is independent of the number/names of output
    # dimensions. A custom dimension may itself be named "solution"; that must
    # not make standardized text inference fail converter label-leakage checks.
    score_values = validate_score_values(getattr(predictor, "score_values", LEGACY_SCORE_VALUES))
    config: dict[str, Any] = {"model": {"dimension_names": list(DEFAULT_DIMENSION_NAMES), "score_values": score_values}}
    if args.config is not None:
        from five_scores.config import load_config

        config = load_config(args.config)
        if config["model"]["dimension_names"] != list(predictor.dimension_names):
            raise ValueError("Config model.dimension_names/order does not match the saved checkpoint")
        if config["model"]["score_values"] != score_values:
            raise ValueError("Config model.score_values/order does not match the saved checkpoint")
    conversion = dict(config.get("conversion", {}))
    for key, value in (("csv_encoding", args.csv_encoding), ("csv_delimiter", args.csv_delimiter), ("header_row", args.header_row)):
        if value is not None:
            conversion[key] = value
    settings = resolve_settings({**config, "conversion": conversion})
    model_config = getattr(predictor, "config", None)
    saved_template = getattr(model_config, "score_text_template", None)
    sidecar = args.model.expanduser() / "text_template.json"
    if args.text_template_file is not None:
        template = _template_from_file(args.text_template_file)
    elif args.config is not None and config.get("data", {}).get("text_template_file"):
        template = _template_from_file(Path(config["data"]["text_template_file"]))
    elif args.config is not None:
        template = settings.text_template()
    elif saved_template is not None:
        template = saved_template
    elif sidecar.is_file():
        template = _template_from_file(sidecar)
    else:
        template = settings.text_template()
        template["dimension_names"] = list(predictor.dimension_names)
        template["score_columns"] = list(predictor.dimension_names)
        template["score_values"] = score_values
        template["num_classes"] = len(score_values)
    if not isinstance(template, Mapping):
        raise ValueError("Saved text template must be a JSON object")
    declared_names = template.get("dimension_names")
    if declared_names is not None and declared_names != list(predictor.dimension_names):
        raise ValueError("Text template dimension_names/order does not match the saved checkpoint")
    if template.get("score_values", list(LEGACY_SCORE_VALUES)) != score_values:
        raise ValueError("Text template score_values/order does not match the saved checkpoint")
    if template.get("num_classes", len(LEGACY_SCORE_VALUES)) != len(score_values):
        raise ValueError("Text template num_classes does not match the saved checkpoint")
    # Validate the renderer before opening an output file; real field values
    # are validated again for each record without synthesizing missing text.
    sections = template.get("sections", [])
    probe = {item.get("column"): "template validation" for item in sections if isinstance(item, Mapping)} if isinstance(sections, list) else {}
    build_text_from_template(probe, template)
    return {
        "template": template,
        "text_column": args.text_column if args.text_column is not None else config.get("data", {}).get("text_column", "text"),
        "encoding": settings.csv_encoding, "delimiter": settings.csv_delimiter,
        "header_row": settings.header_row,
        "text_mode": args.text_mode,
    }


def prediction_text(row: Mapping[str, Any], *, text_column: str, template: Mapping[str, Any], mode: str = "auto") -> str:
    # Preserve original CSV headers in the output while matching the converter's
    # whitespace-trimmed header lookup for rendering.
    values = {key.strip(): value for key, value in row.items()}
    if mode == "text" or (mode == "auto" and text_column in values):
        text = values.get(text_column)
        if not isinstance(text, str) or not text.strip():
            raise ValueError(f"{text_column!r} must be a nonempty string")
        return text
    return build_text_from_template(values, template)


def _prediction_columns(names: list[str], include_probabilities: bool, include_text: bool) -> list[str]:
    columns = [f"pred_{name}" for name in names]
    columns += [f"pred_confidence_{name}" for name in names]
    columns += [f"pred_expected_{name}" for name in names]
    if include_probabilities:
        columns += [f"pred_probabilities_{name}" for name in names]
    columns += ["pred_input_tokens", "pred_used_tokens", "pred_truncated"]
    if include_text:
        columns.append("pred_text")
    if len(columns) != len(set(columns)):
        raise ValueError("Dimension names create colliding pred_* column names")
    return columns


def _flat_prediction(prediction: Mapping[str, Any], names: list[str], text: str, include_text: bool) -> dict[str, Any]:
    result: dict[str, Any] = {f"pred_{name}": prediction["scores"][name] for name in names}
    result.update({f"pred_confidence_{name}": prediction["max_probabilities"][name] for name in names})
    result.update({f"pred_expected_{name}": prediction["expected_scores"][name] for name in names})
    if "probabilities" in prediction:
        result.update({f"pred_probabilities_{name}": prediction["probabilities"][name] for name in names})
    for key in ("input_tokens", "used_tokens", "truncated"):
        result[f"pred_{key}"] = prediction[key]
    if include_text:
        result["pred_text"] = text
    return result


def _csv_value(value: Any) -> Any:
    if isinstance(value, (dict, list, tuple)) or isinstance(value, bool):
        return json.dumps(value, ensure_ascii=False, allow_nan=False)
    return value


def _source_columns(source: Path, input_format: str, input_settings: Mapping[str, Any]) -> list[str]:
    if input_format == "csv":
        with source.open("r", encoding=input_settings["encoding"], newline="") as handle:
            return _read_csv_header(
                csv.reader(handle, delimiter=input_settings["delimiter"], strict=True), source,
                input_settings["header_row"], template=input_settings["template"],
                text_column=input_settings["text_column"], text_mode=input_settings["text_mode"],
            )
    # JSONL permits varying keys. A bounded-memory discovery pass preserves all
    # keys in first-seen order when a user explicitly requests CSV output.
    names: dict[str, None] = {}
    for _, row in iter_prediction_rows(source, input_format="jsonl"):
        names.update(dict.fromkeys(row))
    return list(names)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    add_inference_arguments(parser)
    parser.add_argument("--input", type=Path, required=True, help="Raw-fields CSV/JSONL or standardized text CSV/JSONL")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--input-format", choices=["auto", "csv", "jsonl"], default="auto")
    parser.add_argument("--output-format", choices=["auto", "csv", "jsonl"], default="auto")
    parser.add_argument("--config", type=Path, help="Shared YAML: input text column, conversion text template, CSV encoding/delimiter/header")
    parser.add_argument("--text-template-file", type=Path, help="Explicit converter text_template.json; overrides config and saved template")
    parser.add_argument("--text-column", help="Standardized text column (default: config data.text_column, or text)")
    parser.add_argument("--text-mode", choices=["auto", "text", "fields"], default="auto", help="auto: use the text column when present, otherwise render raw fields")
    parser.add_argument("--csv-encoding", "--encoding", help="Input CSV encoding (default: config conversion.csv_encoding, or utf-8-sig)")
    parser.add_argument("--csv-delimiter", "--delimiter", help="CSV delimiter (default: config conversion.csv_delimiter, or comma)")
    parser.add_argument("--header-row", type=int, help="One-based CSV header record (default: config conversion.header_row, or 1)")
    parser.add_argument("--id-column", default="id", help="JSONL compatibility output: copy this field into output id")
    parser.add_argument("--include-text", action="store_true", help="Also emit rendered text (pred_text in CSV; text in legacy JSONL)")
    parser.add_argument("--overwrite", action="store_true")
    return parser


def main(argv: list[str] | None = None) -> None:
    parser = build_parser()
    args = parser.parse_args(argv)
    if args.batch_size < 1:
        parser.error("--batch-size must be positive")
    source, destination = args.input.expanduser().resolve(), args.output.expanduser().resolve()
    if source == destination:
        parser.error("--input and --output must use different paths")
    if destination.exists() and not args.overwrite:
        parser.error("Output exists; use another path or explicitly pass --overwrite")
    if not source.is_file():
        parser.error(f"Input file does not exist: {source}")
    input_format = _format_from_path(source, args.input_format)
    output_format = _format_from_path(destination, args.output_format)
    predictor = predictor_from_args(args)
    settings = prediction_input_settings(args, predictor)
    names = list(predictor.dimension_names)
    preserve_original = input_format == "csv" or output_format == "csv"
    output_columns: list[str] = []
    if preserve_original:
        source_columns = _source_columns(source, input_format, settings)
        added_columns = _prediction_columns(names, args.include_probabilities, args.include_text)
        collision = set(source_columns).intersection(added_columns)
        if collision:
            raise ValueError(f"Input already contains prediction columns {sorted(collision)}; no source column will be overwritten")
        output_columns = source_columns + added_columns
    destination.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary_name = tempfile.mkstemp(prefix=f".{destination.name}.", suffix=".tmp", dir=destination.parent)
    temporary = Path(temporary_name)
    count = 0
    truncated_count = 0
    try:
        encoding = "utf-8-sig" if output_format == "csv" else "utf-8"
        with os.fdopen(fd, "w", encoding=encoding, newline="") as output:
            writer = csv.DictWriter(output, fieldnames=output_columns, delimiter=settings["delimiter"], lineterminator="\n") if output_format == "csv" else None
            if writer is not None:
                writer.writeheader()
            pending: list[tuple[dict[str, Any], str]] = []

            def flush() -> None:
                nonlocal count, truncated_count
                predictions = predictor.predict(
                    [text for _, text in pending], batch_size=args.batch_size,
                    include_probabilities=args.include_probabilities, reject_truncation=args.reject_truncation,
                )
                if len(predictions) != len(pending):
                    raise ValueError("Predictor returned a different number of results than input records")
                for (row, text), prediction in zip(pending, predictions, strict=True):
                    if preserve_original:
                        result = {**row, **_flat_prediction(prediction, names, text, args.include_text)}
                    else:
                        result = {}
                        if args.id_column in row:
                            result["id"] = row[args.id_column]
                        if args.include_text:
                            result["text"] = text
                        result.update(prediction)
                    if writer is not None:
                        writer.writerow({key: _csv_value(value) for key, value in result.items()})
                    else:
                        output.write(json.dumps(result, ensure_ascii=False, allow_nan=False) + "\n")
                    count += 1
                    truncated_count += int(prediction["truncated"])
                pending.clear()

            for row_number, row in iter_prediction_rows(
                source, input_format=input_format, encoding=settings["encoding"], delimiter=settings["delimiter"], header_row=settings["header_row"],
                template=settings["template"], text_column=settings["text_column"], text_mode=args.text_mode,
            ):
                try:
                    text = prediction_text(row, text_column=settings["text_column"], template=settings["template"], mode=args.text_mode)
                except (TypeError, ValueError) as exc:
                    raise ValueError(f"{source}: record/line {row_number}: {exc}") from exc
                pending.append((row, text))
                if len(pending) == args.batch_size:
                    flush()
            if pending:
                flush()
            if not count:
                raise ValueError("Input contains no records")
            output.flush()
            os.fsync(output.fileno())
        commit_output(temporary, destination, args.overwrite)
    finally:
        temporary.unlink(missing_ok=True)
    print(f"Wrote {count} predictions to {destination}; truncated inputs: {truncated_count}", file=sys.stderr)


if __name__ == "__main__":
    main()

