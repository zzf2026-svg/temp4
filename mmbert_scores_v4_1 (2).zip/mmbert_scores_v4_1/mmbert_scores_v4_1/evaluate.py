#!/usr/bin/env python3
"""Evaluate exact teacher-score agreement and export aligned row diagnostics."""

from __future__ import annotations

import argparse
import base64
import csv
from datetime import date, datetime, time
from decimal import Decimal
from itertools import islice
import hashlib
import json
import os
from pathlib import Path
import tempfile
from typing import Any, TextIO

import numpy as np

from five_scores.data import iter_labeled_records
from five_scores.inference import ScorePredictor
from five_scores.metrics import detailed_score_report
from five_scores.schema import LEGACY_SCORE_VALUES, encode_scores, validate_score_values


def _file_sha256(path: Path) -> str:
    """Fingerprint local inputs without retaining their contents in memory."""
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _update_canonical_digest(digest, value: Any) -> None:
    """Hash one unambiguous, ordered record independently of inference batching."""
    digest.update(json.dumps(value, ensure_ascii=False, sort_keys=True,
                             separators=(",", ":"), allow_nan=False).encode("utf-8"))
    digest.update(b"\n")


def _json_default(value: Any) -> Any:
    """Keep common Parquet metadata representable without dropping its fields."""
    if isinstance(value, (datetime, date, time)):
        return value.isoformat()
    if isinstance(value, Decimal):
        return str(value)
    if isinstance(value, bytes):
        return {"__base64_bytes__": base64.b64encode(value).decode("ascii")}
    raise TypeError(f"Source metadata of type {type(value).__name__} cannot be represented in JSON")


def _json_text(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, allow_nan=False, default=_json_default)


def _same_path(first: Path, second: Path) -> bool:
    if first == second:
        return True
    return first.exists() and second.exists() and first.samefile(second)


def _validate_output_paths(
    source: Path, destination: Path, predictions_destination: Path | None, overwrite: bool,
) -> None:
    outputs = [destination] + ([predictions_destination] if predictions_destination else [])
    for output in outputs:
        if _same_path(source, output):
            raise ValueError("Evaluation outputs must differ from --data, including aliases/symlinks")
        if output.is_dir():
            raise ValueError(f"Output path is a directory: {output}")
        if output.exists() and not overwrite:
            raise FileExistsError(f"Output exists; use a new path or --overwrite: {output}")
    if predictions_destination is not None:
        if _same_path(destination, predictions_destination):
            raise ValueError("--output and --predictions-output must use distinct paths")
        if predictions_destination.suffix.lower() not in {".csv", ".jsonl", ".ndjson"}:
            raise ValueError("--predictions-output must end in .csv, .jsonl, or .ndjson")


def _temporary_file(destination: Path, *, newline: str | None = None) -> TextIO:
    destination.parent.mkdir(parents=True, exist_ok=True)
    return tempfile.NamedTemporaryFile(
        mode="w", encoding="utf-8", newline=newline,
        dir=destination.parent, prefix=f".{destination.name}.", suffix=".tmp", delete=False,
    )


def _commit_file(temporary: Path, destination: Path, overwrite: bool) -> None:
    """Publish a completed file; no-overwrite publication is race-safe on Linux."""
    if overwrite:
        os.replace(temporary, destination)
    else:
        # A check followed by replace could overwrite a file created between
        # those two calls. Linking the completed temp file fails atomically if
        # another process already created the destination.
        os.link(temporary, destination)
        temporary.unlink()


def _diagnostic_record(
    row_number: int,
    original: dict[str, Any],
    canonical: dict[str, Any],
    result: dict[str, Any],
    names: list[str],
    score_values: list[int] | None = None,
) -> dict[str, Any]:
    values = validate_score_values(LEGACY_SCORE_VALUES if score_values is None else score_values)
    gold = dict(zip(names, canonical["scores"]))
    predicted = {name: result["scores"][name] for name in names}
    exact = {name: gold[name] == predicted[name] for name in names}
    record = {
        "source_row": row_number,
        # A separate namespace prevents source columns such as scores,
        # probabilities, or source_row from being silently overwritten.
        "input": original,
        "dimension_names": names,
        "score_values": values,
        "gold_scores": gold,
        "predicted_scores": predicted,
        "probabilities": {name: result["probabilities"][name] for name in names},
        "exact_match": exact,
        "absolute_error": {name: abs(gold[name] - predicted[name]) for name in names},
        "row_exact_match": all(exact.values()),
        "input_tokens": result["input_tokens"],
        "used_tokens": result["used_tokens"],
        "truncated": result["truncated"],
    }
    if values == list(LEGACY_SCORE_VALUES):
        boundary = {
            name: (gold[name] <= 2 and predicted[name] >= 3) or (gold[name] >= 4 and predicted[name] <= 3)
            for name in names
        }

        def group(score: int) -> int:
            return 0 if score <= 2 else (1 if score == 3 else 2)

        group_mismatch = {name: group(gold[name]) != group(predicted[name]) for name in names}
        record.update({
            "boundary_violation": boundary, "group_mismatch": group_mismatch,
            "row_any_boundary_violation": any(boundary.values()),
            "row_any_group_mismatch": any(group_mismatch.values()),
        })
    return record


def _csv_cell(value: Any) -> Any:
    if isinstance(value, (dict, list)):
        return _json_text(value)
    return value


def _write_csv_diagnostics(
    jsonl_path: Path, destination: Path, names: list[str], input_columns: list[str],
    score_values: list[int] | None = None,
) -> Path:
    """Convert the completed spool, including a union of source columns.

    Streaming JSONL once during prediction and once here avoids storing full
    texts/probabilities in RAM. Later records may introduce new source columns.
    ``original_record`` additionally preserves nulls, nested values, and the
    distinction between missing fields and empty CSV cells.
    """
    fields = ["source_row"] + [f"input.{name}" for name in input_columns]
    mapping = {
        "gold": "gold_scores", "predicted": "predicted_scores", "probabilities": "probabilities",
        "exact": "exact_match", "absolute_error": "absolute_error",
    }
    summary_fields = ["row_exact_match", "input_tokens", "used_tokens", "truncated"]
    if score_values is None or list(score_values) == list(LEGACY_SCORE_VALUES):
        mapping.update({"boundary_violation": "boundary_violation", "group_mismatch": "group_mismatch"})
        summary_fields += ["row_any_boundary_violation", "row_any_group_mismatch"]
    fields += [f"{prefix}.{name}" for prefix in mapping for name in names]
    fields += summary_fields + ["original_record"]
    if len(fields) != len(set(fields)):
        raise ValueError("Source/dimension names would create duplicate diagnostic CSV columns")
    handle = _temporary_file(destination, newline="")
    temporary = Path(handle.name)
    try:
        with handle, jsonl_path.open("r", encoding="utf-8") as reader:
            writer = csv.DictWriter(handle, fieldnames=fields)
            writer.writeheader()
            for line in reader:
                record = json.loads(line)
                row = {"source_row": record["source_row"]}
                row.update({f"input.{key}": _csv_cell(value) for key, value in record["input"].items()})
                row.update({
                    f"{prefix}.{name}": _csv_cell(record[key][name])
                    for prefix, key in mapping.items() for name in names
                })
                row.update({key: record[key] for key in summary_fields})
                row["original_record"] = _json_text(record["input"])
                writer.writerow(row)
        return temporary
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise


def main(argv: list[str] | None = None) -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--model", required=True, help="Local trained checkpoint, normally outputs/.../final")
    parser.add_argument("--data", required=True, help="Labeled JSONL, CSV, JSON array or Parquet")
    parser.add_argument("--output", required=True, help="Write evaluation report as JSON")
    parser.add_argument(
        "--predictions-output", help="Optional .csv/.jsonl per-row gold/prediction/probability/error diagnostics",
    )
    parser.add_argument("--text-column", default="text")
    parser.add_argument("--scores-column", default="scores")
    parser.add_argument("--score-columns", nargs="+", metavar="COLUMN", help="One ordered column for each checkpoint dimension")
    parser.add_argument("--device", default="cuda")
    parser.add_argument("--precision", choices=["auto", "bf16", "fp16", "fp32"], default="auto")
    parser.add_argument("--batch-size", type=int, default=32)
    parser.add_argument("--max-length", type=int)
    parser.add_argument("--max-text-chars", type=int, default=100_000)
    parser.add_argument("--attn-implementation", default="sdpa", choices=["sdpa", "eager", "flash_attention_2"])
    parser.add_argument("--reject-truncation", action="store_true")
    filtering_options = parser.add_mutually_exclusive_group()
    filtering_options.add_argument("--include-all-three", dest="exclude_all_three", action="store_false",
                                   help="Keep every legal label combination (default for the six-class task)")
    filtering_options.add_argument("--exclude-all-three", dest="exclude_all_three", action="store_true",
                                   help="Legacy 1..5 task: filter rows whose teacher scores all equal 3")
    parser.set_defaults(exclude_all_three=None)
    parser.add_argument("--overwrite", action="store_true")
    options = parser.parse_args(argv)
    if options.batch_size < 1:
        parser.error("--batch-size must be positive")
    destination = Path(options.output).expanduser().resolve()
    source = Path(options.data).expanduser().resolve()
    predictions_destination = Path(options.predictions_output).expanduser().resolve() if options.predictions_output else None
    try:
        _validate_output_paths(source, destination, predictions_destination, options.overwrite)
    except (ValueError, FileExistsError) as exc:
        parser.error(str(exc))
    input_sha256 = _file_sha256(source)
    predictor = ScorePredictor(
        options.model, device=options.device, precision=options.precision,
        max_length=options.max_length, attn_implementation=options.attn_implementation,
        max_text_chars=options.max_text_chars,
    )
    names = predictor.dimension_names
    dimensions = predictor.num_dimensions
    score_values = validate_score_values(getattr(predictor, "score_values", LEGACY_SCORE_VALUES))
    exclude_all_three = options.exclude_all_three
    if exclude_all_three is None:
        exclude_all_three = bool(getattr(getattr(predictor, "config", None), "score_exclude_all_three",
                                        score_values == list(LEGACY_SCORE_VALUES)))
    model_config_path = predictor.model_dir / "config.json"
    model_config_sha256 = _file_sha256(model_config_path) if model_config_path.is_file() else None
    evaluated_digest = hashlib.sha256()
    digest_schema = {"schema_version": 1, "dimension_names": names}
    if score_values != list(LEGACY_SCORE_VALUES):
        digest_schema.update({"schema_version": 2, "score_values": score_values})
    _update_canonical_digest(evaluated_digest, digest_schema)
    filtering: dict[str, Any] = {}
    records = iter_labeled_records(
        source, text_column=options.text_column, scores_column=options.scores_column,
        score_columns=options.score_columns, num_dimensions=dimensions,
        dimension_names=names, score_values=score_values,
        exclude_all_three=exclude_all_three, filter_report=filtering,
    )
    # Only compact integer label/prediction arrays persist in RAM. Source text,
    # IDs, and probabilities are streamed together, after the shared all-3
    # failure filter, so exports cannot shift rows when failures are skipped.
    label_chunks: list[np.ndarray] = []
    prediction_chunks: list[np.ndarray] = []
    temporary_paths: set[Path] = set()
    spool: TextIO | None = None
    spool_path: Path | None = None
    original_columns: dict[str, None] = {}
    truncated, examples = 0, 0
    try:
        if predictions_destination is not None:
            spool = _temporary_file(predictions_destination)
            spool_path = Path(spool.name)
            temporary_paths.add(spool_path)
        while batch := list(islice(records, options.batch_size)):
            for _, _, canonical in batch:
                _update_canonical_digest(evaluated_digest, {
                    "text": canonical["text"], "scores": canonical["scores"],
                })
            texts = [canonical["text"] for _, _, canonical in batch]
            results = predictor.predict(
                texts, batch_size=options.batch_size,
                include_probabilities=predictions_destination is not None,
                reject_truncation=options.reject_truncation,
            )
            if len(results) != len(batch):
                raise RuntimeError("Predictor returned a different number of rows than its input batch")
            label_chunks.append(np.asarray([encode_scores(canonical["scores"], score_values)
                                            for _, _, canonical in batch], dtype=np.int64))
            prediction_chunks.append(np.asarray(
                [encode_scores([result["scores"][name] for name in names], score_values)
                 for result in results], dtype=np.int64,
            ))
            examples += len(batch)
            truncated += sum(int(result["truncated"]) for result in results)
            if spool is not None:
                for (row_number, original, canonical), result in zip(batch, results):
                    original_columns.update(dict.fromkeys(original))
                    spool.write(_json_text(_diagnostic_record(row_number, original, canonical, result, names, score_values)) + "\n")
        if spool is not None:
            spool.close()
            spool = None
        # iter_labeled_records raises on an empty/all-failure source. Retain a
        # defensive check if another iterator implementation is injected.
        if not label_chunks:
            raise ValueError("No valid labeled rows remain for evaluation")
        labels, predictions = np.concatenate(label_chunks), np.concatenate(prediction_chunks)
        del label_chunks, prediction_chunks
        if _file_sha256(source) != input_sha256:
            raise ValueError("Evaluation input changed during prediction; no report was published. Use an immutable data file.")
        if model_config_sha256 is not None and _file_sha256(model_config_path) != model_config_sha256:
            raise ValueError("Model configuration changed during evaluation; no report was published.")
        report = {
            "model": str(predictor.model_dir),
            "data": str(source),
            "input_sha256": input_sha256,
            "evaluated_data_sha256": evaluated_digest.hexdigest(),
            "evaluated_data_sha256_schema": (
                "v1: ordered canonical dimension names, then text and scores after failed-label filtering"
                if digest_schema["schema_version"] == 1 else
                "v2: ordered canonical dimension names and score_values, then text and scores after configured filtering"
            ),
            "model_config_sha256": model_config_sha256,
            "input_schema": {
                "text_column": options.text_column,
                "scores_column": options.scores_column,
                "score_columns": options.score_columns,
                "exclude_all_three": exclude_all_three,
            },
            "examples": examples,
            "dimensions": names,
            "num_dimensions": dimensions,
            "num_classes": predictor.num_classes,
            "score_values": score_values,
            "max_length": predictor.max_length,
            "device": str(predictor.device),
            "precision": predictor.precision,
            "batch_size": options.batch_size,
            "attn_implementation": options.attn_implementation,
            "truncated_examples": truncated,
            "truncation_rate": truncated / examples,
            "data_filtering": filtering,
            "predictions_output": str(predictions_destination) if predictions_destination is not None else None,
            **detailed_score_report(labels, predictions, names, score_values=score_values),
        }
        if exclude_all_three:
            report["metric_notes"].append("Configured legacy filtering excludes rows with all teacher scores equal to 3 before prediction/metrics/export.")
        else:
            report["metric_notes"].append("Every legal label combination is retained, including all-zero scores.")
        if predictions_destination is not None:
            report["prediction_export_notes"] = [
                "source_row is the original one-based record number (physical line number for JSONL), before failed-label filtering.",
                "JSONL keeps original fields/IDs under input; CSV uses input.<column> and includes original_record JSON to avoid overwriting source metadata.",
                f"probabilities are ordered by score_values={score_values} and describe the model output; they are not a correctness guarantee.",
                "Parquet temporal and decimal metadata are serialized as strings; binary metadata uses a __base64_bytes__ object.",
            ]
        with _temporary_file(destination) as handle:
            report_temporary = Path(handle.name)
            temporary_paths.add(report_temporary)
            json.dump(report, handle, ensure_ascii=False, indent=2, allow_nan=False)
            handle.write("\n")
        predictions_temporary = spool_path
        if predictions_destination is not None and predictions_destination.suffix.lower() == ".csv":
            assert spool_path is not None
            predictions_temporary = _write_csv_diagnostics(spool_path, predictions_destination, names,
                                                           list(original_columns), score_values)
            temporary_paths.add(predictions_temporary)
        # Check both destinations again before publishing either completed file.
        _validate_output_paths(source, destination, predictions_destination, options.overwrite)
        if predictions_destination is not None:
            assert predictions_temporary is not None
            _commit_file(predictions_temporary, predictions_destination, options.overwrite)
            temporary_paths.discard(predictions_temporary)
        _commit_file(report_temporary, destination, options.overwrite)
        temporary_paths.discard(report_temporary)
    finally:
        if spool is not None:
            spool.close()
        records.close()
        for path in temporary_paths:
            path.unlink(missing_ok=True)
    print(json.dumps(report, ensure_ascii=False, indent=2, allow_nan=False))


if __name__ == "__main__":
    main()
