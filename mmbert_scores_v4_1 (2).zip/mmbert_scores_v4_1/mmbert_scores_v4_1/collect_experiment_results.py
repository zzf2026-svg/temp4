#!/usr/bin/env python3
"""Collect experiment metrics and settings, excluding model weights and row texts."""

from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import tempfile
import zipfile


SUITE_FILES = (
    "manifest.json", "comparison.json", "comparison.md", "summary.csv",
    "per_dimension.csv", "per_score.csv", "selected_model.json",
)
RUN_FILES = (
    "resolved_config.json", "data_report.json", "class_weight_report.json",
    "environment.json", "train_results.json", "validation_results.json",
    "trainer_state.json", "validation_metrics.json", "completed.json",
    "final/training_summary.json",
)


def _inside_suite(value: str | Path, suite: Path) -> Path:
    path = Path(value).expanduser()
    path = (path if path.is_absolute() else suite / path).resolve()
    if not path.is_relative_to(suite):
        raise ValueError(f"Report path is outside the suite: {path}")
    return path


def collect_results(suite_dir: str | Path, destination: str | Path, *, overwrite: bool = False) -> dict:
    suite = Path(suite_dir).expanduser().resolve()
    output = Path(destination).expanduser().resolve()
    if not suite.is_dir():
        raise ValueError(f"Suite directory does not exist: {suite}")
    if output.suffix.lower() != ".zip":
        raise ValueError("Output must end in .zip")
    if output.exists() and not overwrite:
        raise FileExistsError(f"Output exists; use another path or --overwrite: {output}")
    manifest = json.loads((suite / "manifest.json").read_text(encoding="utf-8"))
    if manifest.get("schema_version") != 1 or not isinstance(manifest.get("experiments"), list):
        raise ValueError("Unrecognized experiment manifest")
    files = {_inside_suite(suite / name, suite) for name in SUITE_FILES}
    for experiment in manifest["experiments"]:
        run = _inside_suite(experiment["run_dir"], suite)
        files.add(_inside_suite(suite / "state" / f"{experiment['name']}.json", suite))
        files.add(_inside_suite(experiment["config_path"], suite))
        files.update(_inside_suite(run / name, suite) for name in RUN_FILES)
    files = {path for path in files if path.is_file()}
    if output in files:
        raise ValueError("Output cannot replace a source report")
    output.parent.mkdir(parents=True, exist_ok=True)
    descriptor, name = tempfile.mkstemp(prefix=".experiment-results-", suffix=".tmp", dir=output.parent)
    os.close(descriptor)
    temporary = Path(name)
    try:
        with zipfile.ZipFile(temporary, "w", compression=zipfile.ZIP_DEFLATED) as archive:
            for path in sorted(files):
                archive.write(path, arcname=(Path(suite.name) / path.relative_to(suite)).as_posix())
            archive.writestr(f"{suite.name}/BUNDLE_README.txt", (
                "本包仅收集白名单中的实验配置、统计报告和训练历史。\n"
                "不包含模型权重、训练/验证数据、逐条预测 CSV 或控制台日志。\n"
                "配置与报告中可能包含服务器路径。未完成实验也可以收集，缺失报告不会被伪造。\n"
            ))
        if overwrite:
            os.replace(temporary, output)
        else:
            os.link(temporary, output)
    finally:
        temporary.unlink(missing_ok=True)
    return {"output": str(output), "report_files": len(files), "size_bytes": output.stat().st_size}


def main(argv: list[str] | None = None) -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--suite-dir", required=True)
    parser.add_argument("--output", help="Default: <suite directory name>_results.zip alongside the suite")
    parser.add_argument("--overwrite", action="store_true")
    options = parser.parse_args(argv)
    suite = Path(options.suite_dir).expanduser().resolve()
    destination = options.output or suite.parent / f"{suite.name}_results.zip"
    try:
        result = collect_results(suite, destination, overwrite=options.overwrite)
    except (ValueError, FileExistsError) as error:
        parser.error(str(error))
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
