# mmBERT Scores v4.1：三维六档评分与专家对齐

此版本在 `mmbert_scores_v4.zip` 上修改，增加“20 万条自动标签 + 几百条专家标签”的训练流程。三个评分维度保持不变，每维只允许 **0、2、4、6、8、10**。保留 v4 的转换、普通训练、批量推理、CSV 导出、评估、服务和实验比较能力。

**本次专家对齐任务从 [EXPERT_ALIGNMENT.md](EXPERT_ALIGNMENT.md) 开始。** 推荐 `staged`：先用自动标签训练，再用专家标签开始新的微调；默认先冻结编码器、训练评分头，可用配置开启低学习率解冻对照。`expert_only` 与 `staged_replay` 提供另外两个受控候选。最终按专家验证集选择模型，若微调没有改善可回退到第一阶段模型。

新增入口：

- `prepare_alignment_data.py`：分开整理两类数据，排除所有专家案例及关联组在自动标签池中的重叠，生成专家训练/验证/测试和自动训练/验证/回放分片。
- `run_alignment.py`：运行三种策略；第二阶段使用新优化器和新的专家统计，不把跨阶段训练误当成断点恢复。
- `compare_alignment.py`：只比较同一数据切分上的专家验证结果，保存选中模型的真实路径。
- `configs/alignment.yaml`：两阶段、冻结/解冻、回放和选模参数。

原始数据格式与普通训练见 [GETTING_STARTED.md](GETTING_STARTED.md)。验证记录见 [VALIDATION.md](VALIDATION.md)，变更清单见 [CHANGELOG.md](CHANGELOG.md)。以下保留 v4 核心评分任务说明；专家对齐运行器使用自己的专家验证选择规则。

## 1. 新数据结构

v4 中附带的格式样例工作簿 Sheet1 有 7 列、1 条有效记录，另外两个工作表为空。它不是完整的自动标注集或专家集。

| 列位置 | 原表头 | 使用方式 |
| --- | --- | --- |
| A / 1 | row_id | 保留为样本 ID，不进入模型文本 |
| B / 2 | scene_description | 输入：场景描述 |
| C / 3 | pain_analysis | 输入：痛点分析 |
| D / 4 | novelty_score | 此列实际是解决方案文本，按配置重命名为 solution |
| E / 5 | novelty_score | 第 1 维标签 |
| F / 6 | demand_score | 第 2 维标签 |
| G / 7 | quality_score | 第 3 维标签 |

第 4 列和第 5 列存在重名；不能直接按同名列读取，否则可能覆盖文本或分数。默认配置明确修复第 4 个物理列：

```yaml
conversion:
  header_overrides:
    4:
      expected: novelty_score
      name: solution
```

原始 D 列名称为 `novelty_score` 或已更正为 `solution` 都可以。不同表头或修复后仍存在重名会报错。已经规范化且列顺序不同的文件，请设置 `header_overrides: {}` 并使用正确的 `solution` 表头。仅含标准 `text` 字段的预测 CSV 会自动跳过这项原始表头修复。

三个文本字段按固定顺序组成一次模型输入：

```text
【场景描述】...
【痛点分析】...
【解决方案】...
```

标签、row_id 和其他标识不进入输入文本。转换器会保存 `text_template.json`；训练时将该文件传入模型，预测便能使用完全一致的文本格式。

## 2. 标签映射与模型

```yaml
model:
  dimension_names: [novelty_score, demand_score, quality_score]
  num_dimensions: 3
  score_values: [0, 2, 4, 6, 8, 10]
  boundary_weight: 0.0
  ordinal_weight: 0.0
```

| 外部真实分数 | 0 | 2 | 4 | 6 | 8 | 10 |
| --- | --- | --- | --- | --- | --- | --- |
| 内部类别索引 | 0 | 1 | 2 | 3 | 4 | 5 |

每条文本只经过一次 mmBERT 编码，输出形状为 `[batch_size, 3, 6]`。三个维度各自做六分类，默认使用等权交叉熵；预测取各维概率最大的类别，并还原为实际分数。它不会输出 1、3、5、7、9，也不是 0–10 连续回归。

`expected_scores` 是概率加权的期望值，可能为小数，只供诊断；正式评分是 `scores` / CSV 的 `pred_<维度名>`。概率数组顺序始终是 `[0, 2, 4, 6, 8, 10]`。

分类头和中间模块的旧 Python 名称（如 `five_scores`、`ModernBertForFiveScores`）保留以兼容导入路径，实际维度数和类别数由配置决定。

## 3. 数据校验与切分

- 支持 `.xlsx` / `.xlsm` / `.csv` 原始表格，经 `convert_data.py` 转成标准 JSONL；`convert_xlsx.py` 继续作为兼容入口。
- `[0, 0, 0]` 是合法标签组合，保留。不会因 0 被视为空值而删除。
- 只接受指定离散分数。缺失、布尔值、非法整数、非整数数值、错误标签数量会被拒绝，不能取整到最近分数。
- 转换输出包括 `labeled.jsonl`、`rejected.jsonl`、`report.json`、`text_template.json`；部分拒绝不会静默消失，请查看报告。
- `prepare_data.py` 对标准化后的完整文本做去重。相同输入却标签冲突时停止并报告。
- 切分使用固定种子的哈希，按文本或显式 group ID 分组，避免完全相同文本跨集合。默认约 90% / 5% / 5%，不是分层抽样，也不保证各分数均出现。
- 如果要求的训练、验证或测试集合为空，切分会报错；应使用足够的独立真实样本。
- JSONL、文本模板和 checkpoint 会保留评分维度顺序、实际分值集合。它们不一致时直接报错。

附带的原始格式样例只有 1 条记录；其他流程样例为合成数据。正式训练需要提供完整自动标注集和真实专家集，不能据此宣称业务一致率。

## 4. 训练与模型选择

默认继续使用原项目的 `jhu-clsp/mmBERT-small`、全量微调和平均池化。可用 `--model /path/to/local/mmBERT-small` 指定已经下载的底座。

主要配置：

- `model.dimension_names`：三维名称及固定顺序。
- `model.score_values`：实际评分取值，默认六档。
- `data.max_train_samples: null`：使用所有训练数据；可改成正整数限制一次实验的数据量。
- `data.max_length: 512`：含特殊 token 的最大长度，检查训练报告的截断比例。
- `training.per_device_train_batch_size` 与 `gradient_accumulation_steps`：控制批量与显存占用。
- `training.metric_for_best_model: all_dimensions_accuracy`：按同一条记录的三个整数分数全部正确的比例选择最佳 checkpoint。
- `model.class_weight_mode: none`：默认不加类别权重。`sqrt_inverse` 可作为受控对照；权重只从训练集统计，不能预先保证它能提高精确一致率。

`boundary_weight` 在新标尺中必须为 0。旧版的低/中/高分组和 1↔2、4↔5 容错没有自动套用到新任务。`ordinal_weight` 保留为可选的有序 CDF 辅助损失，默认关闭；它按类别档位工作。

### 对照实验

```bash
python run_experiments.py \
  --base-config configs/train.yaml \
  --text-template-file converted/text_template.json \
  --output-dir outputs/ablation-v4
```

新标尺默认比较 `ce` 和 `weighted_ce`。运行器固定共享数据和主要训练设置，按验证集结果选模型。正式测试集保留到选型结束后再评估。更多参数见 `python run_experiments.py --help`。

旧七维、1–5 分配置集中在 `configs/legacy/`，当前任务使用 `configs/train.yaml`。禁止使用旧边界实验配置训练新数据。

## 5. 评估与预测输出

评估包含：

| 指标 | 定义 |
| --- | --- |
| accuracy / exact_accuracy | 所有样本、所有维度的精确评分一致率 |
| all_dimensions_accuracy / row_exact_match | 每条样本三个维度全部一致的比例 |
| 每维 accuracy、macro F1、QWK | 分维度诊断；QWK 在没有可定义分母时为 null |
| mae | 实际分数平均绝对误差；0 预测成 10 计 10 分 |
| mae_steps | 类别档位平均绝对误差；0 预测成 10 计 5 档 |
| two_or_more_steps_error_rate | 预测与标签相隔至少两档的比例 |
| 每分数 recall / precision | 0、2、4、6、8、10 各自的支持数及指标 |
| 混淆矩阵 | 6×6；行是真实分数，列是预测分数，顺序为 score_values |

宏平均 F1 包含六个类别，包括当前集合未出现的类别；报告会保留各类支持数，避免仅看汇总分数。

`predict.py` 的 CSV 输出保留输入列，追加 `pred_novelty_score`、`pred_demand_score`、`pred_quality_score`、每维置信度、期望分数和截断诊断。对原始重复表头的 D 列按显式配置重命名为 `solution`。已有教师分数不会被覆盖，也不会筛掉全 0 样本。

`evaluate.py --predictions-output ...csv` 输出逐条真实分数、预测、概率、精确匹配、绝对误差和原始输入字段，便于人工检查。

## 6. 模型兼容

新 checkpoint 使用 `score_model_version=4`，明确保存 `score_values`、维度顺序及每维类别数。

v4.1 沿用这一评分模型结构，新增训练来源记录。原 v4 同任务模型可用 `--model` 作为新训练起点；缺少输入指纹的旧 checkpoint 不用于已核验的断点恢复。专家对齐运行器复用现有模型时另有来源检查，见 `EXPERT_ALIGNMENT.md`。

旧 v1–v3 checkpoint 仍按旧的 1–5 分解释，不能当成新三维六分类模型。正式新任务从 mmBERT 原始底座重新训练；不能拿旧七维评分头直接续训。恢复同一新任务时，代码还会核对维度、标尺、损失、选择指标和训练类别权重。

## 7. 服务与离线自检

```bash
pip install -r requirements-serve.txt
MODEL_DIR=outputs/mmbert-scores-v4/final DEVICE=cuda python serve.py
```

服务提供 `/health` 与 `/predict`。请求的 `texts` 应使用训练时相同的文本模板。默认监听 `127.0.0.1:8000`，每个进程加载一个模型；输入与输出使用明确的评分映射。

不下载预训练模型的完整 CPU 功能自检：

```bash
pip install -r requirements-dev.txt
python scripts/smoke_test.py \
  --num-dimensions 3 --score-values 0 2 4 6 8 10 \
  --device cpu --work-dir /tmp/mmbert-v4-smoke
```

它创建随机小型 ModernBERT，完成训练、保存、重新加载、预测、评估、基准脚本和断点续训。结果只能证明代码链路，不能证明实际 mmBERT 的业务准确率或 GPU 速度。
