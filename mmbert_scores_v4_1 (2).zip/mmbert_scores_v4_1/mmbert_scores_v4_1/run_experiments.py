#!/usr/bin/env python3
"""Run reproducible discrete-score ablations sequentially on one GPU (or CPU)."""

from __future__ import annotations

import argparse
from copy import deepcopy
from datetime import datetime, timezone
import hashlib
from importlib import metadata
import json
import math
import os
from pathlib import Path
import platform
import re
import shutil
import signal
import subprocess
import sys
import tempfile
from typing import Any

import yaml

from five_scores.config import load_config, validate_config
from five_scores.schema import LEGACY_SCORE_VALUES


PROJECT_ROOT = Path(__file__).resolve().parent
EXPERIMENTS = {
    "baseline": {"boundary_weight": 0.2, "class_weight_mode": "none"},
    "weighted": {"boundary_weight": 0.2, "class_weight_mode": "sqrt_inverse"},
    "ce": {"boundary_weight": 0.0, "class_weight_mode": "none"},
    "weighted_ce": {"boundary_weight": 0.0, "class_weight_mode": "sqrt_inverse"},
}
EXACT_METRICS = {"accuracy", "exact_accuracy", "all_dimensions_accuracy", "row_exact_match"}
MODEL_SUFFIXES = {".json", ".safetensors", ".bin", ".txt", ".model", ".spm", ".tiktoken"}


def canonical_json(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False)


def value_sha256(value: Any) -> str:
    return hashlib.sha256(canonical_json(value).encode("utf-8")).hexdigest()


def file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def atomic_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    descriptor, temporary = tempfile.mkstemp(prefix=f".{path.name}.", suffix=".tmp", dir=path.parent)
    try:
        with os.fdopen(descriptor, "w", encoding="utf-8") as handle:
            json.dump(value, handle, ensure_ascii=False, indent=2, allow_nan=False)
            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
    finally:
        Path(temporary).unlink(missing_ok=True)


def absolute_file(value: str | Path, description: str) -> Path:
    path = Path(value).expanduser().resolve()
    if not path.is_file():
        raise ValueError(f"{description} is not a file: {path}")
    return path


def input_identity(path: str | Path) -> dict[str, Any]:
    path = absolute_file(path, "Input")
    return {"path": str(path), "sha256": file_sha256(path), "size_bytes": path.stat().st_size}


def inspect_local_backbone(source: str | Path) -> dict[str, Any]:
    directory = Path(source).expanduser().resolve()
    configuration = absolute_file(directory / "config.json", "Backbone config")
    config = json.loads(configuration.read_text(encoding="utf-8"))
    if config.get("model_type") != "modernbert":
        raise ValueError("The suite requires an original ModernBERT/mmBERT pretrained backbone")
    if "score_dim_names" in config or any("FiveScores" in name for name in config.get("architectures", [])):
        raise ValueError(
            "The model is a trained scoring checkpoint. Use the original pretrained backbone for every "
            "experiment, not a previous final/checkpoint directory."
        )
    files = {
        str(path.relative_to(directory)): file_sha256(path)
        for path in sorted(directory.rglob("*"))
        if path.is_file() and path.suffix.lower() in MODEL_SUFFIXES
        and not any(part.startswith(".") for part in path.relative_to(directory).parts)
    }
    if not any(name.endswith((".safetensors", ".bin")) for name in files):
        raise ValueError(f"Backbone has no local model weights: {directory}")
    return {"kind": "local", "path": str(directory), "files": files, "sha256": value_sha256(files)}


def resolve_backbone(
    name_or_path: str, revision: str, *, dry_run: bool, previous: dict | None = None,
) -> tuple[str, dict[str, Any]]:
    """Pin a Hub revision once; never perform network I/O for a dry run."""
    local = Path(name_or_path).expanduser()
    if local.exists():
        identity = inspect_local_backbone(local)
        return identity["path"], identity
    if local.is_absolute() or name_or_path.startswith(("./", "../", "~")):
        raise ValueError(f"Local backbone does not exist: {local}")
    request = {"repository": name_or_path, "requested_revision": revision}
    if dry_run:
        return name_or_path, {"kind": "hub_plan", **request, "note": "Commit and snapshot are pinned before training."}
    from huggingface_hub import HfApi, snapshot_download

    # Resume reuses its recorded commit even if a remote branch has moved.
    if previous and previous.get("kind") == "hub":
        if any(previous.get(key) != value for key, value in request.items()):
            raise ValueError("Hub source/revision differs from the saved suite")
        commit = previous["resolved_commit"]
    elif re.fullmatch(r"[0-9a-fA-F]{40}", str(revision)):
        commit = revision
    else:
        commit = HfApi().model_info(name_or_path, revision=revision).sha
        if not commit:
            raise RuntimeError("Could not resolve the pretrained repository to an immutable commit")
    snapshot = snapshot_download(
        repo_id=name_or_path, revision=commit,
        allow_patterns=["*.json", "*.safetensors", "*.bin", "*.txt", "*.model", "*.spm", "*.tiktoken"],
    )
    local_identity = inspect_local_backbone(snapshot)
    return local_identity["path"], {**local_identity, "kind": "hub", **request, "resolved_commit": commit}


def code_identity() -> dict[str, str]:
    files = list(PROJECT_ROOT.glob("*.py")) + list((PROJECT_ROOT / "five_scores").glob("*.py"))
    files += list(PROJECT_ROOT.glob("requirements*.txt"))
    return {str(path.relative_to(PROJECT_ROOT)): file_sha256(path) for path in sorted(files)}


def package_versions() -> dict[str, str | None]:
    versions = {}
    for package in ("torch", "transformers", "datasets", "accelerate", "numpy", "huggingface_hub"):
        try:
            versions[package] = metadata.version(package)
        except metadata.PackageNotFoundError:
            versions[package] = None
    return versions


def prepare_base_config(options: argparse.Namespace) -> dict[str, Any]:
    config = load_config(options.base_config)
    if options.epochs is not None and options.max_steps is None:
        # An explicit epoch budget must not silently lose to a saved max_steps.
        config["training"]["max_steps"] = -1
    if options.epochs is not None and options.max_steps is not None and options.max_steps > 0:
        raise ValueError("Choose --epochs or a positive --max-steps, not both")
    for section, key, value in [
        ("model", "name_or_path", options.model),
        ("data", "train_file", options.train_file),
        ("data", "validation_file", options.validation_file),
        ("data", "text_template_file", options.text_template_file),
        ("data", "max_train_samples", options.max_train_samples),
        ("data", "max_eval_samples", options.max_eval_samples),
        ("training", "seed", options.seed),
        ("training", "num_train_epochs", options.epochs),
        ("training", "max_steps", options.max_steps),
        ("training", "precision", options.precision),
    ]:
        if value is not None:
            config[section][key] = value
    if options.cpu:
        config["training"]["use_cpu"] = True
        config["training"]["precision"] = "fp32"
    if config["data"]["max_eval_samples"] is not None:
        raise ValueError(
            "The suite requires data.max_eval_samples=null so checkpoint selection and exported metrics "
            "use the identical full validation file. For a smaller run, create one fixed validation subset "
            "file beforehand and pass it to --validation-file."
        )
    if config["training"]["resume_from_checkpoint"]:
        raise ValueError("Remove training.resume_from_checkpoint from the base config; suite recovery uses --resume")
    metric = config["training"]["metric_for_best_model"].removeprefix("eval_")
    if metric not in EXACT_METRICS:
        raise ValueError(f"Use an exact-agreement selection metric in the base config: {sorted(EXACT_METRICS)}")
    if config["training"]["greater_is_better"] is False:
        raise ValueError("Exact-agreement metrics must be maximized (greater_is_better=true)")
    config["training"].update({
        "metric_for_best_model": metric, "greater_is_better": True,
        "early_stopping_patience": 0, "resume_from_checkpoint": None,
    })
    config["model"].update({"ordinal_weight": 0.0, "class_weights": None, "class_weight_mode": "none"})
    # Keep the configured label policy. A valid zero is never a failed label.
    config["conversion"]["exclude_all_three"] = config["data"]["exclude_all_three"]
    for key in ("train_file", "validation_file"):
        config["data"][key] = str(absolute_file(config["data"][key], key))
    if Path(config["data"]["train_file"]).samefile(config["data"]["validation_file"]):
        raise ValueError("Training and validation must be distinct files")
    if config["data"]["text_template_file"]:
        config["data"]["text_template_file"] = str(absolute_file(config["data"]["text_template_file"], "Text template"))
    epochs = config["training"]["num_train_epochs"]
    steps = config["training"]["max_steps"]
    if isinstance(epochs, bool) or not isinstance(epochs, (int, float)) or not math.isfinite(epochs) or epochs <= 0:
        raise ValueError("num_train_epochs must be finite and positive")
    if isinstance(steps, bool) or not isinstance(steps, int) or steps == 0 or steps < -1:
        raise ValueError("max_steps must be -1 (use epochs) or a positive integer")
    return validate_config(config)


def build_plan(options: argparse.Namespace, *, previous: dict | None = None) -> tuple[dict, dict[str, dict]]:
    """Build immutable experiment definitions without writing output files."""
    config = prepare_base_config(options)
    selected_experiments = options.experiments
    if selected_experiments is None:
        selected_experiments = (
            ["baseline", "weighted", "ce"]
            if tuple(config["model"].get("score_values", LEGACY_SCORE_VALUES)) == LEGACY_SCORE_VALUES
            else ["ce", "weighted_ce"]
        )
    if len(set(selected_experiments)) != len(selected_experiments):
        raise ValueError("Each experiment may appear only once")
    if tuple(config["model"].get("score_values", LEGACY_SCORE_VALUES)) != LEGACY_SCORE_VALUES:
        unsupported = [name for name in selected_experiments if EXPERIMENTS[name]["boundary_weight"]]
        if unsupported:
            raise ValueError("Boundary-loss experiments are defined only for legacy scores [1, 2, 3, 4, 5]; "
                             f"use ce/weighted_ce for this score scale (requested: {unsupported})")
    output = Path(options.output_dir).expanduser().resolve()
    for key in ("train_file", "validation_file", "text_template_file"):
        value = config["data"].get(key)
        if value and Path(value).is_relative_to(output):
            raise ValueError("Suite output must not contain an input dataset or template")
    source, model_identity = resolve_backbone(
        config["model"]["name_or_path"], config["model"]["revision"], dry_run=options.dry_run,
        previous=previous.get("model_identity") if previous else None,
    )
    if model_identity.get("path"):
        backbone_path = Path(model_identity["path"])
        if backbone_path.is_relative_to(output) or output.is_relative_to(backbone_path):
            raise ValueError("Suite output and pretrained backbone must not contain one another")
    config["model"]["name_or_path"] = source
    if model_identity.get("resolved_commit"):
        config["model"]["revision"] = model_identity["resolved_commit"]
    # The suite root, not the unused single-run path from a base YAML, identifies its output.
    config["training"]["output_dir"] = str(output)
    data = {
        "train": input_identity(config["data"]["train_file"]),
        "validation": input_identity(config["data"]["validation_file"]),
    }
    if config["data"]["text_template_file"]:
        data["text_template"] = input_identity(config["data"]["text_template_file"])
    generated, experiments = {}, []
    for name in selected_experiments:
        candidate = deepcopy(config)
        candidate["model"].update(EXPERIMENTS[name])
        run_dir = output / name
        config_path = output / "configs" / f"{name}.yaml"
        candidate["training"]["output_dir"] = str(run_dir)
        validate_config(candidate)
        generated[name] = candidate
        experiments.append({"name": name, **EXPERIMENTS[name], "config_path": str(config_path), "run_dir": str(run_dir)})
    manifest = {
        "schema_version": 1,
        "base_config": config,
        "data": data,
        "model_identity": model_identity,
        "code_sha256": code_identity(),
        "selection": {"metric": config["training"]["metric_for_best_model"], "greater_is_better": True},
        "experiments": experiments,
        "uniform_overrides": {
            "early_stopping_patience": 0, "ordinal_weight": 0.0,
            "exclude_all_three": config["data"]["exclude_all_three"],
            "note": "Fixed maximum training budget; each run still selects its best validation checkpoint.",
        },
        "experiment_note": "baseline is a new controlled baseline, not an assertion that a historical run is reproduced.",
        "execution": {
            "world_size": 1,
            "python": str(Path(sys.executable).resolve()),
            "python_version": platform.python_version(),
            "package_versions": package_versions(),
            "CUDA_VISIBLE_DEVICES": os.environ.get("CUDA_VISIBLE_DEVICES"),
            "validation_report": "validation_metrics.json",
            "validation_predictions": "validation_predictions.csv",
        },
    }
    manifest["suite_signature"] = value_sha256(manifest)
    return manifest, generated


def initialize_suite(output: Path, manifest: dict, configs: dict[str, dict], *, resume: bool) -> None:
    existing_path = output / "manifest.json"
    if existing_path.is_file():
        if not resume:
            raise FileExistsError(f"Suite already exists. Use the same command with --resume or a new --output-dir: {output}")
        previous = json.loads(existing_path.read_text(encoding="utf-8"))
        if previous != manifest:
            raise ValueError(
                "Suite fingerprint changed (data, model, code, settings, device visibility, or experiment list). "
                "Restore its original command/files or use a new --output-dir; results will not be mixed."
            )
        for experiment in manifest["experiments"]:
            path = Path(experiment["config_path"])
            if not path.is_file() or load_config(path) != configs[experiment["name"]]:
                raise ValueError(f"Generated experiment config changed or disappeared: {path}")
        return
    if resume:
        raise ValueError(f"Cannot resume: no manifest.json found in {output}")
    if output.exists() and (not output.is_dir() or any(output.iterdir())):
        raise FileExistsError(f"Output must be a new or empty directory: {output}")
    output.mkdir(parents=True, exist_ok=True)
    (output / "configs").mkdir()
    for experiment in manifest["experiments"]:
        Path(experiment["config_path"]).write_text(
            yaml.safe_dump(configs[experiment["name"]], allow_unicode=True, sort_keys=False), encoding="utf-8",
        )
    atomic_json(existing_path, manifest)


def assert_inputs_unchanged(manifest: dict) -> None:
    for identity in manifest["data"].values():
        if input_identity(identity["path"]) != identity:
            raise ValueError(f"Input changed since the suite was planned: {identity['path']}")
    identity = manifest["model_identity"]
    current = inspect_local_backbone(identity["path"])
    if current["files"] != identity["files"]:
        raise ValueError("Pretrained backbone changed since the suite was planned")
    if code_identity() != manifest["code_sha256"]:
        raise ValueError("Training/evaluation code changed since the suite was planned")


def complete_training(run_dir: Path) -> bool:
    final = run_dir / "final"
    return (
        (final / "training_summary.json").is_file() and (final / "config.json").is_file()
        and any((final / name).is_file() for name in ("model.safetensors", "model.safetensors.index.json", "pytorch_model.bin", "pytorch_model.bin.index.json"))
    )


def completion_artifacts(run_dir: Path) -> list[str]:
    """Bind the recorded metrics to the exact exported checkpoint bytes."""
    paths = [
        "validation_metrics.json", "validation_predictions.csv",
        "final/config.json", "final/training_summary.json",
    ]
    paths += [str(path.relative_to(run_dir)) for path in sorted((run_dir / "final").glob("*"))
              if path.is_file() and (path.suffix in {".safetensors", ".bin"} or path.name.endswith(".index.json"))]
    return paths


def latest_complete_checkpoint(run_dir: Path) -> Path | None:
    candidates = []
    for path in run_dir.glob("checkpoint-*"):
        suffix = path.name.removeprefix("checkpoint-")
        if not suffix.isdigit() or not path.is_dir():
            continue
        if not all((path / name).is_file() for name in ("trainer_state.json", "optimizer.pt", "scheduler.pt", "config.json", "rng_state.pth")):
            continue
        if any((path / name).is_file() for name in ("model.safetensors", "model.safetensors.index.json", "pytorch_model.bin", "pytorch_model.bin.index.json")):
            candidates.append((int(suffix), path))
    return max(candidates, default=(0, None), key=lambda item: item[0])[1]


def train_command(experiment: dict, checkpoint: Path | None = None) -> list[str]:
    command = [sys.executable, str(PROJECT_ROOT / "train.py"), "--config", experiment["config_path"]]
    if checkpoint:
        command += ["--resume-from-checkpoint", str(checkpoint)]
    return command


def evaluation_command(experiment: dict, config: dict, *, overwrite: bool = False) -> list[str]:
    run_dir = Path(experiment["run_dir"])
    data, training, model = (config[key] for key in ("data", "training", "model"))
    command = [
        sys.executable, str(PROJECT_ROOT / "evaluate.py"),
        "--model", str(run_dir / "final"), "--data", data["validation_file"],
        "--output", str(run_dir / "validation_metrics.json"),
        "--predictions-output", str(run_dir / "validation_predictions.csv"),
        "--device", "cpu" if training["use_cpu"] else "cuda",
        "--precision", training["precision"],
        "--batch-size", str(training["per_device_eval_batch_size"]),
        "--max-length", str(data["max_length"]),
        "--text-column", data["text_column"], "--scores-column", data["scores_column"],
        "--attn-implementation", model["attn_implementation"],
    ]
    if data["score_columns"]:
        command += ["--score-columns", *data["score_columns"]]
    command += ["--exclude-all-three" if data["exclude_all_three"] else "--include-all-three"]
    if overwrite:
        command += ["--overwrite"]
    return command


def run_logged(command: list[str], path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as logfile:
        logfile.write(f"\n[{datetime.now(timezone.utc).isoformat()}] {json.dumps(command)}\n")
        logfile.flush()
        process = subprocess.Popen(
            command, cwd=PROJECT_ROOT, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
            text=True, encoding="utf-8", errors="replace", bufsize=1,
            start_new_session=os.name == "posix",
        )
        try:
            assert process.stdout is not None
            for line in process.stdout:
                print(line, end="", flush=True)
                logfile.write(line)
                logfile.flush()
            returncode = process.wait()
        except BaseException:
            if process.poll() is None:
                if os.name == "posix":
                    os.killpg(process.pid, signal.SIGINT)
                else:
                    process.terminate()
                try:
                    process.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    if os.name == "posix":
                        os.killpg(process.pid, signal.SIGKILL)
                    else:
                        process.kill()
                    process.wait()
            raise
        finally:
            if process.stdout is not None:
                process.stdout.close()
        if returncode:
            raise RuntimeError(f"Command exited with status {returncode}; see {path}")


def execute_suite(manifest: dict, configs: dict[str, dict], *, resume: bool) -> None:
    output = Path(manifest["base_config"]["training"]["output_dir"])
    for experiment in manifest["experiments"]:
        name, run_dir = experiment["name"], Path(experiment["run_dir"])
        completion = output / "state" / f"{name}.json"
        assert_inputs_unchanged(manifest)
        if completion.is_file():
            saved = json.loads(completion.read_text(encoding="utf-8"))
            if saved.get("suite_signature") != manifest["suite_signature"] or not complete_training(run_dir):
                raise ValueError(f"Completed run metadata/model is inconsistent: {name}")
            for filename, fingerprint in saved["outputs"].items():
                path = run_dir / filename
                if not path.is_file() or file_sha256(path) != fingerprint:
                    raise ValueError(f"Completed run output changed: {path}")
            print(f"[{name}] Already complete; keeping its trained model and evaluation.", flush=True)
            continue
        config = configs[name]
        if not complete_training(run_dir):
            checkpoint = latest_complete_checkpoint(run_dir) if resume and run_dir.exists() else None
            if run_dir.exists() and any(run_dir.iterdir()) and checkpoint is None:
                if not resume:
                    raise FileExistsError(f"Experiment output is not empty: {run_dir}")
                # A crash before the first checkpoint cannot be resumed exactly.
                # Preserve its files, then repeat this experiment from the same seed/backbone.
                archive_root = output / "interrupted"
                archive_root.mkdir(exist_ok=True)
                archive = archive_root / f"{name}-{datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')}"
                shutil.move(str(run_dir), str(archive))
                print(f"[{name}] No complete checkpoint; archived partial files to {archive} and restarting.", flush=True)
            print(f"[{name}] Training from {'checkpoint ' + str(checkpoint) if checkpoint else 'the shared pretrained backbone'}.", flush=True)
            run_logged(train_command(experiment, checkpoint), output / "logs" / f"{name}.train.log")
            if not complete_training(run_dir):
                raise RuntimeError(f"Training exited without a complete final checkpoint: {run_dir}")
        assert_inputs_unchanged(manifest)
        print(f"[{name}] Evaluating the shared validation file.", flush=True)
        run_logged(evaluation_command(experiment, config, overwrite=resume), output / "logs" / f"{name}.evaluate.log")
        assert_inputs_unchanged(manifest)
        atomic_json(completion, {
            "suite_signature": manifest["suite_signature"], "status": "complete",
            "outputs": {filename: file_sha256(run_dir / filename) for filename in completion_artifacts(run_dir)},
        })
        run_logged(
            [sys.executable, str(PROJECT_ROOT / "compare_experiments.py"), "--suite-dir", str(output), "--allow-incomplete"],
            output / "logs" / "comparison.log",
        )
    run_logged(
        [sys.executable, str(PROJECT_ROOT / "compare_experiments.py"), "--suite-dir", str(output)],
        output / "logs" / "comparison.log",
    )


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base-config", default="configs/train.yaml", help="YAML or existing resolved_config.json; relative paths use caller CWD")
    parser.add_argument("--model", help="Original pretrained backbone directory or Hugging Face repository")
    parser.add_argument("--train-file")
    parser.add_argument("--validation-file")
    parser.add_argument("--text-template-file")
    parser.add_argument("--output-dir", default="outputs/ablation_v4")
    parser.add_argument("--experiments", nargs="+", choices=EXPERIMENTS, default=None,
                        help="Defaults to ce/weighted_ce for custom scores; legacy 1..5 keeps baseline/weighted/ce")
    parser.add_argument("--seed", type=int)
    parser.add_argument("--epochs", type=float)
    parser.add_argument("--max-steps", type=int)
    parser.add_argument("--max-train-samples", type=int)
    parser.add_argument("--max-eval-samples", type=int, help="Rejected: use a fixed shared validation subset file instead")
    parser.add_argument("--precision", choices=["auto", "bf16", "fp16", "fp32"])
    parser.add_argument("--cpu", action="store_true", help="Only for functional checks with a small offline backbone")
    parser.add_argument("--dry-run", action="store_true", help="Print the plan without creating files, downloading models, or training")
    parser.add_argument("--resume", action="store_true", help="Continue this unchanged suite, skipping completed runs")
    return parser.parse_args(argv)


def validate_execution_device(config: dict) -> None:
    """Prevent Trainer's implicit multi-GPU DataParallel in a single-rank suite."""
    if config["training"]["use_cpu"]:
        return
    import torch

    count = torch.cuda.device_count()
    if count != 1:
        raise RuntimeError(
            f"This controlled suite requires exactly one visible CUDA device; found {count}. "
            "Select one GPU before launching, for example CUDA_VISIBLE_DEVICES=0 python run_experiments.py ... . "
            "For zero visible devices, check the CUDA PyTorch installation/driver, or use --cpu for a tiny functional check."
        )


def main(argv: list[str] | None = None) -> None:
    options = parse_args(argv)
    if any(key in os.environ for key in ("RANK", "LOCAL_RANK", "WORLD_SIZE")):
        raise ValueError("Launch run_experiments.py with ordinary python, not torchrun/DDP; it controls one process/GPU")
    output = Path(options.output_dir).expanduser().resolve()
    previous_path = output / "manifest.json"
    previous = json.loads(previous_path.read_text(encoding="utf-8")) if options.resume and previous_path.is_file() else None
    manifest, configs = build_plan(options, previous=previous)
    if options.dry_run:
        print(json.dumps({
            "dry_run": True,
            "manifest": manifest,
            "commands": [{
                "name": experiment["name"],
                "train": train_command(experiment),
                "evaluate": evaluation_command(experiment, configs[experiment["name"]]),
                "resolved_config": configs[experiment["name"]],
            } for experiment in manifest["experiments"]],
        }, ensure_ascii=False, indent=2, allow_nan=False))
        return
    validate_execution_device(manifest["base_config"])
    print("Running a new controlled comparison (not reusing historical trained models).", flush=True)
    print("Shared overrides: ordinal_weight=0, early_stopping_patience=0, "
          f"exclude_all_three={manifest['uniform_overrides']['exclude_all_three']}.", flush=True)
    for experiment in manifest["experiments"]:
        print(f"  {experiment['name']}: boundary_weight={experiment['boundary_weight']}, "
              f"class_weight_mode={experiment['class_weight_mode']}", flush=True)
    initialize_suite(output, manifest, configs, resume=options.resume)
    # Atomic ownership prevents two invocations training into the same suite.
    lock = output / ".runner.lock"
    try:
        descriptor = os.open(lock, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
    except FileExistsError as exc:
        raise RuntimeError(f"Another runner may be active. Check the PID in {lock} before removing a stale lock.") from exc
    try:
        with os.fdopen(descriptor, "w", encoding="utf-8") as handle:
            handle.write(f"{os.getpid()}\n")
        execute_suite(manifest, configs, resume=options.resume)
    finally:
        lock.unlink(missing_ok=True)
    print(f"Completed. Read {output / 'comparison.md'} and {output / 'summary.csv'}.")


if __name__ == "__main__":
    try:
        main()
    except (ValueError, FileExistsError, RuntimeError) as error:
        print(f"ERROR: {error}", file=sys.stderr)
        sys.exit(1)
