#!/usr/bin/env python3
"""Compare expert-validation results; test metrics never participate in selection."""

from __future__ import annotations

import argparse
import csv
from io import StringIO
import json
import math
from pathlib import Path
import re
from typing import Any

from run_experiments import atomic_json, file_sha256, value_sha256


EXACT_METRICS = {"accuracy", "exact_accuracy", "row_exact_match", "all_dimensions_accuracy"}
NON_MODEL_JSON = {
    "alignment_source_provenance.json", "provenance.json", "training_summary.json",
    "class_weight_report.json", "trainer_state.json", "training_args.json",
}


def read_json(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"Expected a JSON object: {path}")
    return value


def checkpoint_identity(path: str | Path, *, names: list[str] | None = None,
                        values: list[int] | None = None) -> dict[str, Any]:
    """Hash serving files, excluding reports that themselves refer to this hash."""
    directory = Path(path).expanduser().resolve()
    config = read_json(directory / "config.json")
    if config.get("model_type") != "modernbert" or not isinstance(config.get("score_dim_names"), list):
        raise ValueError(f"Expected a trained mmBERT scoring checkpoint: {directory}")
    if names is not None and config["score_dim_names"] != names:
        raise ValueError("Source checkpoint dimension names/order differ from the prepared expert task")
    if values is not None and config.get("score_values") != values:
        raise ValueError("Source checkpoint score_values differ from the prepared expert task")
    files = {
        item.name: file_sha256(item)
        for item in sorted(directory.iterdir())
        if item.is_file() and item.name not in NON_MODEL_JSON
        and not item.name.startswith(".")
        and item.suffix.lower() in {".json", ".safetensors", ".bin", ".txt", ".model", ".spm", ".tiktoken"}
    }
    if not any(name.endswith((".safetensors", ".bin")) for name in files):
        raise ValueError(f"Checkpoint has no local model weights: {directory}")
    return {"path": str(directory), "files": files, "sha256": value_sha256(files)}


def validate_selection(selection: dict[str, Any]) -> dict[str, Any]:
    if not isinstance(selection, dict):
        raise ValueError("selection must be a mapping")
    extra = set(selection) - {"metric", "secondary_metric", "tie_tolerance"}
    if extra:
        raise ValueError(f"Unknown selection options: {sorted(extra)}")
    result = {"metric": "accuracy", "secondary_metric": "row_exact_match", "tie_tolerance": 1e-12}
    result.update(selection)
    for key in ("metric", "secondary_metric"):
        if result[key] not in EXACT_METRICS:
            raise ValueError(f"selection.{key} must be one of {sorted(EXACT_METRICS)}")
    tolerance = result["tie_tolerance"]
    if isinstance(tolerance, bool) or not isinstance(tolerance, (int, float)) or not math.isfinite(tolerance) or not 0 <= tolerance < 1:
        raise ValueError("selection.tie_tolerance must be finite and in [0,1)")
    return result


def choose_candidate(candidates: list[dict[str, Any]], selection: dict[str, Any]) -> dict[str, Any]:
    """Maximize exact agreement, then secondary; keep an unadapted baseline on ties."""
    selection = validate_selection(selection)
    if not candidates:
        raise ValueError("No validation candidates are available")
    remaining = candidates
    for key in (selection["metric"], selection["secondary_metric"]):
        for candidate in remaining:
            value = candidate.get(key)
            if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or not 0 <= value <= 1:
                raise ValueError(f"Candidate {candidate.get('candidate')} has invalid selection metric {key}")
        best = max(candidate[key] for candidate in remaining)
        remaining = [candidate for candidate in remaining if best - candidate[key] <= selection["tie_tolerance"]]
    # Ties are not evidence of an improvement. Stable lexical ordering only
    # resolves ties among candidates of the same baseline/adaptation status.
    return min(remaining, key=lambda item: (item.get("candidate") != "baseline", item.get("run", ""), item["candidate"]))


def _check_report(report: dict[str, Any], manifest: dict[str, Any], candidate: dict[str, Any]) -> None:
    schema = manifest["schema"]
    expected = manifest["data"]["expert_validation"]
    names, values = schema["dimension_names"], schema["score_values"]
    if report.get("dimensions") != names or report.get("score_values") != values:
        raise ValueError("Validation report dimensions/order or score_values differ from the pipeline")
    if report.get("input_sha256") != expected["sha256"] or report.get("examples") != expected["rows"]:
        raise ValueError("Validation report is not the complete prepared expert_validation split")
    if report.get("num_dimensions") != len(names) or report.get("num_classes") != len(values):
        raise ValueError("Validation report has an inconsistent dimension/class count")
    if Path(report.get("model", "")).resolve() != Path(candidate["model"]).resolve():
        raise ValueError("Validation report model differs from its recorded candidate")
    identity = checkpoint_identity(candidate["model"], names=names, values=values)
    if identity != candidate["model_identity"]:
        raise ValueError("Candidate checkpoint files changed after evaluation")
    if report.get("model_config_sha256") != identity["files"]["config.json"]:
        raise ValueError("Candidate config.json changed after evaluation")
    if not re.fullmatch(r"[0-9a-f]{64}", report.get("evaluated_data_sha256", "")):
        raise ValueError("Validation report is missing its evaluated-data fingerprint")
    input_schema = {"text_column": "text", "scores_column": "scores", "score_columns": None, "exclude_all_three": False}
    if report.get("input_schema") != input_schema:
        raise ValueError("Validation report changed the canonical input/filtering policy")
    metrics = report.get("metrics", {})
    count = expected["rows"]
    if not isinstance(count, int) or isinstance(count, bool) or count < 1:
        raise ValueError("Expert validation must contain at least one case")
    matrices = report.get("confusion_matrices", {})
    correct = 0
    correct_per_dimension = []
    for name in names:
        matrix = matrices.get(name)
        if not isinstance(matrix, list) or len(matrix) != len(values) or any(
            not isinstance(row, list) or len(row) != len(values)
            or any(type(value) is not int or value < 0 for value in row) for row in matrix
        ) or sum(map(sum, matrix)) != count:
            raise ValueError(f"Invalid six-class confusion matrix for {name}")
        dimension_correct = sum(matrix[index][index] for index in range(len(values)))
        correct += dimension_correct
        correct_per_dimension.append(dimension_correct)
    for key in ("accuracy", "exact_accuracy"):
        value = metrics.get(key)
        if isinstance(value, bool) or not isinstance(value, (float, int)) or not math.isclose(value, correct / (count * len(names)), abs_tol=1e-12):
            raise ValueError(f"Reported {key} does not match the confusion matrices")
    row_count = metrics.get("row_exact_match_count")
    if type(row_count) is not int or not 0 <= row_count <= count:
        raise ValueError("Invalid row_exact_match_count")
    if not max(0, correct - count * (len(names) - 1)) <= row_count <= min(correct_per_dimension):
        raise ValueError("Row exact matches are inconsistent with the dimension confusion matrices")
    for key in ("row_exact_match", "all_dimensions_accuracy"):
        value = metrics.get(key)
        if isinstance(value, bool) or not isinstance(value, (float, int)) or not math.isclose(value, row_count / count, abs_tol=1e-12):
            raise ValueError(f"Reported {key} differs from its numerator/denominator")


def summarize_alignment(run_dirs: list[str | Path], *, output_dir: str | Path | None = None) -> dict[str, Any]:
    """Compare completed runs with identical prepared data, using validation only."""
    roots = [Path(path).expanduser().resolve() for path in run_dirs]
    if not roots or len(set(roots)) != len(roots):
        raise ValueError("Supply at least one distinct alignment run directory")
    output = Path(output_dir).expanduser().resolve() if output_dir else roots[0]
    if len(roots) > 1 and output_dir is None:
        raise ValueError("Multi-run comparison requires --output-dir")
    rows, reports = [], []
    first_manifest = None
    first_report = None
    for root in roots:
        manifest = read_json(root / "pipeline_manifest.json")
        if manifest.get("pipeline") != "mmbert_scores.run_alignment.v1":
            raise ValueError(f"Unsupported alignment pipeline: {root}")
        if value_sha256({key: value for key, value in manifest.items() if key != "pipeline_signature"}) != manifest.get("pipeline_signature"):
            raise ValueError("Pipeline manifest changed after its signature was recorded")
        if first_manifest is None:
            first_manifest = manifest
        elif (manifest["dataset_fingerprint"] != first_manifest["dataset_fingerprint"]
              or manifest["selection"] != first_manifest["selection"]):
            raise ValueError("Runs must use identical expert train/validation/test and pseudo splits, schema, and selection settings")
        artifact = read_json(root / "validation_candidates.json")
        if artifact.get("pipeline_signature") != manifest["pipeline_signature"]:
            raise ValueError("Validation candidates belong to a different pipeline")
        expected_names = manifest["candidate_names"]
        if [item.get("name") for item in artifact.get("candidates", [])] != expected_names:
            raise ValueError("The pipeline does not have all expected validation candidates")
        for candidate in artifact["candidates"]:
            report_path = Path(candidate["validation_report"])
            if file_sha256(report_path) != candidate["validation_report_sha256"]:
                raise ValueError("Validation report bytes changed after candidate registration")
            report = read_json(report_path)
            _check_report(report, manifest, candidate)
            # All predictions must describe exactly the same ordered inputs and
            # inference conditions, including across different adaptation runs.
            if first_report is None:
                first_report = report
            for key in ("input_sha256", "evaluated_data_sha256", "dimensions", "score_values", "input_schema", "max_length", "precision", "batch_size", "attn_implementation"):
                if report.get(key) != first_report.get(key):
                    raise ValueError(f"Validation reports are not comparable: {key} differs")
            metrics = report["metrics"]
            row = {
                "run": str(root), "method": manifest["method"], "candidate": candidate["name"],
                "model": candidate["model"], "model_sha256": candidate["model_identity"]["sha256"],
                "source_verification": manifest["source_verification"]["status"],
                "examples": report["examples"],
                **{key: metrics.get(key) for key in ("accuracy", "exact_accuracy", "row_exact_match", "all_dimensions_accuracy", "mae", "mae_steps", "macro_f1", "qwk")},
            }
            rows.append(row)
            reports.append({"run": str(root), "candidate": candidate["name"], "report": str(report_path), "per_class_metrics": report.get("per_class_metrics", {}), "confusion_matrices": report["confusion_matrices"]})
            model_directory = Path(candidate["model"]).resolve()
            if output == model_directory or output.is_relative_to(model_directory):
                raise ValueError("Comparison output must be outside every candidate checkpoint directory")
    assert first_manifest is not None and first_report is not None
    selected = choose_candidate(rows, first_manifest["selection"])
    selection = first_manifest["selection"]
    selected_model = {
        **selected, "model_path": selected["model"], "selection_split": "expert_validation",
        "provenance_verified": selected["source_verification"] == "verified",
        "validation_only": True, "selection_metric": selection["metric"],
        "selection_value": selected[selection["metric"]], "secondary_metric": selection["secondary_metric"],
        "secondary_value": selected[selection["secondary_metric"]],
        "expert_validation_sha256": first_report["input_sha256"],
        "dataset_fingerprint": first_manifest["dataset_fingerprint"],
        "inference_settings": {key: first_report[key] for key in ("max_length", "precision", "batch_size", "attn_implementation", "input_schema")},
        "note": "This file points to the selected existing checkpoint; model weights have not been copied. No test metric was read to choose it.",
    }
    warnings = ["专家验证集只用于选择模型；最终效果需要尚未用于选择的专家测试集。", "几百条专家数据切分后验证样本较少，小幅差异不代表已获得稳定提升。", "完全并列时优先保留未适配 baseline；若 baseline 获选，说明本次验证未支持替换它。"]
    if any(row["source_verification"] == "unverified" for row in rows):
        warnings.append("包含显式允许的未核验来源 checkpoint，无法排除它曾见过专家验证或测试样本；相关分数不能作为无泄漏泛化证据。")
    result = {
        "schema_version": 1, "status": "complete", "selection_data": "expert_validation",
        "test_used_for_selection": False, "dataset_fingerprint": first_manifest["dataset_fingerprint"],
        "dimension_names": first_manifest["schema"]["dimension_names"],
        "score_values": first_manifest["schema"]["score_values"],
        "selection": selection, "selected_model": selected_model,
        "candidates": rows, "diagnostics": reports, "warnings": warnings,
    }
    output.mkdir(parents=True, exist_ok=True)
    atomic_json(output / "comparison.json", result)
    atomic_json(output / "selected_model.json", selected_model)
    table = StringIO()
    writer = csv.DictWriter(table, fieldnames=list(rows[0]))
    writer.writeheader()
    writer.writerows(rows)
    (output / "summary.csv").write_text("\ufeff" + table.getvalue(), encoding="utf-8")
    lines = ["# mmBERT 专家对齐验证对照", "", "以下结果全部来自同一专家验证集；测试集未参与选择。", "", "| 方法 | 候选 | 逐维精确一致率 | 三维全对率 | MAE | 来源 |", "|---|---|---:|---:|---:|---|"]
    for row in rows:
        mae = "—" if row["mae"] is None else f"{row['mae']:.4f}"
        lines.append(f"| {row['method']} | {row['candidate']} | {row['accuracy']:.2%} | {row['row_exact_match']:.2%} | {mae} | {row['source_verification']} |")
    lines += ["", f"选中：**{selected['method']} / {selected['candidate']}**。", "", f"主指标：`{selection['metric']}`；次指标：`{selection['secondary_metric']}`；完全并列优先 baseline。", "", f"模型目录：`{selected['model']}`。`selected_model.json` 是路径和验证记录，不是复制后的模型目录。", ""]
    lines += [f"- {warning}" for warning in warnings]
    (output / "comparison.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    return result


def main(argv: list[str] | None = None) -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--run-dir", help="One completed run_alignment.py output")
    group.add_argument("--run-dirs", nargs="+", help="Compare methods on the same prepared expert and pseudo splits")
    parser.add_argument("--output-dir", help="Required for multiple runs; defaults to --run-dir otherwise")
    args = parser.parse_args(argv)
    result = summarize_alignment([args.run_dir] if args.run_dir else args.run_dirs, output_dir=args.output_dir)
    print(json.dumps(result["selected_model"], ensure_ascii=False, indent=2, allow_nan=False))


if __name__ == "__main__":
    main()
