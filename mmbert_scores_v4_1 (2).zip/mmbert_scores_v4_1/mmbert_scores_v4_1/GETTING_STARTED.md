# 如何开始：三维、0/2/4/6/8/10 分

**如果你要处理“20 万条大模型标签 + 几百条专家标签”，请先看 [EXPERT_ALIGNMENT.md](EXPERT_ALIGNMENT.md)。** 本文保留环境、原始表格转换与普通 v4 单来源训练命令。

以下命令在解压后的 `mmbert_scores_v4_1` 项目目录运行。路径和文件名可以替换为你服务器上的实际位置。

## 1. 准备环境

继续使用原项目可用的 GPU 环境即可。依赖兼容目标保持为 PyTorch 2.8.0、Transformers 4.57.1、Datasets 4.3.0、Accelerate 1.10.1；本次 CPU 验证使用 Python 3.12。

```bash
cd mmbert_scores_v4_1
python -m pip install -r requirements.txt -r requirements-excel.txt
python -c "import torch; print('torch:', torch.__version__); print('cuda_available:', torch.cuda.is_available())"
```

正式 GPU 训练要求 `cuda_available: True`。CUDA 版 PyTorch 必须与服务器驱动兼容；优先复用原来已经验证可训练的环境。代码包不包含预训练权重和训练后的模型。

仅检查 Excel/CSV 转换、不训练时，只需安装轻量依赖：

```bash
python -m pip install -r requirements-excel.txt
```

## 2. 先验证本次上传的样例

```bash
python convert_data.py \
  --input examples/sample_input.xlsx \
  --config configs/train.yaml \
  --output-dir sample_converted
```

预期：`accepted_rows=1`、`rejected_rows=0`、`num_dimensions=3`。`sample_converted/labeled.jsonl` 的 `scores` 为 `[0,0,0]`，`text` 包含场景、痛点和解决方案三段。

样例只有一条记录。它用于确认格式，不应继续拆成三份或拿来判断训练准确率。若重复执行转换，请使用新的输出目录，或确认要替换后加 `--overwrite`。

CSV 输入的等价命令：

```bash
python convert_data.py \
  --input examples/sample_input.csv \
  --config configs/train.yaml \
  --output-dir sample_csv_converted
```

默认配置已处理 D 列错误的重复表头。你可以保留原文件不变；如果将 D 列手动改名为 `solution`，相同列顺序仍然可用。若列顺序不同，则先规范表头并把配置里的 `header_overrides` 改为 `{}`。

## 3. 转换完整训练数据

将 `/data/full_training.xlsx` 替换为你的完整训练数据路径：

```bash
python convert_data.py \
  --input /data/full_training.xlsx \
  --config configs/train.yaml \
  --output-dir converted
```

多个同格式文件可一起输入：

```bash
python convert_data.py \
  --input /data/part1.xlsx /data/part2.xlsx \
  --config configs/train.yaml \
  --output-dir converted
```

先看 `converted/report.json` 的接受/拒绝数量，再看 `converted/rejected.jsonl` 中被拒绝的原因。0 分和全 0 行都是合法数据；未知标签不会自动修正。

## 4. 去重并切分

```bash
python prepare_data.py \
  --input converted/labeled.jsonl \
  --output-dir data \
  --config configs/train.yaml
```

生成 `data/train.jsonl`、`data/validation.jsonl`、`data/test.jsonl` 和切分报告。默认比例约为 90% / 5% / 5%，同一份数据和相同 seed 得到稳定切分。

如果报告某个集合为空，需要更多独立数据或合理增大验证/测试比例。不要把同一行复制到多个集合。若仅验证一条记录的规范化，不训练，可显式设置 `--validation-ratio 0 --test-ratio 0`，但其结果没有独立验证集和测试集。

## 5. 单 GPU 正式训练

```bash
CUDA_VISIBLE_DEVICES=0 python train.py \
  --config configs/train.yaml \
  --text-template-file converted/text_template.json
```

如果模型权重已经在服务器本地：

```bash
CUDA_VISIBLE_DEVICES=0 python train.py \
  --config configs/train.yaml \
  --model /models/mmBERT-small \
  --text-template-file converted/text_template.json
```

新任务从 mmBERT 底座训练新的三维六分类头。不要把旧七维、1–5 分任务的 `final` 或 `checkpoint-N` 当成本次新任务的底座。

可在配置中修改训练轮数、批量、最大长度和数据量上限。默认使用全部有效训练数据，无需满足一百万条；若先做小规模实验，可加 `--max-train-samples 50000`。这个限制在切分后应用，不会重划验证集。

最佳模型写入：

```text
outputs/mmbert-scores-v4/final
```

训练报告中会保存维度顺序、实际分值、每类计数、过滤统计、文本长度及最佳模型的选择依据。

## 6. 评估保留的测试集

```bash
python evaluate.py \
  --model outputs/mmbert-scores-v4/final \
  --data data/test.jsonl \
  --output outputs/test_metrics.json \
  --predictions-output outputs/test_predictions.csv \
  --device cuda
```

优先查看 `all_dimensions_accuracy`（一条记录三维全对）、各维 `accuracy`、各分数支持数和 6×6 混淆矩阵。`mae` 使用真实 0–10 分数，`mae_steps` 使用档位距离。

## 7. 预测并导出 CSV

对已转换的文本数据预测：

```bash
python predict.py \
  --model outputs/mmbert-scores-v4/final \
  --input data/test.jsonl \
  --output outputs/predictions.csv \
  --device cuda \
  --include-probabilities
```

对原始字段 CSV 预测，保留输入列并追加预测列：

```bash
python predict.py \
  --model outputs/mmbert-scores-v4/final \
  --input /data/to_predict.csv \
  --output outputs/raw_predictions.csv \
  --device cuda \
  --include-probabilities
```

只要训练时保存了 `text_template.json`，原始字段 CSV 就按训练模板组装文本并处理已配置的重复表头。预测不需要标签值，也不按标签筛行；当前批量预测入口直接支持 CSV/JSONL。Excel 原表可先另存为 CSV；不要对无标签预测数据运行训练标签转换器。

三个正式预测列为 `pred_novelty_score`、`pred_demand_score`、`pred_quality_score`，取值只会是六档之一。`pred_expected_*` 可为小数，是概率期望诊断值，不是最终分类结果。

## 8. 中断后继续同一任务

```bash
CUDA_VISIBLE_DEVICES=0 python train.py \
  --config configs/train.yaml \
  --text-template-file converted/text_template.json \
  --resume-from-checkpoint auto
```

使用同一任务、数据、配置和输出目录恢复。`final` 是部署目录；恢复训练使用包含 Trainer 状态的 `checkpoint-N`。

## 9. 服务器上自行验证代码链路

```bash
python -m pip install -r requirements-dev.txt
python -m pytest -q
python scripts/smoke_test.py \
  --num-dimensions 3 \
  --score-values 0 2 4 6 8 10 \
  --device cpu \
  --work-dir /tmp/mmbert-v4-smoke
```

此测试创建本地随机小型模型，不下载 mmBERT 权重。输出仅用于验证程序正确运行，不能作为业务精度、GPU 吞吐量或正式模型效果的证据。
