# v4.1：20 万条自动标签与几百条专家标签如何一起训练

本版以 v4 的三维六分类代码为基础。三个维度保持 `novelty_score`、`demand_score`、`quality_score`，每维正式输出只能是 `0、2、4、6、8、10`。

## 1. 推荐先运行哪一种

**先运行 `staged`：自动标签训练 → 专家标签微调。** 自动标签用于第一阶段；第二阶段以专家标签为唯一监督，学习专家的评分方式。无需先把生成自动标签的大模型改造完成。

| 方法 | 本版入口 | 用途 |
| --- | --- | --- |
| 只用专家数据 | `--method expert_only` | 从原始 mmBERT 底座训练，作为必要对照；几百条能否覆盖业务差异，需要验证 |
| 两阶段训练 | `--method staged` | 推荐主方案：先用自动标签训练，再从其权重开始一轮新的专家训练 |
| 两阶段加少量回放 | `--method staged_replay` | 对照方案：第二阶段以专家批次为主，额外加入小权重自动标签损失，检查是否改善泛化 |

不建议把 20 万条自动标签和几百条专家标签直接拼起来、随机打乱、等权训练。这样的批次大多来自自动标签，无法体现“最终应服从专家评分”的目标。本版的回放独立计算两个来源的批次平均损失：

```text
loss = mean(expert_loss) + replay_weight * mean(replay_loss)
```

默认 `replay_weight=0.1`；这只是待验证的起点，不是已证明最优的值，也不是“专家梯度一定占 90%”的保证。训练轮次和步数按专家训练集计算，自动标签池变大不会自动增加其损失权重。默认回放最多 5,000 条，只从自动标签训练集取出。

`staged` 与 `staged_replay` 都会把**未经过专家微调的第一阶段模型**保留为候选，重新在同一个专家验证集上评估。如果微调后的候选未更好，就选回原模型；主、次指标都相同时也保留原模型。训练成功不等于专家一致率必然提高。

## 2. 数据组织与评分要求

准备两份数据：

- 自动标签表：约 20 万条，分数是大模型给出的。
- 专家标签表：几百条，分数是按同一准则确认的专家结果。

专家标签是最终训练目标。每条专家数据需要相同输入文本和完整的三个分数；本版不对缺失维度自动补 0，也不实现缺失标签掩码。专家对同一输入存在分歧时，先确定最终标签。完全相同输入而标签冲突会被数据准备脚本拒绝。

若两表的三列评分都叫 `novelty_score`、`demand_score`、`quality_score`，按同一配置分别转换即可。如果专家分数存在单独的 `expert_*` 三列，用 `configs/convert_expert_columns.yaml` 指定，不要误读同一表中保留的自动评分。

`examples/alignment/` 提供仅含表头的专家 CSV 模板。文本仍只由场景、痛点、解决方案组成；评分、评分理由和专家评语不应拼入模型输入。训练与上线预测必须使用相同文本模板。

### 案例分组比随机分行更重要

同一案例的不同版本、同一项目的改写、明显重复的数据，应采用同一稳定 `group_id`，以便整组切分与整组排除。在两份原始表增加该列后，将两边的转换配置都设为：

```yaml
conversion:
  group_column: group_id
```

没有分组 ID 时，代码依据规范化后的完整文本去重和检查重叠：统一 Unicode NFC、换行和首尾空白。它不会自动发现语义相近的改写，也不会知道两个不同 ID 实际属于同一项目。没有可靠分组信息时，不应声称已经排除了所有语义泄漏。

默认不把每份表分别从 1 开始的 `row_id` 当作跨表共享案例 ID。只有确认两表确实采用同一案例 ID 体系时，才在数据准备命令加 `--overlap-id-column id`；原表 `row_id` 转换后叫 `id`。若真正的共享键在另一列，请把两边转换配置的 `conversion.id_column` 指向该列，转换后仍统一使用 `id`。

## 3. 转换与隔离数据

以下命令在解压后的 `mmbert_scores_v4_1` 项目目录运行。环境安装与原始表头修复仍见 `GETTING_STARTED.md`。

```bash
python -m pip install -r requirements.txt -r requirements-excel.txt

python convert_data.py \
  --input /data/llm_scores.xlsx \
  --config configs/train.yaml \
  --output-dir converted/pseudo

python convert_data.py \
  --input /data/expert_scores.xlsx \
  --config configs/train.yaml \
  --output-dir converted/expert

python prepare_alignment_data.py \
  --expert-input converted/expert/labeled.jsonl \
  --pseudo-input converted/pseudo/labeled.jsonl \
  --config configs/train.yaml \
  --output-dir data/alignment
```

CSV 输入只需替换文件扩展名。若专家采用 `expert_*` 列，第二条转换命令改用 `--config configs/convert_expert_columns.yaml`。它要求文本列表头规范为 `scene_description`、`pain_analysis`、`solution`；这也避免把重复的 `novelty_score` 文本列误认为评分。

检查两次转换的 `report.json` 与 `rejected.jsonl`，确认保留数量及拒绝原因。缺失、非法分数不会自动修正；合法的 `[0,0,0]` 会保留。

数据准备的默认结果如下：

| 输出 | 默认比例或上限 | 使用阶段 |
| --- | --- | --- |
| `expert_train.jsonl` | 专家独立组约 70% | 第二阶段训练 |
| `expert_validation.jsonl` | 专家独立组约 15% | 第二阶段早停、选 checkpoint、候选比较 |
| `expert_test.jsonl` | 专家独立组约 15% | 完成方法选择后最终评估 |
| `pseudo_train.jsonl` | 剔除专家重叠后的自动标签组约 95% | 第一阶段训练 |
| `pseudo_validation.jsonl` | 剩余自动标签组约 5% | 第一阶段选择 checkpoint |
| `replay_train.jsonl` | 从 `pseudo_train` 取最多 5,000 条 | 仅 `staged_replay` 的第二阶段 |
| `report.json` | 数量、去重、剔除原因、各维分值支持数 | 数据审查 |
| `alignment_manifest.json` | 分片身份、SHA256、来源、评分模式 | 运行前和模型复用时校验 |

**全部专家案例及其关联组都会先从自动标签池剔除，包括专家训练、验证、测试三部分。** 一个自动标签组中只要有一条与专家案例匹配，该组就整体剔除。回放不会使用自动验证集，更不会使用专家验证集或测试集。

切分以独立组数为单位，按固定种子确定。70/15/15 不是每次都精确的行数比例，也不是三维分值的联合分层抽样。少量专家样本可能导致某些分数在验证或测试中缺失，报告会列出这些情况。独立组不足以生成请求的非空集合时直接报错，不会复制案例凑集合。

转换后的输入文件只读，数据准备使用 SQLite 处理较大的自动标签池。重复运行使用新输出目录；只有确认替换本工具此前生成的目录时才用 `--overwrite`。

## 4. 运行推荐的两阶段训练

```bash
CUDA_VISIBLE_DEVICES=0 python run_alignment.py \
  --config configs/alignment.yaml \
  --data-dir data/alignment \
  --method staged \
  --text-template-file converted/pseudo/text_template.json \
  --output-dir outputs/alignment-staged
```

若底座已下载到本地，增加 `--model /models/mmBERT-small`。新流程支持单 GPU 或 CPU；CPU 用 `--cpu`，适合功能验证，不建议用来运行正式 20 万条训练。`--dry-run` 会验证数据和配置、显示计划，不下载模型或开始训练。

默认训练设置：

| 项目 | 第一阶段 | 专家阶段 |
| --- | --- | --- |
| 训练数据 | 自动标签训练集 | 专家训练集 |
| 验证数据 | 自动标签验证集 | 专家验证集 |
| 编码器 | 训练 | 默认冻结 |
| 评分头 | 训练 | 训练 |
| 编码器学习率 | `2e-5` | 解冻时 `5e-6` |
| 评分头学习率 | `1e-4` | `2e-5` |
| 最多轮次 | 2 | 12；每轮验证，连续 3 次未改善早停 |
| 每设备 batch / 梯度累积 | 16 / 4 | 16 / 1 |
| 类别加权 | 关闭 | 关闭 |

这些参数是工程起点。小样本情况下先冻结编码器、仅调整评分头，是减少可训练参数的一种保守选择；如果已有表示无法区分专家关注的内容，仅调整头部可能不足。可以复制 `configs/alignment.yaml` 为一个独立配置，将 `expert.training.freeze_backbone` 改为 `false`，在同一数据切分上运行低学习率解冻对照。不要根据测试集反复调参。

第二阶段是**从同任务权重开始的新训练**：创建新的优化器、调度器及早停状态，专家类别统计也重新计算。它不是用 `--resume-from-checkpoint` 继续原来的自动标签训练。维度顺序或分值集合不同的旧模型不能强行加载。

`run_alignment.py` 本版每次要求新的或空的输出目录，不自动恢复中断的整条流水线。第一阶段已经完成并保存来源记录时，可以在新输出目录通过 `--source-model` 跳过它。底层 `train.py` 仍支持从 v4.1 的完整 checkpoint 恢复同一个训练 run；恢复要求数据、阶段、冻结、回放、批量、学习率和训练预算等保持一致，并保留优化器、调度器与随机状态。缺少指纹的旧 v4 checkpoint 可用于新 run 的权重初始化。

默认主选择指标是 `accuracy`：所有样本、三个维度上的精确一致率。最终候选主指标相同时再比较 `row_exact_match`：一条记录三个维度全部一致的比例；仍相同则保留第一阶段模型。没有相邻档位容错，0 预测成 2 也算错误。MAE、逐维指标和 6×6 混淆矩阵用于辅助分析。

## 5. 两个必要对照与第一阶段复用

先跑只用专家数据的对照：

```bash
CUDA_VISIBLE_DEVICES=0 python run_alignment.py \
  --config configs/alignment.yaml \
  --data-dir data/alignment \
  --method expert_only \
  --text-template-file converted/pseudo/text_template.json \
  --output-dir outputs/alignment-expert-only
```

`expert_only` 从原始 mmBERT 底座开始，采用相同的专家阶段设置。若比较冻结与解冻，应明确使用相应配置并保留各自结果；它们是不同候选。

两阶段主方案完成后，可复用其第一阶段模型，再运行回放对照，无需重跑 20 万条：

```bash
CUDA_VISIBLE_DEVICES=0 python run_alignment.py \
  --config configs/alignment.yaml \
  --data-dir data/alignment \
  --method staged_replay \
  --source-model outputs/alignment-staged/stage1/final \
  --text-template-file converted/pseudo/text_template.json \
  --output-dir outputs/alignment-replay
```

来源校验会检查分片指纹、评分模式、模型权重身份及本流程保存的来源记录。以前已经用全部 20 万条训练好的模型，可能提前见过现在的专家验证或测试案例；没有可验证来源记录的模型默认不能当作干净对照复用。

确实需要把现有模型作为探索起点时，可以显式加 `--allow-unverified-source`，报告会标记来源未验证；这不会把受污染或未知的评估变成可信的独立测试。该选项不放行错误的维度或评分标尺。来源记录是本地一致性核查，不是独立数据审计。

回放开启时每个专家训练批次另外抽取同等条数的自动标签，独立算损失后加权。训练日志中的组合损失不能直接与纯专家损失比较；专家验证和最终测试只计算专家数据上的指标。为保证已验证的断点恢复行为，回放限制为单进程、最多单 GPU，且 `training.dataloader_num_workers=0`；提供的专家配置已设为 0。普通无回放的底层 `train.py` 保留原多进程数据加载和 DDP 路径，但本次未测试 GPU/DDP。

## 6. 怎样判断有效

三种方法完成后，生成同一专家验证集上的比较：

```bash
python compare_alignment.py \
  --run-dirs outputs/alignment-staged outputs/alignment-expert-only outputs/alignment-replay \
  --output-dir outputs/alignment-comparison
```

结果包括 `comparison.md`、`comparison.json`、`summary.csv`、`selected_model.json`。最后一个文件的 `model_path` 是实际选中的模型目录，可能指向第一阶段模型，也可能指向专家微调模型。工具不复制模型权重，因此请保留它引用的训练输出目录。仅运行一个方案时，也可以读取该方案输出根目录中的 `selected_model.json`。

选中记录的 `inference_settings` 还保存实际验证时的最大长度、数值精度、批量和 attention 实现。运行器要求两个阶段及复用模型具有相同最大长度和相容文本模板。若自行改过推理参数，最终评估也应显式传入记录中的 `--precision`、`--batch-size`、`--attn-implementation`、`--max-length`，避免比较时与上线时的行为不一致。下面命令适用于提供的默认配置、相同 GPU 环境。

选型完成后，读取这一真实路径再做最终测试或预测：

```bash
MODEL_DIR=$(python -c 'import json; print(json.load(open("outputs/alignment-comparison/selected_model.json"))["model_path"])')

python evaluate.py \
  --model "$MODEL_DIR" \
  --data data/alignment/expert_test.jsonl \
  --output outputs/final_expert_test_metrics.json \
  --predictions-output outputs/final_expert_test_predictions.csv \
  --device cuda

python predict.py \
  --model "$MODEL_DIR" \
  --input /data/to_predict.csv \
  --output outputs/aligned_predictions.csv \
  --device cuda
```

运行器也支持 `--evaluate-test`，它在本次运行的验证选择结束后额外评估选中模型；仍在比较多种方法时，建议保持默认关闭，完成跨方法选择后再执行上面的最终测试命令。

先在相同专家训练/验证/测试切分上比较三种方法。优先查看专家验证集的精确一致率与各维结果，同时检查：

- 三维全部一致率有没有同步改善；平均分的偏差有没有掩盖某一维退步。
- 0、2、4、6、8、10 各档有多少真实样本；样本极少时，不应将一次涨跌视为稳定结论。
- 高估与低估分别集中在哪些内容类型，专家关注的证据是否在输入中。
- 是否有与专家裁定原则不一致的同文冲突，或者文本模板、截断、数据来源造成的偏差。

本版不把大模型验证集的高分当作人类一致率，也不根据专家测试集选择方法。新流程默认只生成验证结果；只有显式请求测试评估才读取测试标签用于计算效果指标。建议先固定小范围候选、完成比较，再只对最终确定的模型评估 `expert_test.jsonl`。

几百条中如果大部分是专门挑出的“大模型出错案例”，它们适合帮助模型纠错，但不能单凭它们估计真实线上总体准确率。最终专家测试样本应尽量覆盖实际使用分布。对专家之间本就难达成一致的案例，也应先统一评分准则。

## 7. 功能验证与适用范围

```bash
python -m pip install -r requirements-dev.txt
python -m pytest -q
python scripts/smoke_alignment.py --work-dir /tmp/mmbert-v41-alignment-smoke
```

自检使用本地随机小型 ModernBERT 和合成数据，验证切分、训练、回放、来源校验、候选选择、保存和加载流程。交付中的 `VALIDATION.md` 记录实际执行命令与结果。

代码包不包含 20 万条完整数据、几百条真实专家数据或训练后的业务模型。因此只报告已完成的软件验证，不给出“对齐提升多少”的未经测量结论。方法是否胜过现有模型，最终由独立专家数据上的受控比较决定。
