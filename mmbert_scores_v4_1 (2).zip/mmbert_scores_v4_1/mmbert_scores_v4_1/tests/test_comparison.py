"""Controlled-comparison tests use fixed matrices, no training or downloads."""

from __future__ import annotations

from copy import deepcopy
import csv
import hashlib
import json

import numpy as np
import pytest

from compare_experiments import summarize_suite
from five_scores.config import DEFAULTS, validate_config
from five_scores.metrics import detailed_score_report


def write_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, allow_nan=False), encoding="utf-8")


def create_suite(tmp_path, *, metric="all_dimensions_accuracy", greater=True, labels=None, predictions=None):
    root = tmp_path / "suite"
    names = ["quality", "feasibility"]
    if labels is None:
        labels = np.array([[0, 4], [1, 3], [2, 4], [4, 0], [3, 2]])
    if predictions is None:
        predictions = {
            "baseline": np.array([[1, 3], [2, 3], [2, 3], [4, 0], [3, 3]]),
            "weighted": labels.copy(),
            "ce": np.array([[1, 3], [2, 3], [2, 3], [4, 0], [3, 3]]),
        }
    experiments = []
    input_schema = {"text_column": "text", "scores_column": "scores", "score_columns": None, "exclude_all_three": True}
    for name, predicted in predictions.items():
        boundary = 0.0 if name == "ce" else 0.2
        mode = "sqrt_inverse" if name == "weighted" else "none"
        run_dir = root / "runs" / name
        config = deepcopy(DEFAULTS)
        config["model"].update(dimension_names=names, score_values=[1, 2, 3, 4, 5],
                               boundary_weight=boundary, class_weight_mode=mode)
        config["data"].update(max_length=32, exclude_all_three=True)
        config["training"].update(output_dir=str(run_dir), metric_for_best_model=metric,
                                  greater_is_better=greater, early_stopping_patience=0)
        config = validate_config(config)
        config_path = root / "configs" / f"{name}.json"
        write_json(config_path, config)
        write_json(run_dir / "resolved_config.json", config)
        write_json(run_dir / "final" / "training_summary.json", {"global_step": 4})
        write_json(run_dir / "final" / "config.json", {"experiment": name, "score_boundary_weight": boundary})
        write_json(run_dir / "environment.json", {
            "torch": "2.8.0", "transformers": "4.57.1", "datasets": "4.3.0", "precision": "fp32",
            "world_size": 1, "effective_batch_size": 64, "resolved_revision": "fixed-source",
        })
        report = {
            "model": str(run_dir / "final"), "data": "/fixed/validation.jsonl", "examples": len(labels),
            "dimensions": names, "num_dimensions": len(names), "num_classes": 5, "max_length": 32,
            "input_sha256": "f" * 64, "evaluated_data_sha256": "e" * 64,
            # Model loss metadata legitimately differ between experiments.
            "model_config_sha256": hashlib.sha256((run_dir / "final" / "config.json").read_bytes()).hexdigest(),
            "precision": "fp32", "batch_size": 32, "attn_implementation": "sdpa",
            "input_schema": input_schema, "truncation_rate": 0.0,
            **detailed_score_report(labels, predicted, names),
        }
        write_json(run_dir / "validation_metrics.json", report)
        experiments.append({"name": name, "boundary_weight": boundary, "class_weight_mode": mode,
                            "config_path": str(config_path), "run_dir": str(run_dir)})
    manifest = {
        "schema_version": 1, "suite_signature": "test-suite",
        "selection": {"metric": metric, "greater_is_better": greater},
        "data": {"train": {"path": "/fixed/train.jsonl", "sha256": "a" * 64},
                 "validation": {"path": "/fixed/validation.jsonl", "sha256": "f" * 64}},
        "experiments": experiments,
    }
    write_json(root / "manifest.json", manifest)
    return root


def edit_json(path, callback):
    value = json.loads(path.read_text(encoding="utf-8"))
    callback(value)
    write_json(path, value)


def test_selects_by_exact_row_metric_and_exports_percentage_point_deltas(tmp_path):
    root = create_suite(tmp_path)
    result = summarize_suite(root)
    assert result["status"] == "complete"
    assert result["selected_model"]["experiment"] == "weighted"
    assert result["selected_model"]["validation_only"] is True
    baseline, weighted, _ = result["experiments"]
    assert weighted["all_dimensions_accuracy"] == 1
    assert weighted["delta_exact_accuracy_pp"] == pytest.approx(100 * (1 - baseline["exact_accuracy"]))
    assert baseline["delta_exact_accuracy_pp"] == 0
    assert len(result["per_dimension"]) == 6
    assert len(result["per_score"]) == 30
    for filename in ("summary.csv", "per_dimension.csv", "per_score.csv", "comparison.json", "comparison.md", "selected_model.json"):
        assert (root / filename).is_file()
    assert "1↔2" in (root / "comparison.md").read_text(encoding="utf-8")


def test_lower_is_better_selection_is_not_accidentally_reversed(tmp_path):
    root = create_suite(tmp_path, metric="low_to_nonlow_rate", greater=False)
    result = summarize_suite(root)
    assert result["selected_model"]["experiment"] == "weighted"
    assert result["selected_model"]["selection_value"] == 0
    assert result["selected_model"]["greater_is_better"] is False


def test_tied_primary_uses_exact_accuracy_then_name_without_claiming_significance(tmp_path):
    labels = np.array([[0, 4], [1, 3], [2, 4], [4, 0], [3, 2]])
    baseline = labels.copy()
    baseline[0] = [1, 3]
    weighted = labels.copy()
    weighted[0, 0] = 1
    root = create_suite(tmp_path, labels=labels, predictions={"baseline": baseline, "weighted": weighted, "ce": weighted})
    result = summarize_suite(root)
    assert result["selected_model"]["experiment"] == "ce"
    assert result["selected_model"]["selection_value"] == pytest.approx(4 / 5)
    assert any("主指标并列" in warning for warning in result["warnings"])


def test_partial_runs_publish_pending_status_and_remove_stale_selection(tmp_path):
    root = create_suite(tmp_path)
    summarize_suite(root)
    (root / "runs" / "weighted" / "validation_metrics.json").unlink()
    result = summarize_suite(root, allow_incomplete=True)
    assert result["status"] == "partial"
    assert result["pending_experiments"] == ["weighted"]
    assert result["selected_model"] is None
    assert not (root / "selected_model.json").exists()
    with pytest.raises(ValueError, match="incomplete"):
        summarize_suite(root)


@pytest.mark.parametrize("field,value,error", [
    ("input_sha256", "0" * 64, "input_sha256"),
    ("evaluated_data_sha256", "0" * 64, "rows/order/schema"),
    ("max_length", 64, "max_length"),
    ("precision", "bf16", "rows/order/schema"),
    ("batch_size", 16, "rows/order/schema"),
    ("dimensions", ["feasibility", "quality"], "dimensions/order"),
    ("input_schema", {}, "input_schema"),
])
def test_rejects_noncomparable_evaluation_even_if_counts_match(tmp_path, field, value, error):
    root = create_suite(tmp_path)
    edit_json(root / "runs" / "weighted" / "validation_metrics.json", lambda report: report.update({field: value}))
    with pytest.raises(ValueError, match=error):
        summarize_suite(root)


def test_rejects_inconsistent_matrices_and_reported_metrics(tmp_path):
    root = create_suite(tmp_path)
    edit_json(root / "runs" / "weighted" / "validation_metrics.json",
              lambda report: report["metrics"].update(exact_accuracy=0.5))
    with pytest.raises(ValueError, match="does not match expected"):
        summarize_suite(root)


def test_rejects_uncontrolled_training_changes(tmp_path):
    root = create_suite(tmp_path)
    edit_json(root / "configs" / "weighted.json", lambda config: config["training"].update(learning_rate=1e-4))
    with pytest.raises(ValueError, match="shared training/data/model"):
        summarize_suite(root)


def test_rejects_actual_config_or_training_budget_drift(tmp_path):
    root = create_suite(tmp_path)
    edit_json(root / "runs" / "weighted" / "resolved_config.json", lambda config: config["training"].update(seed=123))
    with pytest.raises(ValueError, match="actual resolved_config"):
        summarize_suite(root)
    config = json.loads((root / "configs" / "weighted.json").read_text(encoding="utf-8"))
    write_json(root / "runs" / "weighted" / "resolved_config.json", config)
    edit_json(root / "runs" / "weighted" / "final" / "training_summary.json", lambda summary: summary.update(global_step=3))
    with pytest.raises(ValueError, match="actual training steps"):
        summarize_suite(root)


def test_zero_support_stays_null_and_csv_empty(tmp_path):
    labels = np.array([[0, 0], [1, 1]])
    predictions = {"baseline": np.array([[0, 0], [0, 0]]), "weighted": labels.copy()}
    root = create_suite(tmp_path, labels=labels, predictions=predictions)
    result = summarize_suite(root)
    for row in result["experiments"]:
        assert row["high_to_nonhigh_rate"] is None
        assert row["score_5_recall"] is None
        assert row["score_5_precision"] is None
    with (root / "per_score.csv").open(encoding="utf-8-sig", newline="") as handle:
        score_five = [row for row in csv.DictReader(handle) if row["score"] == "5"]
    assert all(row["recall"] == row["precision"] == "" for row in score_five)


def test_same_teacher_histogram_with_different_record_order_is_rejected(tmp_path):
    root = create_suite(tmp_path)
    # Identical matrices are not sufficient evidence of identical ordered inputs.
    edit_json(root / "runs" / "ce" / "validation_metrics.json",
              lambda report: report.update(evaluated_data_sha256="b" * 64))
    with pytest.raises(ValueError, match="rows/order/schema"):
        summarize_suite(root)


def test_rejects_model_configuration_changed_after_its_report(tmp_path):
    root = create_suite(tmp_path)
    edit_json(root / "runs" / "weighted" / "final" / "config.json", lambda value: value.update(score_boundary_weight=0.5))
    with pytest.raises(ValueError, match="config.json changed after evaluation"):
        summarize_suite(root)
