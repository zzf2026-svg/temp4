"""Training-only choices must preserve exact labels and isolate train statistics."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pytest

from five_scores.config import load_config
from five_scores.data import load_labeled_dataset
from train import build_class_weight_report, count_score_classes, resolve_selection_options


@pytest.mark.parametrize("metric,expected", [
    ("all_dimensions_accuracy", True), ("eval_accuracy", True),
    ("mae", False), ("authenticity_mae", False),
    ("endpoint_boundary_error_rate", False), ("low_to_nonlow_rate", False),
])
def test_checkpoint_selection_infers_quality_metric_direction(metric, expected):
    name = metric.removeprefix("eval_")
    actual = resolve_selection_options({"metric_for_best_model": metric, "greater_is_better": None}, {name: 0.0})
    assert actual == (name, expected)


def test_selection_rejects_unknown_metrics_and_support_counts():
    for metric in ["not_a_metric", "low_to_nonlow_support"]:
        with pytest.raises(ValueError):
            resolve_selection_options({"metric_for_best_model": metric, "greater_is_better": None}, {"low_to_nonlow_support": 0})


def test_class_counts_use_filtered_capped_external_scores(tmp_path):
    path = tmp_path / "scores.jsonl"
    scores = [[3, 3], [1, 5], [2, 4], [3, 3], [5, 1]]
    path.write_text("\n".join(json.dumps({"text": f"row {i}", "scores": row}) for i, row in enumerate(scores)), encoding="utf-8")
    raw = load_labeled_dataset(path, num_dimensions=2, exclude_all_three=True)
    assert len(raw) == 3
    capped = raw.select(range(2))
    counts = count_score_classes(capped, 2)
    np.testing.assert_array_equal(counts, [[1, 1, 0, 0, 0], [0, 0, 0, 1, 1]])


def test_no_class_weighting_is_an_exact_identity():
    counts = np.asarray([[90, 1, 3, 5, 1], [0, 0, 0, 100, 0]])
    report = build_class_weight_report(counts, {"dimension_names": ["a", "b"], "class_weight_mode": "none"})
    np.testing.assert_array_equal(report["weights"], np.ones((2, 5)))
    assert report["class_counts"] == counts.tolist()


def test_sqrt_inverse_raw_cap_and_frequency_normalization_are_separate():
    counts = np.asarray([[996, 1, 1, 2, 0], [200, 200, 200, 200, 200]])
    report = build_class_weight_report(counts, {"dimension_names": ["a", "b"], "class_weight_mode": "sqrt_inverse"})
    raw, weights = np.asarray(report["raw_weights"]), np.asarray(report["weights"])
    assert np.all((raw >= 0.5) & (raw <= 3.0))
    assert weights[0, 1] > 3.0  # Normalization is intentionally after raw clipping.
    frequencies = counts / counts.sum(axis=1, keepdims=True)
    np.testing.assert_allclose((frequencies * weights).sum(axis=1), [1.0, 1.0])
    np.testing.assert_allclose(weights[1], np.ones(5))
    assert report["absent_training_scores"] == [[5], []]
    assert report["final_weights_guaranteed_within_raw_cap"] is False


def test_manual_weights_are_dimension_specific_and_frequency_normalized():
    counts = np.asarray([[0, 5, 0, 5, 0], [2, 2, 2, 2, 2]])
    report = build_class_weight_report(counts, {
        "dimension_names": ["a", "b"], "class_weight_mode": "manual",
        "class_weights": [[1, 2, 3, 4, 5], [5, 4, 3, 2, 1]],
    })
    np.testing.assert_allclose(report["weights"], np.asarray([[1, 2, 3, 4, 5], [5, 4, 3, 2, 1]]) / 3)


def test_three_experiments_only_change_auxiliary_weight_and_output_directory():
    root = Path(__file__).resolve().parents[1] / "configs" / "legacy"
    names = ["experiment_ce.yaml", "experiment_boundary_02.yaml", "experiment_boundary_05.yaml"]
    configs = [load_config(root / name) for name in names]
    assert [config["model"].pop("boundary_weight") for config in configs] == [0.0, 0.2, 0.5]
    assert len({config["training"].pop("output_dir") for config in configs}) == 3
    assert configs[0] == configs[1] == configs[2]


def test_new_experiments_only_change_class_weights_and_output_directory():
    root = Path(__file__).resolve().parents[1] / "configs"
    configs = [load_config(root / name) for name in ["experiment_ce.yaml", "experiment_weighted_ce.yaml"]]
    assert all(config["model"]["score_values"] == [0, 2, 4, 6, 8, 10] for config in configs)
    assert all(config["model"]["boundary_weight"] == 0.0 for config in configs)
    assert [config["model"].pop("class_weight_mode") for config in configs] == ["none", "sqrt_inverse"]
    assert len({config["training"].pop("output_dir") for config in configs}) == 2
    assert configs[0] == configs[1]
