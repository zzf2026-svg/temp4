"""Regression checks for three dimensions and the six external even scores."""

from __future__ import annotations

import copy
import json

import numpy as np
import pytest
import torch
import torch.nn.functional as F
from transformers import AutoTokenizer

from five_scores.config import load_config
from five_scores.inference import ScorePredictor
from five_scores.metrics import detailed_score_report, score_metrics
from five_scores.modeling import ModernBertForMultiScores, per_dimension_score_loss, validate_score_config
from five_scores.schema import (
    DEFAULT_SCORE_VALUES, LEGACY_SCORE_VALUES, NEW_DIMENSION_NAMES,
    decode_indices, encode_scores, validate_score_values,
)


def six_config(config):
    config = copy.deepcopy(config)
    config.score_dim_names = list(NEW_DIMENSION_NAMES)
    config.score_num_dimensions = 3
    config.score_values = list(DEFAULT_SCORE_VALUES)
    config.score_num_classes = 6
    config.score_model_version = 4
    config.score_boundary_weight = 0.0
    return config


def test_every_score_round_trips_including_zero_and_ten():
    assert encode_scores(DEFAULT_SCORE_VALUES, DEFAULT_SCORE_VALUES) == list(range(6))
    assert decode_indices(range(6), DEFAULT_SCORE_VALUES) == list(DEFAULT_SCORE_VALUES)
    for bad in (1, 3, 5, 7, 9, 11, -2, 2.0, True):
        with pytest.raises(ValueError):
            encode_scores([bad], DEFAULT_SCORE_VALUES)
    for bad in (-1, 6, 1.0, True):
        with pytest.raises(ValueError):
            decode_indices([bad], DEFAULT_SCORE_VALUES)


@pytest.mark.parametrize("values", [[], [0], [0, 2, 2], [2, 0], [0, 2.0], [False, 2]])
def test_score_scale_is_explicit_and_ordered(values):
    with pytest.raises(ValueError):
        validate_score_values(values)


def test_config_defaults_and_manual_six_class_weights(tmp_path):
    path = tmp_path / "config.json"
    path.write_text("{}", encoding="utf-8")
    config = load_config(path)
    assert config["model"]["dimension_names"] == list(NEW_DIMENSION_NAMES)
    assert config["model"]["score_values"] == list(DEFAULT_SCORE_VALUES)
    assert config["model"]["boundary_weight"] == 0
    assert config["data"]["exclude_all_three"] is False
    path.write_text(json.dumps({"model": {
        "score_values": list(DEFAULT_SCORE_VALUES),
        "class_weight_mode": "manual", "class_weights": [[1] * 6] * 3,
    }}), encoding="utf-8")
    assert len(load_config(path)["model"]["class_weights"][0]) == 6


def test_new_scale_does_not_inherit_legacy_boundary_groups(tmp_path, tiny_config):
    path = tmp_path / "config.json"
    path.write_text(json.dumps({"model": {"boundary_weight": 0.2}}), encoding="utf-8")
    with pytest.raises(ValueError, match="boundary_weight"):
        load_config(path)
    config = six_config(tiny_config)
    config.score_boundary_weight = 0.2
    with pytest.raises(ValueError, match="boundary_weight"):
        validate_score_config(config)
    with pytest.raises(ValueError, match="boundary_weight"):
        per_dimension_score_loss(torch.zeros(1, 3, 6), torch.zeros(1, 3, dtype=torch.long), boundary_weight=0.2)


def test_six_class_ce_and_ordinal_loss_keep_all_classes():
    torch.manual_seed(23)
    logits = torch.randn(2, 3, 6, requires_grad=True)
    labels = torch.arange(6).reshape(2, 3)
    actual = per_dimension_score_loss(logits, labels, score_values=list(DEFAULT_SCORE_VALUES)).mean()
    expected = F.cross_entropy(logits.reshape(-1, 6), labels.reshape(-1))
    torch.testing.assert_close(actual, expected)
    actual.backward()
    assert logits.grad is not None and torch.isfinite(logits.grad).all()
    ordinal = per_dimension_score_loss(logits, labels, ordinal_weight=0.3,
                                       score_values=list(DEFAULT_SCORE_VALUES))
    cdf = logits.softmax(-1).cumsum(-1)[..., :-1]
    true_cdf = F.one_hot(labels, 6).float().cumsum(-1)[..., :-1]
    ce = F.cross_entropy(logits.reshape(-1, 6), labels.reshape(-1), reduction="none").reshape(2, 3)
    torch.testing.assert_close(ordinal, ce + 0.3 * (cdf - true_cdf).square().mean(-1))


def test_head_shape_backprop_and_target_bounds(tiny_config, input_batch):
    model = ModernBertForMultiScores(six_config(tiny_config))
    labels = torch.tensor([[0, 1, 5], [5, 3, 0]])
    output = model(**input_batch, labels=labels)
    assert output.logits.shape == (2, 3, 6)
    torch.testing.assert_close(output.loss, F.cross_entropy(output.logits.reshape(-1, 6), labels.reshape(-1)))
    output.loss.backward()
    assert model.classifier.weight.grad is not None and torch.isfinite(model.classifier.weight.grad).all()
    with pytest.raises(ValueError, match="class indices"):
        model(**input_batch, labels=torch.full((2, 3), 6, dtype=torch.long))


def test_saved_mapping_controls_prediction_and_expected_scores(tmp_path, tiny_pretrained, tiny_config):
    model = ModernBertForMultiScores(six_config(tiny_config)).eval()
    with torch.no_grad():
        model.classifier.weight.zero_()
        model.classifier.bias.zero_()
        for dimension, index in enumerate((0, 5, 3)):
            model.classifier.bias.view(3, 6)[dimension, index] = 4
    model.save_pretrained(tmp_path, safe_serialization=True)
    AutoTokenizer.from_pretrained(tiny_pretrained / "model", local_files_only=True).save_pretrained(tmp_path)
    predictor = ScorePredictor(tmp_path, device="cpu")
    result = predictor.predict(["scenario pain solution"], include_probabilities=True)[0]
    assert predictor.score_values == [0, 2, 4, 6, 8, 10]
    assert list(result["scores"].values()) == [0, 10, 6]
    for name in NEW_DIMENSION_NAMES:
        probabilities = result["probabilities"][name]
        assert len(probabilities) == 6
        assert sum(probabilities) == pytest.approx(1)
        assert result["expected_scores"][name] == pytest.approx(np.dot(probabilities, DEFAULT_SCORE_VALUES))
    saved = json.loads((tmp_path / "config.json").read_text(encoding="utf-8"))
    assert saved["score_model_version"] == 4 and saved["score_values"] == [0, 2, 4, 6, 8, 10]
    del saved["score_values"]
    (tmp_path / "config.json").write_text(json.dumps(saved), encoding="utf-8")
    with pytest.raises(ValueError, match="score_values"):
        ScorePredictor(tmp_path, device="cpu")


def test_legacy_checkpoint_without_scale_preserves_original_mapping(tiny_config):
    validate_score_config(tiny_config)
    assert tiny_config.score_values == list(LEGACY_SCORE_VALUES)
    assert tiny_config.score_num_classes == 5


def test_six_class_metrics_use_real_score_units_and_six_bins():
    labels = np.array([[0, 1, 2], [3, 4, 5]])
    predictions = np.array([[1, 1, 2], [3, 2, 5]])
    metrics = score_metrics(labels, predictions, NEW_DIMENSION_NAMES, score_values=DEFAULT_SCORE_VALUES)
    assert metrics["accuracy"] == pytest.approx(4 / 6)
    assert metrics["all_dimensions_accuracy"] == 0
    assert metrics["mae"] == pytest.approx(1)
    assert metrics["mae_steps"] == pytest.approx(0.5)
    assert metrics["two_or_more_steps_error_rate"] == pytest.approx(1 / 6)
    assert not any("boundary" in key or "group" in key or "low_to" in key for key in metrics)
    report = detailed_score_report(labels, predictions, NEW_DIMENSION_NAMES, score_values=DEFAULT_SCORE_VALUES)
    assert report["score_values"] == [0, 2, 4, 6, 8, 10]
    assert report["num_classes"] == 6
    for name in NEW_DIMENSION_NAMES:
        assert np.asarray(report["confusion_matrices"][name]).shape == (6, 6)
        assert list(report["per_class_metrics"][name]) == ["0", "2", "4", "6", "8", "10"]
    assert report["per_class_metrics"]["quality_score"]["0"]["recall"] is None
    assert "group_confusion_matrices" not in report
