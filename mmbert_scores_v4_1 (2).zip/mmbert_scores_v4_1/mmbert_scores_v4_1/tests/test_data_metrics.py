"""Boundary checks for label semantics and fixed-five-bin ordinal metrics."""

from __future__ import annotations

import json

import numpy as np
import pytest
from transformers import AutoTokenizer

from five_scores.data import canonical_record, get_tokenized_dataset, load_labeled_dataset, parse_scores, resolve_dimension_schema
from five_scores.metrics import detailed_score_report, metrics_for_report, score_metrics
from five_scores.schema import DEFAULT_DIMENSION_NAMES, default_dimension_names


@pytest.mark.parametrize("scores", [
    [True, 2, 3, 4, 5],
    [1.0, 2, 3, 4, 5],
    [0, 2, 3, 4, 5],
    [1, 2, 3, 4, 6],
    [1, 2, 3, 4],
    [1, 2, 3, 4, None],
])
def test_rejects_invalid_raw_scores(scores):
    with pytest.raises(ValueError):
        parse_scores(scores, num_dimensions=5)


def test_accepts_json_and_five_csv_integer_columns():
    assert parse_scores("[1,2,3,4,5]", num_dimensions=5) == [1, 2, 3, 4, 5]
    row = {"content": " 文本保留空格 ", **{f"s{i}": str(i) for i in range(1, 6)}}
    parsed = canonical_record(row, text_column="content", score_columns=[f"s{i}" for i in range(1, 6)], num_dimensions=5)
    assert parsed == {"text": " 文本保留空格 ", "scores": [1, 2, 3, 4, 5]}


@pytest.mark.parametrize("text", [None, "", "   ", 123])
def test_rejects_missing_or_blank_text(text):
    with pytest.raises(ValueError):
        canonical_record({"text": text, "scores": [1, 2, 3, 4, 5]}, num_dimensions=5)


@pytest.mark.parametrize("dimensions", [1, 5, 7])
def test_arrow_tokenization_converts_labels_once_without_padding(tmp_path, tiny_pretrained, dimensions):
    source = tmp_path / "valid.jsonl"
    first_scores = [(index % 5) + 1 for index in range(dimensions)]
    second_scores = [6 - score for score in first_scores]
    names = default_dimension_names(dimensions)
    rows = [
        {"text": "hello", "scores": first_scores, "dimension_names": names},
        {"text": "这 是 一个 清晰 回答", "scores": second_scores, "dimension_names": names},
    ]
    source.write_text("".join(json.dumps(row, ensure_ascii=False) + "\n" for row in rows), encoding="utf-8")
    raw = load_labeled_dataset(source, dimension_names=names)
    assert raw.features["scores"].length == dimensions
    tokenizer = AutoTokenizer.from_pretrained(tiny_pretrained / "model", local_files_only=True)
    tokenized = get_tokenized_dataset(raw, tokenizer, max_length=32, dimension_names=names)
    assert tokenized[0]["labels"] == [score - 1 for score in first_scores]
    assert tokenized[1]["labels"] == [score - 1 for score in second_scores]
    assert len(tokenized[0]["input_ids"]) < len(tokenized[1]["input_ids"])
    assert "text" not in tokenized.column_names
    assert "scores" not in tokenized.column_names


@pytest.mark.parametrize("dimensions", [1, 5, 7])
def test_configurable_dimensions_validate_each_record_and_scalar_columns(dimensions):
    names = default_dimension_names(dimensions)
    scores = [(i % 5) + 1 for i in range(dimensions)]
    assert parse_scores(json.dumps(scores), num_dimensions=dimensions) == scores
    raw = {"text": "保持原文", "dimension_names": names, **dict(zip(names, scores))}
    parsed = canonical_record(raw, score_columns=names, dimension_names=names)
    assert parsed == {"text": "保持原文", "scores": scores}
    with pytest.raises(ValueError, match=f"exactly {dimensions}"):
        canonical_record({"text": "长度错误", "scores": scores + [1]}, num_dimensions=dimensions)


def test_seven_dimensions_are_the_default():
    assert resolve_dimension_schema() == (7, None)
    assert parse_scores([4, 3, 4, 4, 3, 3, 3]) == [4, 3, 4, 4, 3, 3, 3]
    with pytest.raises(ValueError, match="exactly 7"):
        parse_scores([1, 2, 3, 4, 5])


@pytest.mark.parametrize("dimensions", [0, -1, True, 1.5, "7"])
def test_invalid_dimension_count_is_rejected(dimensions):
    with pytest.raises(ValueError, match="positive integer"):
        parse_scores([1], num_dimensions=dimensions)


def test_declared_dimension_order_cannot_be_silently_reinterpreted():
    row = {"text": "test", "scores": [1] * 7, "dimension_names": list(DEFAULT_DIMENSION_NAMES)}
    with pytest.raises(ValueError, match="dimension_names/order"):
        canonical_record(row, dimension_names=list(reversed(DEFAULT_DIMENSION_NAMES)))
    with pytest.raises(ValueError, match="does not match"):
        canonical_record(row, num_dimensions=5, dimension_names=DEFAULT_DIMENSION_NAMES)
    with pytest.raises(ValueError, match="distinct"):
        canonical_record(row, dimension_names=["x"] * 7)
    with pytest.raises(ValueError, match="distinct"):
        canonical_record(row, score_columns=["x"] * 7)


def test_metrics_preserve_ordinal_distance_and_five_class_f1():
    # Class 2 and 3 are absent. Compressing the remaining bins [0,1,4]
    # to [0,1,2] would incorrectly turn QWK into +0.5 instead of -1/26.
    labels = np.repeat(np.array([0, 1, 4])[:, None], 5, axis=1)
    predictions = np.repeat(np.array([0, 4, 1])[:, None], 5, axis=1)
    result = score_metrics(labels, predictions)
    assert result["qwk"] == pytest.approx(-1 / 26)
    assert result["mae"] == pytest.approx(2.0)
    assert result["accuracy"] == pytest.approx(1 / 3)
    assert result["all_dimensions_accuracy"] == pytest.approx(1 / 3)
    assert result["severe_error_rate"] == pytest.approx(2 / 3)
    assert result["macro_f1"] == pytest.approx(0.2)
    assert result["qwk_defined_dimensions"] == 5


def test_degenerate_qwk_is_finite_but_explicitly_undefined():
    labels = np.zeros((3, 5), dtype=np.int64)
    result = score_metrics(labels, labels)
    assert result["accuracy"] == 1
    assert result["mae"] == 0
    assert result["macro_f1"] == pytest.approx(0.2)
    assert result["qwk"] == 0
    assert result["qwk_defined_dimensions"] == 0
    assert result["dim_1_qwk_defined"] == 0
    assert all(np.isfinite(value) for value in result.values())


@pytest.mark.parametrize("labels", [
    np.zeros((1, 5), dtype=np.float64),
    np.zeros((1, 5), dtype=np.bool_),
    np.full((1, 5), 5, dtype=np.int64),
    np.zeros((1, 4), dtype=np.int64),
])
def test_metrics_reject_non_index_or_wrong_shape_labels(labels):
    with pytest.raises(ValueError):
        score_metrics(labels, np.zeros((1, 5), dtype=np.int64))


def test_adjacent_endpoint_to_middle_errors_are_counted_and_exact_remains_five_class():
    # Human scores: 2->3 and 4->3 are boundary violations despite distance=1.
    # 1->2 and 5->4 are still exact-score errors, but do not cross a group.
    labels = np.array([[2, 4], [1, 5], [3, 4]]) - 1
    predictions = np.array([[3, 3], [2, 4], [3, 4]]) - 1
    metrics = score_metrics(labels, predictions, ["quality", "feasibility"])
    assert metrics["exact_accuracy"] == metrics["accuracy"] == pytest.approx(2 / 6)
    assert metrics["row_exact_match"] == metrics["all_dimensions_accuracy"] == pytest.approx(1 / 3)
    assert metrics["severe_error_rate"] == 0
    assert metrics["endpoint_boundary_error_count"] == 2
    assert metrics["endpoint_boundary_error_support"] == 5
    assert metrics["endpoint_boundary_error_rate"] == pytest.approx(2 / 5)
    assert metrics["low_to_middle_count"] == 1
    assert metrics["low_to_middle_support"] == 2
    assert metrics["low_to_middle_rate"] == pytest.approx(1 / 2)
    assert metrics["high_to_middle_support"] == 3
    assert metrics["high_to_middle_rate"] == pytest.approx(1 / 3)
    assert metrics["low_to_high_count"] == metrics["high_to_low_count"] == 0
    assert metrics["row_any_boundary_violation_count"] == 1
    assert metrics["row_any_boundary_violation_rate"] == pytest.approx(1 / 3)
    assert metrics["quality_score_1_support"] == 1
    assert metrics["quality_score_1_correct_count"] == 0
    assert metrics["quality_score_1_recall"] == 0
    assert metrics["quality_score_2_predicted_count"] == 1
    assert metrics["feasibility_score_4_support"] == 2
    assert metrics["feasibility_score_4_correct_count"] == 1
    assert metrics["feasibility_score_4_recall"] == pytest.approx(1 / 2)
    assert metrics["max_endpoint_directional_error_rate"] == pytest.approx(1 / 2)
    assert metrics["endpoint_directional_defined_groups"] == 2
    assert metrics["endpoint_directional_total_groups"] == 4
    assert metrics["endpoint_directional_coverage"] == pytest.approx(1 / 2)
    assert metrics["endpoint_directional_all_groups_defined"] == 0


def test_teacher_middle_errors_are_exact_and_group_errors_but_not_endpoint_errors():
    labels = np.array([[3], [3], [3]]) - 1
    predictions = np.array([[2], [4], [3]]) - 1
    metrics = score_metrics(labels, predictions, ["quality"])
    assert metrics["accuracy"] == pytest.approx(1 / 3)
    assert metrics["group_mismatch_count"] == 2
    assert metrics["middle_to_nonmiddle_count"] == 2
    assert metrics["middle_to_nonmiddle_support"] == 3
    assert metrics["middle_to_nonmiddle_rate"] == pytest.approx(2 / 3)
    assert metrics["middle_to_low_count"] == 1
    assert metrics["middle_to_high_count"] == 1
    assert metrics["endpoint_boundary_error_count"] == 0
    assert metrics["endpoint_boundary_error_support"] == 0
    assert metrics["endpoint_boundary_error_defined"] == 0
    assert metrics["max_endpoint_directional_error_defined"] == 0
    assert metrics["endpoint_directional_coverage"] == 0
    assert all(np.isfinite(value) for value in metrics.values())
    report_metrics = metrics_for_report(metrics)
    assert report_metrics["endpoint_boundary_error_rate"] is None
    assert report_metrics["quality_high_to_nonhigh_rate"] is None
    assert report_metrics["max_endpoint_directional_error_rate"] is None
    assert report_metrics["row_endpoint_boundary_error_rate"] is None
    assert report_metrics["quality_score_1_recall"] is None
    assert report_metrics["quality_score_3_recall"] == pytest.approx(1 / 3)


def test_directional_errors_use_teacher_denominators_and_keep_full_confusions():
    # low1->high5, low2->middle3, high4->low2, high5->middle3, middle3->low1.
    labels = np.array([[1], [2], [4], [5], [3]]) - 1
    predictions = np.array([[5], [3], [2], [3], [1]]) - 1
    report = detailed_score_report(labels, predictions, ["quality"])
    metrics = report["metrics"]
    assert metrics["low_to_nonlow_rate"] == metrics["high_to_nonhigh_rate"] == 1
    assert metrics["low_to_high_count"] == metrics["high_to_low_count"] == 1
    assert metrics["low_to_high_support"] == metrics["high_to_low_support"] == 2
    assert metrics["low_to_high_rate"] == metrics["high_to_low_rate"] == pytest.approx(1 / 2)
    assert metrics["middle_to_low_rate"] == 1
    assert metrics["endpoint_boundary_error_rate"] == 1
    assert metrics["accuracy"] == metrics["row_exact_match"] == 0
    assert metrics["endpoint_directional_coverage"] == 1
    assert metrics["endpoint_directional_all_groups_defined"] == 1
    assert report["confusion_matrices"]["quality"] == [
        [0, 0, 0, 0, 1], [0, 0, 1, 0, 0], [1, 0, 0, 0, 0],
        [0, 1, 0, 0, 0], [0, 0, 1, 0, 0],
    ]
    assert report["group_confusion_matrices"]["quality"] == [[0, 1, 1], [1, 0, 0], [1, 1, 0]]
    assert report["score_distributions"]["quality"]["teacher"] == {str(i): 1 for i in range(1, 6)}
    assert report["score_distributions"]["quality"]["predicted"] == {"1": 1, "2": 1, "3": 2, "4": 0, "5": 1}


def test_undefined_recall_and_qwk_are_null_in_json_report_not_perfect_agreement():
    labels = np.zeros((3, 1), dtype=np.int64)
    report = detailed_score_report(labels, labels, ["quality"])
    assert report["metrics"]["accuracy"] == 1
    assert report["metrics"]["qwk"] is None
    assert report["metrics"]["quality_qwk"] is None
    assert report["metrics"]["high_to_nonhigh_rate"] is None
    assert report["metrics"]["low_to_nonlow_rate"] == 0
    assert report["per_class_metrics"]["quality"]["1"] == {
        "support": 3, "predicted_count": 3, "correct_count": 3, "recall": 1.0, "precision": 1.0,
    }
    assert report["per_class_metrics"]["quality"]["5"] == {
        "support": 0, "predicted_count": 0, "correct_count": 0, "recall": None, "precision": None,
    }
    # Strict JSON must contain real nulls rather than NaN/Infinity tokens.
    assert json.loads(json.dumps(report, allow_nan=False))["metrics"]["high_to_nonhigh_rate"] is None


def test_precision_uses_prediction_denominator_and_missing_prediction_is_undefined():
    labels = np.array([[0], [0], [1], [4]])
    predictions = np.array([[0], [1], [0], [1]])
    flat = score_metrics(labels, predictions, ["quality"])
    assert flat["quality_score_1_precision"] == pytest.approx(1 / 2)
    assert flat["quality_score_1_recall"] == pytest.approx(1 / 2)
    assert flat["quality_score_2_precision"] == 0
    assert flat["quality_score_2_precision_defined"] == 1
    assert flat["quality_score_5_precision_defined"] == 0
    report = detailed_score_report(labels, predictions, ["quality"])
    assert report["metrics"]["quality_score_5_precision"] is None
    assert report["per_class_metrics"]["quality"]["5"]["recall"] == 0
    assert report["per_class_metrics"]["quality"]["5"]["precision"] is None
