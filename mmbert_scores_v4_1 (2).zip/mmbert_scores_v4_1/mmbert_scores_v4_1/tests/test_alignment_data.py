"""Behavioral checks for small-expert/large-pseudo preparation boundaries."""

import csv
import json
from pathlib import Path
import subprocess
import sys

import pytest

from five_scores import alignment_data as alignment
from five_scores.data import normalized_text
from five_scores.schema import DEFAULT_SCORE_VALUES, NEW_DIMENSION_NAMES
from prepare_alignment_data import build_parser, options_from_args


def row(text, scores=None, **extra):
    return {"text": text, "scores": scores if scores is not None else [0, 2, 4], **extra}


def write_rows(path, rows):
    path.write_text("".join(json.dumps(item, ensure_ascii=False) + "\n" for item in rows), encoding="utf-8")
    return path


def read_rows(path):
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines()]


def setup_sources(tmp_path, *, experts=None, pseudos=None):
    if experts is None:
        experts = [row(f"expert {index}", [value] * 3, id=index) for index, value in enumerate(DEFAULT_SCORE_VALUES * 2)]
    if pseudos is None:
        pseudos = [row(f"pseudo {index}", [DEFAULT_SCORE_VALUES[index % 6]] * 3, id=index) for index in range(40)]
    return write_rows(tmp_path / "experts.jsonl", experts), write_rows(tmp_path / "pseudo.jsonl", pseudos)


def prepare(tmp_path, **kwargs):
    experts = kwargs.pop("experts", None)
    pseudos = kwargs.pop("pseudos", None)
    expert, pseudo = setup_sources(tmp_path, experts=experts, pseudos=pseudos)
    output = tmp_path / "prepared"
    report = alignment.prepare_alignment_dataset(expert, pseudo, output, **kwargs)
    return output, report


def all_records(output, source):
    splits = ("train", "validation", "test") if source == "expert" else ("train", "validation")
    return [record for split in splits for record in read_rows(output / f"{source}_{split}.jsonl")]


def test_defaults_provenance_counts_and_six_score_supports(tmp_path):
    output, report = prepare(tmp_path, replay_max_samples=7)
    assert {path.name for path in output.iterdir()} == alignment.OUTPUT_FILES
    assert report["dimension_names"] == list(NEW_DIMENSION_NAMES)
    assert report["score_values"] == list(DEFAULT_SCORE_VALUES)
    assert report["sources"]["expert"]["unique_rows"] == 12
    assert report["sources"]["pseudo"]["retained_unique_rows"] == 40
    assert report["sources"]["pseudo"]["excluded_unique_rows"] == 0
    assert report["split_groups"]["expert"] == {"train": 8, "validation": 2, "test": 2}
    assert report["split_groups"]["pseudo"] == {"train": 38, "validation": 2, "test": 0}
    assert report["splits"]["replay_train"]["rows"] == 7
    for name, info in report["splits"].items():
        records = read_rows(output / info["path"])
        assert len(records) == info["rows"]
        assert all(record["label_source"] == ("expert" if name.startswith("expert_") else "pseudo") for record in records)
        assert all(record["dimension_names"] == list(NEW_DIMENSION_NAMES) and record["score_values"] == list(DEFAULT_SCORE_VALUES) for record in records)
        assert all(Path(record["alignment_source"]["file"]).is_absolute() for record in records)
        for dimension, histogram in info["score_counts"].items():
            assert set(histogram) == {str(score) for score in DEFAULT_SCORE_VALUES}
            assert sum(histogram.values()) == len(records)
            assert info["missing_score_values"][dimension] == [value for value in DEFAULT_SCORE_VALUES if histogram[str(value)] == 0]
    # Coincident independent row counters are retained by default.
    assert {record["id"] for record in all_records(output, "expert")} <= {record["id"] for record in all_records(output, "pseudo")}
    manifest = alignment.load_alignment_manifest(output)
    assert manifest["files"] == report["splits"]
    assert manifest["overlap_policy"]["excludes_all_expert_from_pseudo"] is True
    assert manifest["overlap_policy"]["row_id_exclusion_enabled"] is False


def test_all_expert_partitions_removed_from_entire_pseudo_pool(tmp_path):
    experts = [row(f"expert {index}") for index in range(12)]
    pseudos = [row(f"expert {index}", [10, 8, 6]) for index in range(12)]
    pseudos += [row(f"extra {index}") for index in range(30)]
    output, report = prepare(tmp_path, experts=experts, pseudos=pseudos)
    expert_texts = {normalized_text(record["text"]) for record in all_records(output, "expert")}
    pseudo_texts = {normalized_text(record["text"]) for record in all_records(output, "pseudo")}
    assert not expert_texts & pseudo_texts
    assert report["sources"]["pseudo"]["excluded_unique_rows"] == 12
    for split in ("train", "validation", "test"):
        assert read_rows(output / f"expert_{split}.jsonl")
    replay = {normalized_text(record["text"]) for record in read_rows(output / "replay_train.jsonl")}
    train = {normalized_text(record["text"]) for record in read_rows(output / "pseudo_train.jsonl")}
    validation = {normalized_text(record["text"]) for record in read_rows(output / "pseudo_validation.jsonl")}
    assert replay <= train
    assert not replay & (validation | expert_texts)


def test_normalized_expert_dedup_preserves_first_provenance_and_zero_labels(tmp_path):
    experts = [row(" cafe\u0301\r\ncase ", [0, 0, 0], id="first", metadata={"reviewer": "A"}),
               row("caf\u00e9\ncase", [0, 0, 0], id="second")]
    experts += [row(f"other {index}") for index in range(8)]
    output, report = prepare(tmp_path, experts=experts)
    assert report["sources"]["expert"]["duplicates_removed"] == 1
    records = [record for record in all_records(output, "expert") if record["scores"] == [0, 0, 0]]
    assert len(records) == 1
    assert records[0]["id"] == "first"
    assert records[0]["metadata"] == {"reviewer": "A"}
    assert records[0]["text"] == experts[0]["text"]


def test_expert_label_conflict_aborts_without_partial_publish(tmp_path):
    expert, pseudo = setup_sources(tmp_path, experts=[row(" same "), row("same", [10, 10, 10])])
    with pytest.raises(ValueError, match="conflicting expert labels"):
        alignment.prepare_alignment_dataset(expert, pseudo, tmp_path / "out")
    assert not (tmp_path / "out").exists()
    assert not list(tmp_path.glob(".out.staging-*"))


def test_pseudo_conflicting_labels_fail_only_if_case_retained(tmp_path):
    experts = [row(f"expert {index}") for index in range(6)]
    pseudos = [row("expert 0"), row("expert 0", [10, 10, 10])]
    pseudos += [row(f"pseudo {index}") for index in range(8)]
    output, report = prepare(tmp_path, experts=experts, pseudos=pseudos)
    assert report["sources"]["pseudo"]["excluded_unique_rows"] == 1
    assert report["sources"]["pseudo"]["excluded_raw_rows"] == 2
    assert len(all_records(output, "pseudo")) == 8
    pseudos += [row("pseudo 0", [6, 8, 10])]
    write_rows(tmp_path / "pseudo.jsonl", pseudos)
    with pytest.raises(ValueError, match="conflicting pseudo labels"):
        alignment.prepare_alignment_dataset(tmp_path / "experts.jsonl", tmp_path / "pseudo.jsonl", tmp_path / "bad")
    assert not (tmp_path / "bad").exists()


def test_groups_block_variants_and_propagate_exact_overlap_to_whole_pseudo_group(tmp_path):
    experts = [row(f"expert {index}", group_id=f"case-{index}") for index in range(6)]
    pseudos = [row("alternate text for expert case 0", group_id="case-0"),
               row("expert 1", group_id="pseudo-other-name"),
               row("alternate pseudo text for expert 1", group_id="pseudo-other-name")]
    pseudos += [row(f"extra {index} version {version}", group_id=f"new-{index}") for index in range(8) for version in range(2)]
    output, report = prepare(tmp_path, experts=experts, pseudos=pseudos)
    assert report["sources"]["pseudo"]["excluded_unique_rows"] == 3
    removals = report["sources"]["pseudo"]["exclusion_reasons"]
    assert removals["expert_group"]["unique_rows"] == 1
    assert removals["expert_text"]["unique_rows"] == 1
    assert removals["linked_pseudo_group"]["unique_rows"] == 1
    train_groups = {record["group_id"] for record in read_rows(output / "pseudo_train.jsonl")}
    validation_groups = {record["group_id"] for record in read_rows(output / "pseudo_validation.jsonl")}
    assert not train_groups & validation_groups
    assert not {"case-0", "pseudo-other-name"} & (train_groups | validation_groups)


def test_shared_id_is_explicit_case_key_and_becomes_canonical_group_id(tmp_path):
    experts = [row(f"expert {index}", case_key=index) for index in range(6)]
    pseudos = [row("changed wording", case_key="0")]
    pseudos += [row(f"extra {index} variant {version}", case_key=f"new-{index}") for index in range(6) for version in range(2)]
    output, report = prepare(tmp_path, experts=experts, pseudos=pseudos, overlap_id_column="case_key")
    assert report["sources"]["pseudo"]["excluded_unique_rows"] == 1
    assert report["sources"]["pseudo"]["exclusion_reasons"]["expert_shared_id"]["unique_rows"] == 1
    assert all(record["group_id"] == record["case_key"] for record in all_records(output, "expert") + all_records(output, "pseudo"))
    assert not {record["group_id"] for record in read_rows(output / "pseudo_train.jsonl")} & {record["group_id"] for record in read_rows(output / "pseudo_validation.jsonl")}


def test_custom_group_column_is_preserved_as_canonical_group_id(tmp_path):
    experts = [row(f"expert {index}", document=f"e-{index}") for index in range(6)]
    pseudos = [row(f"pseudo {index}", document=f"p-{index}") for index in range(8)]
    output, report = prepare(tmp_path, experts=experts, pseudos=pseudos, group_column="document")
    assert report["sources"]["expert"]["group_column"] == "document"
    assert all(record["group_id"].startswith("e-") for record in all_records(output, "expert"))


def test_shared_key_named_group_id_does_not_overwrite_custom_split_group(tmp_path):
    experts = [row(f"expert {index}", document=f"expert-document-{index}", group_id=f"expert-case-{index}") for index in range(6)]
    pseudos = [row(f"pseudo {index}", document=f"pseudo-document-{index}", group_id=f"pseudo-case-{index}") for index in range(8)]
    output, _ = prepare(tmp_path, experts=experts, pseudos=pseudos, group_column="document", overlap_id_column="group_id")
    records = all_records(output, "expert") + all_records(output, "pseudo")
    assert all("document" in record["group_id"] for record in records)
    assert all("case" in record["alignment_source"]["overlap_id"]["value"] for record in records)


@pytest.mark.parametrize("experts,option,match", [
    ([row("a", group_id="one"), row("b")], {}, "missing group column"),
    ([row("a"), row("b", group_id="two")], {}, "mixed presence"),
    ([row("a", group_id="one"), row("a", group_id="two")], {}, "conflicting group IDs"),
    ([row("a", case="same", group_id="one"), row("b", case="same", group_id="two")], {"overlap_id_column": "case"}, "conflicting group IDs"),
    ([row("a")], {"overlap_id_column": "shared_case"}, "missing overlap ID column"),
])
def test_ambiguous_group_or_shared_case_mapping_fails(tmp_path, experts, option, match):
    expert, pseudo = setup_sources(tmp_path, experts=experts)
    with pytest.raises(ValueError, match=match):
        alignment.prepare_alignment_dataset(expert, pseudo, tmp_path / "out", **option)
    assert not (tmp_path / "out").exists()


def test_minimal_positive_splits_nonempty_and_zero_ratios_supported(tmp_path):
    output, report = prepare(tmp_path, experts=[row(f"e{index}") for index in range(3)], pseudos=[row("p0"), row("p1")])
    assert report["split_groups"]["expert"] == {"train": 1, "validation": 1, "test": 1}
    assert report["split_groups"]["pseudo"] == {"train": 1, "validation": 1, "test": 0}
    report = alignment.prepare_alignment_dataset(tmp_path / "experts.jsonl", tmp_path / "pseudo.jsonl", output,
        expert_validation_ratio=0, expert_test_ratio=0, pseudo_validation_ratio=0, replay_max_samples=0, overwrite=True)
    assert report["splits"]["expert_train"]["rows"] == 3
    for split in ("expert_validation", "expert_test", "pseudo_validation", "replay_train"):
        assert report["splits"][split]["rows"] == 0
        assert (output / f"{split}.jsonl").read_bytes() == b""
    alignment.load_alignment_manifest(output)


@pytest.mark.parametrize("source", ["expert", "pseudo"])
def test_too_few_independent_groups_fails_before_publication(tmp_path, source):
    experts = [row(f"expert {index}", group_id="one-group") for index in range(10)] if source == "expert" else None
    pseudos = [row(f"pseudo {index}", group_id="one-group") for index in range(10)] if source == "pseudo" else None
    expert, pseudo = setup_sources(tmp_path, experts=experts, pseudos=pseudos)
    with pytest.raises(ValueError, match=f"{source}: only 1 independent groups"):
        alignment.prepare_alignment_dataset(expert, pseudo, tmp_path / "out")
    assert not (tmp_path / "out").exists()


@pytest.mark.parametrize("options", [
    {"expert_validation_ratio": -0.1}, {"expert_test_ratio": float("nan")},
    {"expert_validation_ratio": 0.5, "expert_test_ratio": 0.5},
    {"pseudo_validation_ratio": True}, {"pseudo_validation_ratio": 1.0},
    {"seed": -1}, {"seed": True}, {"replay_max_samples": -1}, {"replay_max_samples": True},
    {"overlap_id_column": "scores"}, {"group_column": " "},
])
def test_invalid_preparation_options(tmp_path, options):
    expert, pseudo = setup_sources(tmp_path)
    with pytest.raises(ValueError):
        alignment.prepare_alignment_dataset(expert, pseudo, tmp_path / "out", **options)
    assert not (tmp_path / "out").exists()


@pytest.mark.parametrize("extra", [
    {"dimension_names": list(reversed(NEW_DIMENSION_NAMES))},
    {"score_values": [1, 2, 3, 4, 5]},
    {"scores": [1, 2, 4]}, {"scores": [0, 2]}, {"scores": [False, 2, 4]},
])
def test_canonical_schema_mismatch_is_not_silently_relabelled(tmp_path, extra):
    invalid = row("invalid")
    invalid.update(extra)
    expert, pseudo = setup_sources(tmp_path, experts=[invalid])
    with pytest.raises(ValueError):
        alignment.prepare_alignment_dataset(expert, pseudo, tmp_path / "out")
    assert not (tmp_path / "out").exists()


def test_csv_canonical_schema_metadata_and_identifier_compatibility(tmp_path):
    expert, _ = setup_sources(tmp_path, experts=[row(f"expert {index}", group_id=index) for index in range(6)])
    pseudo = tmp_path / "pseudo.csv"
    with pseudo.open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=["text", "scores", "dimension_names", "score_values", "group_id", "metadata"])
        writer.writeheader()
        for index in range(8):
            writer.writerow({"text": f"csv {index}", "scores": "[0,2,4]", "dimension_names": json.dumps(NEW_DIMENSION_NAMES),
                             "score_values": json.dumps(DEFAULT_SCORE_VALUES), "group_id": "0" if index == 0 else f"new-{index}",
                             "metadata": '{"source_sheet":"labels"}'})
    output = tmp_path / "prepared"
    report = alignment.prepare_alignment_dataset(expert, pseudo, output)
    assert report["sources"]["pseudo"]["excluded_unique_rows"] == 1
    assert all(record["metadata"] == {"source_sheet": "labels"} for record in all_records(output, "pseudo"))
    alignment.load_alignment_manifest(output)


def test_preparation_is_deterministic_and_replay_capped(tmp_path):
    expert, pseudo = setup_sources(tmp_path)
    out1, out2 = tmp_path / "one", tmp_path / "two"
    alignment.prepare_alignment_dataset(expert, pseudo, out1, replay_max_samples=4)
    alignment.prepare_alignment_dataset(expert, pseudo, out2, replay_max_samples=4)
    for name in alignment.OUTPUT_FILES:
        assert (out1 / name).read_bytes() == (out2 / name).read_bytes()
    assert len(read_rows(out1 / "replay_train.jsonl")) == 4
    first = {name: (out1 / name).read_bytes() for name in alignment.OUTPUT_FILES}
    alignment.prepare_alignment_dataset(expert, pseudo, out1, replay_max_samples=4, overwrite=True)
    assert first == {name: (out1 / name).read_bytes() for name in alignment.OUTPUT_FILES}


def test_group_assignment_independent_of_input_row_order(tmp_path):
    expert, pseudo = setup_sources(tmp_path)
    output = tmp_path / "original"
    alignment.prepare_alignment_dataset(expert, pseudo, output)
    first = {name: {record["text"] for record in read_rows(output / f"{name}.jsonl")} for name in alignment.SPLITS}
    write_rows(expert, list(reversed(read_rows(expert))))
    write_rows(pseudo, list(reversed(read_rows(pseudo))))
    other = tmp_path / "reversed"
    alignment.prepare_alignment_dataset(expert, pseudo, other)
    assert first == {name: {record["text"] for record in read_rows(other / f"{name}.jsonl")} for name in alignment.SPLITS}


def test_overwrite_is_restricted_and_failure_preserves_previous_dataset(tmp_path):
    output, _ = prepare(tmp_path)
    original = {name: (output / name).read_bytes() for name in alignment.OUTPUT_FILES}
    with pytest.raises(FileExistsError):
        alignment.prepare_alignment_dataset(tmp_path / "experts.jsonl", tmp_path / "pseudo.jsonl", output)
    write_rows(tmp_path / "experts.jsonl", [row("conflict"), row("conflict", [8, 8, 8])])
    with pytest.raises(ValueError, match="conflicting expert labels"):
        alignment.prepare_alignment_dataset(tmp_path / "experts.jsonl", tmp_path / "pseudo.jsonl", output, overwrite=True)
    assert original == {name: (output / name).read_bytes() for name in alignment.OUTPUT_FILES}
    (output / "valuable.txt").write_text("unrelated user file")
    with pytest.raises(ValueError, match="complete directory generated"):
        alignment.prepare_alignment_dataset(tmp_path / "experts.jsonl", tmp_path / "pseudo.jsonl", output, overwrite=True)
    assert (output / "valuable.txt").read_text() == "unrelated user file"


def test_output_cannot_contain_input_or_be_symlink(tmp_path):
    expert, pseudo = setup_sources(tmp_path)
    with pytest.raises(ValueError, match="must not contain or replace"):
        alignment.prepare_alignment_dataset(expert, pseudo, tmp_path, overwrite=True)
    real = tmp_path / "real"
    real.mkdir()
    link = tmp_path / "link"
    link.symlink_to(real, target_is_directory=True)
    with pytest.raises(ValueError, match="symbolic link"):
        alignment.prepare_alignment_dataset(expert, pseudo, link, overwrite=True)


def test_input_changed_during_preparation_does_not_publish(tmp_path, monkeypatch):
    expert, pseudo = setup_sources(tmp_path)
    original_writer = alignment._write_split
    changed = False

    def modifying_writer(*args, **kwargs):
        nonlocal changed
        result = original_writer(*args, **kwargs)
        if not changed:
            expert.write_text(expert.read_text() + json.dumps(row("late change")) + "\n")
            changed = True
        return result

    monkeypatch.setattr(alignment, "_write_split", modifying_writer)
    with pytest.raises(ValueError, match="changed during preparation"):
        alignment.prepare_alignment_dataset(expert, pseudo, tmp_path / "out")
    assert not (tmp_path / "out").exists()
    assert not list(tmp_path.glob(".out.staging-*"))


@pytest.mark.parametrize("change,match", [
    (lambda manifest: manifest["files"]["expert_train"].update(path="../experts.jsonl"), "fixed relative path"),
    (lambda manifest: manifest["files"]["expert_train"].update(path="expert_test.jsonl"), "fixed relative path"),
    (lambda manifest: manifest["files"]["expert_train"].update(rows=999), "row count mismatch"),
    (lambda manifest: manifest["files"]["expert_train"].update(label_source="pseudo"), "label_source"),
    (lambda manifest: manifest["files"]["expert_train"].update(score_values=[1, 2, 3, 4, 5]), "split schema"),
    (lambda manifest: manifest["overlap_policy"].update(excludes_all_expert_from_pseudo=False), "removal of all expert"),
])
def test_manifest_rejects_mismatched_paths_roles_counts_and_schema(tmp_path, change, match):
    output, _ = prepare(tmp_path)
    path = output / "alignment_manifest.json"
    manifest = json.loads(path.read_text())
    change(manifest)
    path.write_text(json.dumps(manifest))
    with pytest.raises(ValueError, match=match):
        alignment.load_alignment_manifest(path)


def test_manifest_rejects_same_size_content_changes_and_symlinks(tmp_path):
    output, _ = prepare(tmp_path)
    train = output / "expert_train.jsonl"
    content = train.read_bytes()
    train.write_bytes(content.replace(b"expert ", b"change ", 1))
    assert train.stat().st_size == len(content)
    with pytest.raises(ValueError, match="SHA256 mismatch"):
        alignment.load_alignment_manifest(output)
    train.write_bytes(content)
    elsewhere = tmp_path / "train_copy.jsonl"
    elsewhere.write_bytes(content)
    train.unlink()
    train.symlink_to(elsewhere)
    with pytest.raises(ValueError, match="symbolic link"):
        alignment.load_alignment_manifest(output)


def test_manifest_schema_checks_and_portability_without_original_sources(tmp_path):
    output, _ = prepare(tmp_path)
    with pytest.raises(ValueError, match="dimension_names/order"):
        alignment.load_alignment_manifest(output, expected_dimension_names=list(reversed(NEW_DIMENSION_NAMES)))
    with pytest.raises(ValueError, match="score_values"):
        alignment.load_alignment_manifest(output, expected_score_values=[1, 2, 3, 4, 5])
    (tmp_path / "experts.jsonl").unlink()
    (tmp_path / "pseudo.jsonl").unlink()
    manifest = alignment.load_alignment_manifest(output, expected_dimension_names=NEW_DIMENSION_NAMES, expected_score_values=DEFAULT_SCORE_VALUES)
    assert manifest["files"]["expert_train"]["rows"] > 0


def test_cli_shared_config_and_failure_exit_status(tmp_path):
    expert, pseudo = setup_sources(tmp_path)
    project = Path(__file__).resolve().parents[1]
    config = project / "configs" / "train.yaml"
    arguments = ["--expert-input", str(expert), "--pseudo-input", str(pseudo), "--output-dir", str(tmp_path / "cli"), "--config", str(config)]
    options = options_from_args(build_parser().parse_args(arguments))
    assert options["dimension_names"] == list(NEW_DIMENSION_NAMES)
    assert options["score_values"] == list(DEFAULT_SCORE_VALUES)
    assert options["expert_validation_ratio"] == 0.15  # Not inherited from old data.validation_ratio=.05.
    assert options["overlap_id_column"] is None  # Not inherited from conversion.id_column=row_id.
    result = subprocess.run([sys.executable, str(project / "prepare_alignment_data.py"), *arguments], cwd=project, text=True, capture_output=True)
    assert result.returncode == 0, result.stderr
    summary = json.loads(result.stdout)
    assert summary["expert_unique_rows"] == 12
    manifest = alignment.load_alignment_manifest(tmp_path / "cli")
    assert manifest["inputs"]["config"]["sha256"] == alignment.file_sha256(config)
    result = subprocess.run([sys.executable, str(project / "prepare_alignment_data.py"), *arguments], cwd=project, text=True, capture_output=True)
    assert result.returncode == 2
    assert "not empty" in result.stderr
