"""Integration regression checks for the new three-dimension/six-class task."""

from __future__ import annotations

from copy import deepcopy
import csv
import json
from pathlib import Path
from types import SimpleNamespace

import numpy as np
import pytest
import torch
from datasets import Dataset
from transformers import AutoConfig, AutoTokenizer

import evaluate
import predict
from five_scores.excel import resolve_settings
from five_scores.inference import ScorePredictor
from five_scores.modeling import ModernBertForFiveScores, validate_score_config
from train import build_class_weight_report, count_score_classes


NAMES = ["novelty_score", "demand_score", "quality_score"]
VALUES = [0, 2, 4, 6, 8, 10]


def _template():
    return resolve_settings({
        "model": {"dimension_names": NAMES, "score_values": VALUES},
        "conversion": {
            "text_columns": ["scene_description", "pain_analysis", "solution"],
            "required_text_columns": ["scene_description", "pain_analysis", "solution"],
            "text_labels": {"scene_description": "场景描述", "pain_analysis": "痛点分析", "solution": "解决方案"},
            "id_column": "row_id", "group_column": None, "status_column": None,
            "metadata_columns": [], "accepted_statuses": [], "exclude_all_three": False,
            "header_overrides": {4: {"expected": "novelty_score", "name": "solution"}},
        },
    }).text_template()


def test_training_statistics_count_zero_and_ten_in_six_bins():
    dataset = Dataset.from_dict({"scores": [[0, 0, 10], [10, 2, 8], [0, 4, 10]]})
    counts = count_score_classes(dataset, 3, VALUES)
    assert counts.tolist() == [
        [2, 0, 0, 0, 0, 1],
        [1, 1, 1, 0, 0, 0],
        [0, 0, 0, 0, 1, 2],
    ]
    options = {"dimension_names": NAMES, "score_values": VALUES, "class_weight_mode": "sqrt_inverse"}
    report = build_class_weight_report(counts, options)
    weights = np.asarray(report["weights"])
    assert weights.shape == (3, 6)
    assert np.isfinite(weights).all() and (weights > 0).all()
    np.testing.assert_allclose((counts / 3 * weights).sum(axis=1), 1)
    assert report["absent_training_scores"] == [[2, 4, 6, 8], [6, 8, 10], [0, 2, 4, 6]]
    assert report["score_values"] == VALUES


def test_training_rejects_non_discrete_labels_and_old_manual_weight_shape():
    with pytest.raises(ValueError, match="canonical integer scores"):
        count_score_classes(Dataset.from_dict({"scores": [[0, 1, 10]]}), 3, VALUES)
    with pytest.raises(ValueError, match="canonical integer scores"):
        count_score_classes(Dataset.from_dict({"scores": [[0.0, 2.0, 10.0]]}), 3, VALUES)
    with pytest.raises(ValueError, match="Manual class weights"):
        build_class_weight_report(np.ones((3, 6), dtype=np.int64), {
            "dimension_names": NAMES, "score_values": VALUES,
            "class_weight_mode": "manual", "class_weights": [[1.0] * 5] * 3,
        })


class SixClassPredictor:
    def __init__(self, model_dir=None, **kwargs):
        self.model_dir = Path(model_dir or "model")
        self.dimension_names = list(NAMES)
        self.score_values = list(VALUES)
        self.num_dimensions, self.num_classes, self.max_length = 3, 6, 64
        self.device, self.precision = "cpu", "fp32"
        self.config = SimpleNamespace(score_text_template=_template(), score_exclude_all_three=False)
        self.seen_texts = []

    def predict(self, texts, *, batch_size, include_probabilities, reject_truncation):
        self.seen_texts.extend(texts)
        results = []
        for text in texts:
            scores = [0, 0, 0] if text == "all-zero" else [10, 0, 4]
            row = {
                "scores": dict(zip(NAMES, scores)),
                "max_probabilities": dict.fromkeys(NAMES, 1.0),
                "expected_scores": dict(zip(NAMES, [float(score) for score in scores])),
                "input_tokens": 5, "used_tokens": 5, "truncated": False,
            }
            if include_probabilities:
                row["probabilities"] = {
                    name: [float(value == score) for value in VALUES]
                    for name, score in zip(NAMES, scores)
                }
            results.append(row)
        return results


@pytest.mark.parametrize("extension", ["csv", "jsonl"])
def test_evaluate_retains_zero_labels_and_exports_actual_score_units(tmp_path, monkeypatch, extension):
    source = tmp_path / "input.jsonl"
    rows = [
        {"id": "zero", "text": "all-zero", "scores": [0, 0, 0], "dimension_names": NAMES, "score_values": VALUES},
        {"id": "extremes", "text": "extremes", "scores": [0, 10, 4], "dimension_names": NAMES, "score_values": VALUES},
    ]
    source.write_text("".join(json.dumps(row) + "\n" for row in rows), encoding="utf-8")
    report_path, export_path = tmp_path / "report.json", tmp_path / f"predictions.{extension}"
    predictor = SixClassPredictor(tmp_path / "model")
    monkeypatch.setattr(evaluate, "ScorePredictor", lambda *args, **kwargs: predictor)
    evaluate.main([
        "--model", str(predictor.model_dir), "--data", str(source), "--output", str(report_path),
        "--predictions-output", str(export_path), "--device", "cpu", "--batch-size", "1",
    ])
    report = json.loads(report_path.read_text(encoding="utf-8"))
    assert predictor.seen_texts == ["all-zero", "extremes"]
    assert report["examples"] == 2
    assert report["score_values"] == VALUES
    assert report["data_filtering"]["retained_rows"] == 2
    assert report["data_filtering"]["excluded_all_three"] == 0
    assert report["metrics"]["accuracy"] == pytest.approx(4 / 6)
    assert report["metrics"]["row_exact_match"] == pytest.approx(0.5)
    assert report["metrics"]["mae"] == pytest.approx(20 / 6)
    assert report["metrics"]["mae_steps"] == pytest.approx(10 / 6)
    assert np.asarray(report["confusion_matrices"][NAMES[0]]).shape == (6, 6)
    assert report["confusion_matrices"][NAMES[0]][0][5] == 1
    assert not any("boundary" in name for name in report["metrics"])
    if extension == "csv":
        with export_path.open(encoding="utf-8", newline="") as stream:
            exported = list(csv.DictReader(stream))
        assert exported[0]["gold.novelty_score"] == "0"
        assert exported[1]["gold.demand_score"] == "10"
        assert exported[1]["predicted.novelty_score"] == "10"
        assert exported[1]["absolute_error.novelty_score"] == "10"
        assert json.loads(exported[1]["probabilities.novelty_score"]) == [0, 0, 0, 0, 0, 1]
        assert not any("boundary" in name or "group_mismatch" in name for name in exported[0])
    else:
        exported = [json.loads(line) for line in export_path.read_text(encoding="utf-8").splitlines()]
        assert exported[0]["gold_scores"] == dict.fromkeys(NAMES, 0)
        assert exported[1]["gold_scores"]["demand_score"] == 10
        assert exported[1]["absolute_error"]["novelty_score"] == 10
        assert exported[1]["score_values"] == VALUES
        assert "boundary_violation" not in exported[1]


@pytest.mark.parametrize("standardized", [False, True])
def test_predict_handles_duplicate_raw_header_and_skips_override_for_text_csv(tmp_path, monkeypatch, standardized):
    source, destination = tmp_path / "source.csv", tmp_path / "prediction.csv"
    if standardized:
        header = ["row_id", "text", "scores"]
        values = ["001", "all-zero", "[0,0,0]"]
    else:
        header = ["row_id", "scene_description", "pain_analysis", "novelty_score", *NAMES]
        values = ["001", "场景", "痛点", "解决方法", "0", "0", "0"]
    with source.open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(header)
        writer.writerow(values)
    original_bytes = source.read_bytes()
    predictor = SixClassPredictor(tmp_path / "model")
    monkeypatch.setattr(predict, "predictor_from_args", lambda args: predictor)
    predict.main([
        "--model", str(predictor.model_dir), "--input", str(source), "--output", str(destination),
        "--include-probabilities", "--include-text", "--device", "cpu",
    ])
    with destination.open(encoding="utf-8-sig", newline="") as stream:
        reader = csv.DictReader(stream)
        output_headers, exported = reader.fieldnames, list(reader)
    assert len(exported) == 1
    assert source.read_bytes() == original_bytes
    assert exported[0]["row_id"] == "001"
    if standardized:
        assert predictor.seen_texts == ["all-zero"]
        assert output_headers[:3] == header
        assert exported[0]["pred_novelty_score"] == "0"
    else:
        assert output_headers[:7] == ["row_id", "scene_description", "pain_analysis", "solution", *NAMES]
        assert predictor.seen_texts == ["【场景描述】场景\n【痛点分析】痛点\n【解决方案】解决方法"]
        assert exported[0]["solution"] == "解决方法"
        assert exported[0]["novelty_score"] == "0"
        assert exported[0]["pred_novelty_score"] == "10"
    assert len(json.loads(exported[0]["pred_probabilities_novelty_score"])) == 6


@pytest.mark.parametrize("corruption", ["values", "classes", "names"])
def test_prediction_rejects_template_checkpoint_semantic_mismatch(tmp_path, corruption):
    predictor = SixClassPredictor(tmp_path / "model")
    template = deepcopy(predictor.config.score_text_template)
    if corruption == "values":
        template["score_values"] = [0, 1, 2, 3, 4, 5]
        message = "score_values"
    elif corruption == "classes":
        template["num_classes"] = 5
        message = "num_classes"
    else:
        template["dimension_names"] = list(reversed(NAMES))
        message = "dimension_names"
    predictor.config.score_text_template = template
    args = predict.build_parser().parse_args([
        "--model", str(predictor.model_dir), "--input", "unused.csv", "--output", "unused-output.csv",
    ])
    with pytest.raises(ValueError, match=message):
        predict.prediction_input_settings(args, predictor)


def test_real_six_class_checkpoint_maps_endpoint_logits_to_zero_and_ten(tmp_path, tiny_pretrained):
    config = AutoConfig.from_pretrained(tiny_pretrained / "model", local_files_only=True)
    config.score_dim_names = NAMES
    config.score_values = VALUES
    config.score_num_classes = 6
    config.score_max_length = 64
    config.score_model_version = 4
    config.score_pooling = "mean"
    config.score_dropout = 0
    config.score_text_template = _template()
    config._attn_implementation = "sdpa"
    model = ModernBertForFiveScores(config)
    with torch.no_grad():
        model.classifier.weight.zero_()
        bias = model.classifier.bias.view(3, 6)
        bias.fill_(-20)
        bias[0, 0] = 20
        bias[1, 5] = 20
        bias[2, 2] = 20
    model_dir = tmp_path / "six-class-checkpoint"
    model.save_pretrained(model_dir)
    AutoTokenizer.from_pretrained(tiny_pretrained / "model", local_files_only=True).save_pretrained(model_dir)
    predictor = ScorePredictor(model_dir, device="cpu", precision="fp32")
    result = predictor.predict(["hello world"], include_probabilities=True)[0]
    assert result["scores"] == {"novelty_score": 0, "demand_score": 10, "quality_score": 4}
    assert predictor.score_values == VALUES and predictor.num_classes == 6
    assert result["expected_scores"]["demand_score"] == pytest.approx(10)
    assert all(len(probabilities) == 6 for probabilities in result["probabilities"].values())
    config.score_model_version = 3
    with pytest.raises(ValueError, match="score_model_version=4"):
        validate_score_config(config)
