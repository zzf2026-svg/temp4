"""Validation-only model selection and safe reuse of a pseudo-trained checkpoint."""

from __future__ import annotations

from copy import deepcopy
import json
from pathlib import Path

import numpy as np
import pytest

import compare_alignment as comparison
import run_alignment as runner
from five_scores.alignment_data import load_alignment_manifest, prepare_alignment_dataset
from five_scores.metrics import detailed_score_report
from five_scores.schema import DEFAULT_SCORE_VALUES, NEW_DIMENSION_NAMES


NAMES, VALUES = list(NEW_DIMENSION_NAMES), list(DEFAULT_SCORE_VALUES)


def write_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, allow_nan=False) + "\n", encoding="utf-8")


def records(path, source, count):
    path.write_text("".join(json.dumps({"id": i, "text": f"{source} case {i}",
        "scores": [VALUES[(i + index) % 6] for index in range(3)],
        "dimension_names": NAMES, "score_values": VALUES}) + "\n" for i in range(count)), encoding="utf-8")


@pytest.fixture
def options(tmp_path):
    model = tmp_path / "backbone"
    write_json(model / "config.json", {"model_type": "modernbert"})
    (model / "model.safetensors").write_bytes(b"planning-only weights")
    expert, pseudo = tmp_path / "experts.jsonl", tmp_path / "pseudo.jsonl"
    records(expert, "expert", 24)
    records(pseudo, "pseudo", 40)
    prepared = tmp_path / "prepared"
    prepare_alignment_dataset(expert, pseudo, prepared, replay_max_samples=8)
    base = tmp_path / "base.json"
    write_json(base, {"model": {"name_or_path": str(model)},
                     "data": {"max_length": 32, "num_proc": 1},
                     "training": {"use_cpu": True, "precision": "fp32", "tf32": False,
                                  "max_steps": 1, "dataloader_num_workers": 0}})
    config = tmp_path / "alignment.json"
    write_json(config, {"base_config": str(base), "expert": {"training": {"max_steps": 1}}})
    return runner.parse_args(["--config", str(config), "--data-dir", str(prepared),
                              "--output-dir", str(tmp_path / "run"), "--cpu"])


def edit_json(path, mutate):
    value = json.loads(Path(path).read_text())
    mutate(value)
    write_json(Path(path), value)


def scoring_checkpoint(path, prepared, *, verified=True):
    write_json(path / "config.json", {"model_type": "modernbert", "score_dim_names": NAMES,
               "score_values": VALUES, "score_pooling": "mean", "score_max_length": 32})
    (path / "model.safetensors").write_bytes(b"scoring weights")
    if verified:
        write_json(path / "provenance.json", {"training_stage": "pseudo", "replay_weight": 0.0,
                   "data_files": {"train": {"sha256": prepared["files"]["pseudo_train"]["sha256"]},
                                  "validation": {"sha256": prepared["files"]["pseudo_validation"]["sha256"]}, "replay": None}})
        identity = comparison.checkpoint_identity(path)
        write_json(path / runner.PROVENANCE_FILE, {"schema_version": 1, "stage": "pseudo_pretraining",
                   "dataset_fingerprint": runner.dataset_fingerprint(prepared), "model_sha256": identity["sha256"],
                   "training_provenance_sha256": runner.file_sha256(path / "provenance.json")})
    return path


def test_staged_separates_data_sources_and_defaults_to_frozen_expert_head(options):
    manifest, configs = runner.build_plan(options)
    assert manifest["candidate_names"] == ["baseline", "adapted"]
    assert configs["stage1"]["training"]["stage"] == "pseudo"
    assert configs["expert"]["training"]["stage"] == "expert"
    assert configs["stage1"]["data"]["validation_file"].endswith("pseudo_validation.jsonl")
    assert configs["expert"]["data"]["validation_file"].endswith("expert_validation.jsonl")
    assert configs["expert"]["training"]["freeze_backbone"] is True
    assert configs["stage1"]["training"]["freeze_backbone"] is False
    assert configs["expert"]["training"]["replay_weight"] == 0
    assert configs["expert"]["data"]["replay_file"] is None
    assert configs["expert"]["model"]["name_or_path"] == str(Path(options.output_dir) / "stage1" / "final")
    assert configs["expert"]["training"]["resume_from_checkpoint"] is None
    assert configs["expert"]["training"]["metric_for_best_model"] == "accuracy"
    assert manifest["evaluate_test"] is False


def test_replay_is_only_enabled_for_staged_replay(options):
    options.method = "staged_replay"
    _, configs = runner.build_plan(options)
    assert configs["expert"]["training"]["replay_weight"] == pytest.approx(0.1)
    assert configs["expert"]["data"]["replay_file"].endswith("replay_train.jsonl")
    assert configs["stage1"]["data"]["replay_file"] is None
    options.method = "expert_only"
    manifest, configs = runner.build_plan(options)
    assert list(configs) == ["expert"]
    assert manifest["candidate_names"] == ["expert_only"]
    assert configs["expert"]["training"]["replay_weight"] == 0
    assert configs["expert"]["model"]["name_or_path"].endswith("backbone")


@pytest.mark.parametrize("key,value", [("max_train_samples", 3), ("max_eval_samples", 3)])
def test_subsampling_cannot_change_validation_or_source_provenance(options, key, value):
    edit_json(options.config, lambda cfg: cfg["expert"].update({"data": {key: value}}))
    with pytest.raises(ValueError, match="full prepared splits"):
        runner.build_plan(options)


def test_rejects_resume_unknown_options_and_unsupported_schema(options):
    edit_json(options.config, lambda cfg: cfg["expert"]["training"].update(resume_from_checkpoint="old/checkpoint-1"))
    with pytest.raises(ValueError, match="new runs"):
        runner.build_plan(options)
    edit_json(options.config, lambda cfg: cfg["expert"].update(training={"does_not_exist": True}))
    with pytest.raises(ValueError, match="Unknown training"):
        runner.build_plan(options)
    edit_json(options.config, lambda cfg: cfg["expert"].update(training={}, model={"score_values": [1, 2, 3, 4, 5]}))
    with pytest.raises(ValueError, match="must match"):
        runner.build_plan(options)


def test_existing_output_is_never_silently_reused(options):
    Path(options.output_dir).mkdir()
    (Path(options.output_dir) / "important.txt").write_text("keep")
    with pytest.raises(FileExistsError, match="new or empty"):
        runner.build_plan(options)
    assert (Path(options.output_dir) / "important.txt").read_text() == "keep"


def test_existing_source_requires_matching_provenance_or_explicit_opt_in(options, tmp_path):
    prepared = load_alignment_manifest(options.data_dir)
    source = scoring_checkpoint(tmp_path / "existing", prepared, verified=False)
    options.source_model = str(source)
    with pytest.raises(ValueError, match="Cannot verify"):
        runner.build_plan(options)
    options.allow_unverified_source = True
    manifest, configs = runner.build_plan(options)
    assert manifest["source_verification"]["status"] == "unverified"
    assert list(configs) == ["expert"]
    assert configs["expert"]["model"]["name_or_path"] == str(source)
    edit_json(source / "config.json", lambda cfg: cfg.update(score_values=[1, 2, 3, 4, 5]))
    with pytest.raises(ValueError, match="score_values"):
        runner.build_plan(options)


def test_verified_stage1_reuse_skips_pseudo_training_and_rejects_changed_weights(options, tmp_path):
    prepared = load_alignment_manifest(options.data_dir)
    source = scoring_checkpoint(tmp_path / "source", prepared)
    options.source_model = str(source)
    manifest, configs = runner.build_plan(options)
    assert manifest["source_verification"]["status"] == "verified"
    assert list(configs) == ["expert"]
    (source / "model.safetensors").write_bytes(b"different weights")
    with pytest.raises(ValueError, match="serving files differ"):
        runner.build_plan(options)


def test_source_reuse_requires_same_expert_partition_not_just_pseudo_hashes(options, tmp_path):
    prepared = load_alignment_manifest(options.data_dir)
    source = scoring_checkpoint(tmp_path / "source", prepared)
    changed = deepcopy(prepared)
    changed["files"]["expert_test"]["sha256"] = "0" * 64
    with pytest.raises(ValueError, match="dataset fingerprint"):
        runner.verify_source_checkpoint(source, changed, allow_unverified=False)


def test_text_template_is_attached_to_both_stages(options, tmp_path):
    template = tmp_path / "template.json"
    write_json(template, {"dimension_names": NAMES, "score_values": VALUES, "num_classes": 6})
    options.text_template_file = str(template)
    manifest, configs = runner.build_plan(options)
    assert all(config["data"]["text_template_file"] == str(template) for config in configs.values())
    assert manifest["text_templates"][str(template)] == runner.file_sha256(template)


def test_baseline_selection_cannot_change_saved_inference_length(options, tmp_path):
    edit_json(options.config, lambda cfg: cfg["expert"].update(data={"max_length": 64}))
    with pytest.raises(ValueError, match="same max_length"):
        runner.build_plan(options)
    prepared = load_alignment_manifest(options.data_dir)
    source = scoring_checkpoint(tmp_path / "source", prepared)
    options.source_model = str(source)
    with pytest.raises(ValueError, match="score_max_length"):
        runner.build_plan(options)


def test_dry_run_does_not_download_or_write(options, monkeypatch, capsys):
    import huggingface_hub

    def forbidden(*args, **kwargs):
        raise AssertionError("dry-run attempted to download")

    monkeypatch.setattr(huggingface_hub.HfApi, "model_info", forbidden)
    monkeypatch.setattr(huggingface_hub, "snapshot_download", forbidden)
    runner.main(["--config", options.config, "--data-dir", options.data_dir, "--output-dir", options.output_dir,
                 "--model", "organization/mmbert", "--cpu", "--dry-run"])
    report = json.loads(capsys.readouterr().out)
    assert report["dry_run"] is True
    assert report["manifest"]["source_identity"]["kind"] == "hub_plan"
    assert not Path(options.output_dir).exists()


def test_selection_uses_secondary_then_baseline_fallback():
    candidates = [
        {"candidate": "baseline", "accuracy": .8, "row_exact_match": .5},
        {"candidate": "adapted", "accuracy": .8, "row_exact_match": .5},
    ]
    assert comparison.choose_candidate(candidates, {})["candidate"] == "baseline"
    candidates[1]["row_exact_match"] = .6
    assert comparison.choose_candidate(candidates, {})["candidate"] == "adapted"
    candidates[1]["accuracy"] = .7
    assert comparison.choose_candidate(candidates, {})["candidate"] == "baseline"
    with pytest.raises(ValueError, match="selection.metric"):
        comparison.choose_candidate(candidates, {"metric": "test_accuracy"})


def fake_subprocesses(monkeypatch):
    commands = []

    def fake(command, log):
        commands.append(command)
        script = Path(command[1]).name
        get = lambda key: command[command.index(key) + 1]
        if script == "train.py":
            config = runner.load_config(get("--config"))
            final = Path(config["training"]["output_dir"]) / "final"
            write_json(final / "config.json", {"model_type": "modernbert", "score_dim_names": NAMES,
                       "score_values": VALUES, "score_pooling": "mean", "score_max_length": config["data"]["max_length"]})
            (final / "model.safetensors").write_bytes(config["training"]["stage"].encode())
            write_json(final / "training_summary.json", {"global_step": 1})
            write_json(final / "provenance.json", {"training_stage": config["training"]["stage"],
                       "replay_weight": config["training"]["replay_weight"], "data_files": {
                           key: ({"sha256": runner.file_sha256(Path(config["data"][file_key]))} if config["data"][file_key] else None)
                           for key, file_key in (("train", "train_file"), ("validation", "validation_file"), ("replay", "replay_file"))}})
        elif script == "evaluate.py":
            source, model = Path(get("--data")), Path(get("--model"))
            rows = [json.loads(line) for line in source.read_text().splitlines() if line.strip()]
            labels = np.array([[VALUES.index(score) for score in row["scores"]] for row in rows])
            predicted = labels if model.parent.name == "stage1" else (labels + 1) % 6
            report = {"model": str(model), "input_sha256": runner.file_sha256(source), "evaluated_data_sha256": "f" * 64,
                      "model_config_sha256": runner.file_sha256(model / "config.json"), "examples": len(rows),
                      "dimensions": NAMES, "num_dimensions": 3, "num_classes": 6, "score_values": VALUES,
                      "input_schema": {"text_column": "text", "scores_column": "scores", "score_columns": None, "exclude_all_three": False},
                      "max_length": int(get("--max-length")), "precision": get("--precision"),
                      "batch_size": int(get("--batch-size")), "attn_implementation": get("--attn-implementation"),
                      **detailed_score_report(labels, predicted, NAMES, score_values=VALUES)}
            write_json(Path(get("--output")), report)
            write_json(Path(get("--predictions-output")), {"smoke": True})

    monkeypatch.setattr(runner, "run_logged", fake)
    return commands


@pytest.mark.parametrize("evaluate_test", [False, True])
def test_pipeline_baseline_fallback_never_selects_on_test(options, monkeypatch, evaluate_test):
    options.evaluate_test = evaluate_test
    commands = fake_subprocesses(monkeypatch)
    manifest, configs = runner.build_plan(options)
    runner.initialize_pipeline(manifest, configs)
    result = runner.execute_pipeline(manifest, configs)
    assert result["selected_model"]["candidate"] == "baseline"
    assert result["selected_model"]["selection_split"] == "expert_validation"
    assert result["selected_model"]["model_path"].endswith("stage1/final")
    assert result["test_used_for_selection"] is False
    eval_commands = [cmd for cmd in commands if Path(cmd[1]).name == "evaluate.py"]
    assert len(eval_commands) == 2 + int(evaluate_test)
    assert sum(cmd[cmd.index("--data") + 1].endswith("expert_test.jsonl") for cmd in eval_commands) == int(evaluate_test)
    if evaluate_test:
        assert eval_commands[-1][eval_commands[-1].index("--model") + 1].endswith("stage1/final")
        # Test report content has no effect on regeneration of selection.
        write_json(Path(options.output_dir) / "expert_test_metrics.json", {"not_a_metric": "ignored"})
        assert comparison.summarize_alignment([options.output_dir])["selected_model"]["candidate"] == "baseline"
    state = comparison.read_json(Path(options.output_dir) / "pipeline_state.json")
    assert state["status"] == "complete"
    prepared = load_alignment_manifest(options.data_dir)
    _, verification = runner.verify_source_checkpoint(Path(options.output_dir) / "stage1" / "final", prepared, allow_unverified=False)
    assert verification["status"] == "verified"


def test_comparison_rejects_checkpoint_or_report_drift(options, monkeypatch):
    fake_subprocesses(monkeypatch)
    manifest, configs = runner.build_plan(options)
    runner.initialize_pipeline(manifest, configs)
    runner.execute_pipeline(manifest, configs)
    source = Path(options.output_dir) / "stage1" / "final" / "model.safetensors"
    source.write_bytes(b"changed after validation")
    with pytest.raises(ValueError, match="changed after evaluation"):
        comparison.summarize_alignment([options.output_dir])


def test_cross_method_comparison_requires_identical_expert_train_and_test_splits(options, monkeypatch, tmp_path):
    fake_subprocesses(monkeypatch)
    manifest, configs = runner.build_plan(options)
    runner.initialize_pipeline(manifest, configs)
    runner.execute_pipeline(manifest, configs)
    other = tmp_path / "another_run"
    changed = deepcopy(manifest)
    changed["dataset_fingerprint"] = "0" * 64
    changed["pipeline_signature"] = runner.value_sha256({key: value for key, value in changed.items() if key != "pipeline_signature"})
    write_json(other / "pipeline_manifest.json", changed)
    with pytest.raises(ValueError, match="identical expert train/validation/test"):
        comparison.summarize_alignment([options.output_dir, other], output_dir=tmp_path / "combined")
