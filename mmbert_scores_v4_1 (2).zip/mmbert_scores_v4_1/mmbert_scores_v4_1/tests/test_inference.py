"""Verify the saved-checkpoint inference contract without a GPU or network."""

from __future__ import annotations

import json

import pytest
from transformers import AutoTokenizer

from five_scores.inference import ScorePredictor
from five_scores.modeling import ModernBertForFiveScores


@pytest.fixture
def scored_checkpoint(tmp_path, tiny_pretrained, tiny_config):
    checkpoint = tmp_path / "scorer"
    ModernBertForFiveScores(tiny_config).save_pretrained(checkpoint, safe_serialization=True)
    tokenizer = AutoTokenizer.from_pretrained(tiny_pretrained / "model", local_files_only=True)
    tokenizer.save_pretrained(checkpoint)
    return checkpoint


@pytest.mark.parametrize("tiny_config", [5, 7], indirect=True)
@pytest.mark.parametrize("checkpoint_version", [2, 3])
def test_saved_model_returns_dynamic_normalized_score_distributions(scored_checkpoint, tiny_config, checkpoint_version):
    config_path = scored_checkpoint / "config.json"
    saved = json.loads(config_path.read_text(encoding="utf-8"))
    saved["score_model_version"] = checkpoint_version
    saved["score_boundary_weight"] = 0.2 if checkpoint_version == 3 else 0.0
    config_path.write_text(json.dumps(saved), encoding="utf-8")
    predictor = ScorePredictor(scored_checkpoint, device="cpu", precision="auto")
    assert predictor.config.score_model_version == checkpoint_version
    assert predictor.num_dimensions == len(tiny_config.score_dim_names)
    assert predictor.num_classes == 5
    texts = ["hello world", "这 是 一个 清晰 回答", "需要 改善 内容"]
    output = predictor.predict(texts, batch_size=2, include_probabilities=True)
    assert len(output) == len(texts)
    for row in output:
        assert list(row["scores"]) == tiny_config.score_dim_names
        assert row["truncated"] is False
        assert row["input_tokens"] == row["used_tokens"]
        for dimension in tiny_config.score_dim_names:
            probabilities = row["probabilities"][dimension]
            assert len(probabilities) == 5
            assert sum(probabilities) == pytest.approx(1.0, abs=1e-6)
            assert all(0 <= value <= 1 for value in probabilities)
            assert type(row["scores"][dimension]) is int
            assert row["scores"][dimension] == max(range(5), key=probabilities.__getitem__) + 1
            assert row["expected_scores"][dimension] == pytest.approx(
                sum((index + 1) * p for index, p in enumerate(probabilities)), abs=1e-5
            )
            assert row["max_probabilities"][dimension] == pytest.approx(max(probabilities), abs=1e-6)
    assert predictor.predict([]) == []


def test_truncation_is_visible_and_can_be_rejected(scored_checkpoint):
    predictor = ScorePredictor(scored_checkpoint, device="cpu", max_length=16)
    long_text = "hello " * 40
    row = predictor.predict([long_text])[0]
    assert row["truncated"] is True
    assert row["input_tokens"] > 16
    assert row["used_tokens"] <= 16
    with pytest.raises(ValueError):
        predictor.predict([long_text], reject_truncation=True)


@pytest.mark.parametrize("texts", [[""], ["   "], [None], [123], "hello"])
def test_invalid_text_batch_is_rejected(scored_checkpoint, texts):
    predictor = ScorePredictor(scored_checkpoint, device="cpu")
    with pytest.raises((ValueError, TypeError)):
        predictor.predict(texts)


def test_refuses_mlm_checkpoint_without_a_trained_scoring_head(tiny_pretrained):
    with pytest.raises(ValueError):
        ScorePredictor(tiny_pretrained / "model", device="cpu")


def test_refuses_inference_length_larger_than_backbone_context(scored_checkpoint):
    with pytest.raises(ValueError):
        ScorePredictor(scored_checkpoint, device="cpu", max_length=129)


def test_refuses_missing_scoring_head_even_with_valid_metadata(scored_checkpoint):
    from safetensors.torch import load_file, save_file

    weights_path = scored_checkpoint / "model.safetensors"
    weights = load_file(weights_path)
    del weights["classifier.weight"]
    del weights["classifier.bias"]
    save_file(weights, weights_path, metadata={"format": "pt"})
    with pytest.raises(ValueError, match="missing_keys"):
        ScorePredictor(scored_checkpoint, device="cpu")


@pytest.mark.parametrize("field,value", [
    ("score_num_dimensions", 5),
    ("score_num_classes", 7),
    ("score_dim_weights", [1.0] * 5),
    ("score_dim_names", ["duplicate"] * 7),
    ("score_model_version", 99),
])
def test_refuses_corrupt_dimension_metadata(scored_checkpoint, field, value):
    path = scored_checkpoint / "config.json"
    config = json.loads(path.read_text(encoding="utf-8"))
    config[field] = value
    path.write_text(json.dumps(config), encoding="utf-8")
    with pytest.raises(ValueError):
        ScorePredictor(scored_checkpoint, device="cpu")


@pytest.mark.parametrize("tiny_config", [5], indirect=True)
def test_legacy_five_dimensional_inference(scored_checkpoint, tiny_config):
    path = scored_checkpoint / "config.json"
    config = json.loads(path.read_text(encoding="utf-8"))
    config["score_model_version"] = 1
    path.write_text(json.dumps(config), encoding="utf-8")
    predictor = ScorePredictor(scored_checkpoint, device="cpu")
    result = predictor.predict(["hello world"])[0]
    assert predictor.num_dimensions == 5
    assert list(result["scores"]) == tiny_config.score_dim_names


def test_http_service_loads_checkpoint_and_validates_requests(scored_checkpoint, tiny_config, monkeypatch):
    from fastapi.testclient import TestClient
    import serve

    monkeypatch.setenv("MODEL_DIR", str(scored_checkpoint))
    monkeypatch.setenv("DEVICE", "cpu")
    monkeypatch.setenv("DTYPE", "fp32")
    monkeypatch.setenv("MAX_REQUEST_TEXTS", "2")
    with TestClient(serve.app) as client:
        health = client.get("/health")
        assert health.status_code == 200
        assert health.json()["dimensions"] == tiny_config.score_dim_names
        response = client.post("/predict", json={"texts": ["hello world"], "include_probabilities": True})
        assert response.status_code == 200
        body = response.json()
        assert body["dimensions"] == tiny_config.score_dim_names
        assert len(body["predictions"]) == 1
        assert len(body["predictions"][0]["scores"]) == len(tiny_config.score_dim_names)
        for payload in (
            {"texts": []},
            {"texts": [123]},
            {"texts": [" "]},
            {"texts": ["hello"], "unknown": 1},
            {"texts": ["hello"] * 3},
        ):
            assert client.post("/predict", json=payload).status_code == 422
