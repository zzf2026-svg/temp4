"""The suite must compare identical inputs and survive interruptions without mixing runs."""

from __future__ import annotations

from copy import deepcopy
import json
from pathlib import Path

import pytest
import yaml

import run_experiments as runner
from five_scores.schema import DEFAULT_DIMENSION_NAMES, LEGACY_SCORE_VALUES


@pytest.fixture
def suite_options(tmp_path):
    model = tmp_path / "original backbone"
    model.mkdir()
    (model / "config.json").write_text(json.dumps({"model_type": "modernbert"}), encoding="utf-8")
    (model / "model.safetensors").write_bytes(b"placeholder weights for planning only")
    train, validation = tmp_path / "train.jsonl", tmp_path / "validation.jsonl"
    train.write_text('{"text":"training","scores":[1,2,3,4,5,4,3]}\n', encoding="utf-8")
    validation.write_text('{"text":"held out","scores":[5,4,3,2,1,2,3]}\n', encoding="utf-8")
    config = tmp_path / "base.yaml"
    config.write_text(yaml.safe_dump({
        "model": {"name_or_path": str(model), "dimension_names": list(DEFAULT_DIMENSION_NAMES),
                  "score_values": list(LEGACY_SCORE_VALUES), "boundary_weight": 0.2},
        "data": {"train_file": str(train), "validation_file": str(validation), "exclude_all_three": True},
        "training": {"seed": 17, "num_train_epochs": 3, "early_stopping_patience": 2},
    }), encoding="utf-8")
    return runner.parse_args(["--base-config", str(config), "--output-dir", str(tmp_path / "suite")])


def test_experiments_share_every_setting_except_intended_loss_and_output(suite_options):
    manifest, configs = runner.build_plan(suite_options)
    assert [(entry["name"], entry["boundary_weight"], entry["class_weight_mode"]) for entry in manifest["experiments"]] == [
        ("baseline", 0.2, "none"), ("weighted", 0.2, "sqrt_inverse"), ("ce", 0.0, "none"),
    ]
    normalized = []
    for config in configs.values():
        assert config["training"]["early_stopping_patience"] == 0
        assert config["training"]["seed"] == 17
        assert config["training"]["num_train_epochs"] == 3
        assert config["training"]["greater_is_better"] is True
        assert config["data"]["exclude_all_three"] is True
        assert config["data"]["max_eval_samples"] is None
        value = deepcopy(config)
        for key in ("boundary_weight", "class_weight_mode"):
            value["model"].pop(key)
        value["training"].pop("output_dir")
        normalized.append(value)
    assert normalized[0] == normalized[1] == normalized[2]
    assert manifest["data"]["validation"]["path"] == configs["baseline"]["data"]["validation_file"]


def test_runner_rejects_different_selection_and_export_validation_populations(suite_options):
    suite_options.max_eval_samples = 1
    with pytest.raises(ValueError, match="identical full validation"):
        runner.build_plan(suite_options)


def test_explicit_epochs_override_saved_step_budget(suite_options):
    path = Path(suite_options.base_config)
    config = yaml.safe_load(path.read_text())
    config["training"]["max_steps"] = 50
    path.write_text(yaml.safe_dump(config))
    suite_options.epochs = 2
    _, generated = runner.build_plan(suite_options)
    assert generated["baseline"]["training"]["max_steps"] == -1
    suite_options.max_steps = 20
    with pytest.raises(ValueError, match="not both"):
        runner.build_plan(suite_options)


def test_dry_run_does_not_create_files_or_fetch_hub(suite_options, monkeypatch, capsys):
    import huggingface_hub
    import torch

    def unexpected_network(*args, **kwargs):
        raise AssertionError("dry-run must not download or resolve a Hub revision")

    monkeypatch.setattr(huggingface_hub.HfApi, "model_info", unexpected_network)
    monkeypatch.setattr(huggingface_hub, "snapshot_download", unexpected_network)
    monkeypatch.setattr(torch.cuda, "device_count", unexpected_network)
    runner.main([
        "--base-config", suite_options.base_config, "--output-dir", suite_options.output_dir,
        "--model", "organization/backbone", "--dry-run",
    ])
    result = json.loads(capsys.readouterr().out)
    assert result["dry_run"] is True
    assert len(result["commands"]) == 3
    assert not Path(suite_options.output_dir).exists()


def test_resume_rejects_changed_inputs_and_generated_configs(suite_options):
    manifest, configs = runner.build_plan(suite_options)
    output = Path(suite_options.output_dir)
    runner.initialize_suite(output, manifest, configs, resume=False)
    runner.initialize_suite(output, manifest, configs, resume=True)
    with pytest.raises(FileExistsError, match="Suite already exists"):
        runner.initialize_suite(output, manifest, configs, resume=False)
    source = Path(manifest["data"]["train"]["path"])
    source.write_text(source.read_text() + '\n')
    changed, changed_configs = runner.build_plan(suite_options)
    with pytest.raises(ValueError, match="fingerprint changed"):
        runner.initialize_suite(output, changed, changed_configs, resume=True)
    with pytest.raises(ValueError, match="Input changed"):
        runner.assert_inputs_unchanged(manifest)
    generated = Path(manifest["experiments"][0]["config_path"])
    altered = deepcopy(configs["baseline"])
    altered["training"]["learning_rate"] *= 2
    generated.write_text(yaml.safe_dump(altered))
    with pytest.raises(ValueError, match="config changed"):
        runner.initialize_suite(output, manifest, configs, resume=True)


def test_old_scoring_model_is_not_implicitly_reused_as_backbone(suite_options):
    base = yaml.safe_load(Path(suite_options.base_config).read_text())
    config_path = Path(base["model"]["name_or_path"]) / "config.json"
    config_path.write_text(json.dumps({"model_type": "modernbert", "score_dim_names": ["a"]}))
    with pytest.raises(ValueError, match="trained scoring checkpoint"):
        runner.build_plan(suite_options)


def test_suite_output_cannot_be_nested_in_backbone(suite_options):
    base = yaml.safe_load(Path(suite_options.base_config).read_text())
    suite_options.output_dir = str(Path(base["model"]["name_or_path"]) / "experiments")
    with pytest.raises(ValueError, match="must not contain one another"):
        runner.build_plan(suite_options)


def test_completed_runs_skip_training_and_eval_but_changed_artifacts_fail(suite_options, monkeypatch):
    manifest, configs = runner.build_plan(suite_options)
    output = Path(suite_options.output_dir)
    runner.initialize_suite(output, manifest, configs, resume=False)
    commands = []

    def fake_child(command, logfile):
        commands.append(command)
        script = Path(command[1]).name
        if script == "train.py":
            config = runner.load_config(command[command.index("--config") + 1])
            final = Path(config["training"]["output_dir"]) / "final"
            final.mkdir(parents=True)
            for name in ("training_summary.json", "config.json", "model.safetensors"):
                (final / name).write_text("{}")
        elif script == "evaluate.py":
            for option in ("--output", "--predictions-output"):
                Path(command[command.index(option) + 1]).write_text("{}")

    monkeypatch.setattr(runner, "run_logged", fake_child)
    runner.execute_suite(manifest, configs, resume=False)
    assert sum(Path(command[1]).name == "train.py" for command in commands) == 3
    assert sum(Path(command[1]).name == "evaluate.py" for command in commands) == 3
    for command in commands:
        if Path(command[1]).name == "evaluate.py":
            assert command[command.index("--data") + 1] == manifest["data"]["validation"]["path"]
    commands.clear()
    runner.execute_suite(manifest, configs, resume=True)
    assert [Path(command[1]).name for command in commands] == ["compare_experiments.py"]
    (output / "weighted" / "validation_metrics.json").write_text("changed")
    with pytest.raises(ValueError, match="Completed run output changed"):
        runner.execute_suite(manifest, configs, resume=True)


def test_failed_evaluation_retries_without_retraining(suite_options, monkeypatch):
    suite_options.experiments = ["baseline"]
    manifest, configs = runner.build_plan(suite_options)
    output = Path(suite_options.output_dir)
    runner.initialize_suite(output, manifest, configs, resume=False)
    commands = []
    fail = True

    def fake_child(command, logfile):
        nonlocal fail
        commands.append(command)
        script = Path(command[1]).name
        if script == "train.py":
            final = output / "baseline" / "final"
            final.mkdir(parents=True)
            for name in ("training_summary.json", "config.json", "model.safetensors"):
                (final / name).write_text("{}")
        elif script == "evaluate.py":
            if fail:
                fail = False
                Path(command[command.index("--predictions-output") + 1]).write_text("partial")
                raise RuntimeError("interrupted evaluation")
            assert "--overwrite" in command
            for option in ("--output", "--predictions-output"):
                Path(command[command.index(option) + 1]).write_text("{}")

    monkeypatch.setattr(runner, "run_logged", fake_child)
    with pytest.raises(RuntimeError, match="interrupted evaluation"):
        runner.execute_suite(manifest, configs, resume=False)
    runner.execute_suite(manifest, configs, resume=True)
    assert sum(Path(command[1]).name == "train.py" for command in commands) == 1
    assert sum(Path(command[1]).name == "evaluate.py" for command in commands) == 2


def test_checkpoint_search_ignores_incomplete_latest_save(tmp_path):
    for step in (10, 20):
        directory = tmp_path / f"checkpoint-{step}"
        directory.mkdir()
        names = ["trainer_state.json", "optimizer.pt", "scheduler.pt", "config.json", "model.safetensors"]
        if step == 10:
            names.append("rng_state.pth")
        for name in names:
            (directory / name).write_text("{}")
    assert runner.latest_complete_checkpoint(tmp_path).name == "checkpoint-10"


def test_runner_rejects_torchrun_launch(suite_options, monkeypatch):
    monkeypatch.setenv("LOCAL_RANK", "0")
    with pytest.raises(ValueError, match="not torchrun"):
        runner.main(["--base-config", suite_options.base_config, "--dry-run"])


@pytest.mark.parametrize("visible", [0, 2])
def test_gpu_execution_rejects_zero_or_multiple_visible_devices(monkeypatch, visible):
    import torch

    monkeypatch.setattr(torch.cuda, "device_count", lambda: visible)
    with pytest.raises(RuntimeError, match="CUDA_VISIBLE_DEVICES"):
        runner.validate_execution_device({"training": {"use_cpu": False}})


def test_single_gpu_and_cpu_execution_are_allowed(monkeypatch):
    import torch

    monkeypatch.setattr(torch.cuda, "device_count", lambda: 1)
    runner.validate_execution_device({"training": {"use_cpu": False}})

    def unexpected_cuda_probe():
        raise AssertionError("CPU mode must not probe CUDA")

    monkeypatch.setattr(torch.cuda, "device_count", unexpected_cuda_probe)
    runner.validate_execution_device({"training": {"use_cpu": True}})
