"""The all-3 sentinel is removed only from labeled data, with counted rows."""

from __future__ import annotations

import csv
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest

from five_scores.data import is_failed_teacher_scores, iter_labeled_records, load_labeled_dataset
from prepare_data import prepare_dataset


class FailedTeacherLabelTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name)

    def write_jsonl(self, rows):
        path = self.root / "labels.jsonl"
        path.write_text("".join(json.dumps(row) + "\n" for row in rows), encoding="utf-8")
        return path

    def test_iterator_preserves_sources_and_some_three_scores(self):
        rows = [
            {"id": "failed", "text": "failed input", "scores": [3] * 7},
            {"id": "valid", "text": "valid input", "scores": [4, 3, 4, 4, 3, 3, 3]},
            {"id": "mostly-three", "text": "another input", "scores": [3, 3, 3, 3, 3, 3, 2]},
        ]
        source = self.write_jsonl(rows)
        report = {}
        output = list(iter_labeled_records(source, filter_report=report))
        self.assertEqual([item[0] for item in output], [2, 3])
        self.assertEqual([item[1] for item in output], rows[1:])
        self.assertEqual(output[0][2], {"text": rows[1]["text"], "scores": rows[1]["scores"]})
        self.assertEqual((report["input_rows"], report["excluded_all_three"], report["retained_rows"]), (3, 1, 2))

    def test_filter_tracks_configured_dimension_count_and_has_explicit_override(self):
        for dimensions in (1, 2, 5, 7):
            with self.subTest(dimensions=dimensions):
                source = self.write_jsonl([{"text": "failed", "scores": [3] * dimensions}])
                report = {}
                with self.assertRaisesRegex(ValueError, "no valid labeled rows"):
                    list(iter_labeled_records(source, num_dimensions=dimensions, filter_report=report))
                self.assertEqual(report["excluded_all_three"], 1)
                retained = list(iter_labeled_records(source, num_dimensions=dimensions, exclude_all_three=False))
                self.assertEqual(retained[0][2]["scores"], [3] * dimensions)
        self.assertFalse(is_failed_teacher_scores([]))

    def test_standardized_csv_scalar_labels_apply_identical_filter(self):
        source = self.root / "labels.csv"
        with source.open("w", encoding="utf-8-sig", newline="") as output:
            writer = csv.DictWriter(output, fieldnames=["id", "text", "a", "b"])
            writer.writeheader()
            writer.writerows([
                {"id": "001", "text": "bad", "a": "3", "b": "3"},
                {"id": "002", "text": "good", "a": "3", "b": "4"},
            ])
        rows = list(iter_labeled_records(source, dimension_names=["first", "second"], score_columns=["a", "b"]))
        self.assertEqual(rows[0][1]["id"], "002")
        self.assertEqual(rows[0][2]["scores"], [3, 4])

    def test_prepare_filters_before_split_and_records_counts(self):
        source = self.write_jsonl([
            {"text": "failed", "scores": [3, 3]},
            {"text": "valid", "scores": [3, 4], "id": "002"},
        ])
        destination = self.root / "prepared"
        report = prepare_dataset(source, destination, num_dimensions=2, validation_ratio=0, test_ratio=0)
        self.assertEqual((report["input_rows"], report["excluded_all_three"], report["retained_rows"], report["unique_rows"]), (2, 1, 1, 1))
        rows = [json.loads(line) for line in (destination / "train.jsonl").read_text().splitlines()]
        self.assertEqual([row["id"] for row in rows], ["002"])
        self.write_jsonl([{"text": "failed", "scores": [3, 3]}])
        with self.assertRaisesRegex(ValueError, "No valid labeled rows"):
            prepare_dataset(source, self.root / "empty", num_dimensions=2, validation_ratio=0, test_ratio=0)
        self.assertFalse((self.root / "empty").exists())

    @unittest.skipUnless(importlib.util.find_spec("datasets"), "datasets not installed")
    def test_arrow_loader_and_cache_report_the_same_filtered_counts(self):
        source = self.write_jsonl([
            {"text": "failed", "scores": [3, 3]},
            {"text": "valid", "scores": [3, 4]},
        ])
        for _ in range(2):
            report = {}
            dataset = load_labeled_dataset(source, num_dimensions=2, filter_report=report)
            self.assertEqual(len(dataset), 1)
            self.assertEqual(dataset[0]["scores"], [3, 4])
            self.assertEqual((report["input_rows"], report["excluded_all_three"], report["retained_rows"]), (2, 1, 1))
        self.assertEqual(len(load_labeled_dataset(source, num_dimensions=2, exclude_all_three=False)), 2)
        source = self.write_jsonl([{"text": "failed only", "scores": [3, 3]}])
        with self.assertRaisesRegex(ValueError, "no valid labeled rows"):
            load_labeled_dataset(source, num_dimensions=2)
