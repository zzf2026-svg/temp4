"""Offline six-class comparison checks; no model weights or trainer required."""

from __future__ import annotations

from copy import deepcopy
import hashlib
import json
from pathlib import Path
import tempfile
import unittest

from compare_experiments import summarize_suite
from five_scores.config import DEFAULTS, validate_config
from five_scores.schema import DEFAULT_SCORE_VALUES, NEW_DIMENSION_NAMES
import run_experiments as runner


def write_json(path: Path, value: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False), encoding="utf-8")


def make_suite(root: Path) -> Path:
    """Six distinct labels; CE makes exactly one 0 -> 2 error, weighted CE none."""
    names, values = list(NEW_DIMENSION_NAMES), list(DEFAULT_SCORE_VALUES)
    experiments = []
    for name in ("ce", "weighted_ce"):
        run_dir = root / name
        config = deepcopy(DEFAULTS)
        config["model"].update(dimension_names=names, num_dimensions=3, score_values=values,
                               boundary_weight=0.0, class_weight_mode="none" if name == "ce" else "sqrt_inverse")
        config["data"].update(exclude_all_three=False, max_length=32)
        config["training"].update(output_dir=str(run_dir), metric_for_best_model="all_dimensions_accuracy",
                                  greater_is_better=True, early_stopping_patience=0)
        config = validate_config(config)
        config_path = root / "configs" / f"{name}.json"
        write_json(config_path, config)
        write_json(run_dir / "resolved_config.json", config)
        write_json(run_dir / "final" / "config.json", {"score_values": values, "name": name})
        matrices, per_class, dimension_metrics = {}, {}, {}
        for d, dimension in enumerate(names):
            matrix = [[int(i == j) for j in range(6)] for i in range(6)]
            if name == "ce" and d == 0:
                matrix[0][0], matrix[0][1] = 0, 1
            matrices[dimension] = matrix
            per_class[dimension] = {}
            for i, score in enumerate(values):
                predicted = sum(row[i] for row in matrix)
                correct = matrix[i][i]
                per_class[dimension][str(score)] = {
                    "support": 1, "predicted_count": predicted, "correct_count": correct,
                    "recall": float(correct), "precision": correct / predicted if predicted else None,
                }
            dimension_metrics[f"{dimension}_exact_accuracy"] = sum(matrix[i][i] for i in range(6)) / 6
        errors = int(name == "ce")
        metrics = {
            "num_examples": 6, "num_decisions": 18, "exact_match_count": 18 - errors,
            "row_exact_match_count": 6 - errors, "exact_accuracy": (18 - errors) / 18,
            "accuracy": (18 - errors) / 18, "all_dimensions_accuracy": (6 - errors) / 6,
            "row_exact_match": (6 - errors) / 6, "mae": errors * 2 / 18, "mae_steps": errors / 18,
            **dimension_metrics,
        }
        report = {
            "model": str(run_dir / "final"), "dimensions": names, "num_dimensions": 3,
            "num_classes": 6, "score_values": values, "examples": 6, "max_length": 32,
            "input_sha256": "f" * 64, "evaluated_data_sha256": "e" * 64,
            "model_config_sha256": hashlib.sha256((run_dir / "final" / "config.json").read_bytes()).hexdigest(),
            "input_schema": {"text_column": "text", "scores_column": "scores", "score_columns": None,
                             "exclude_all_three": False},
            "metrics": metrics, "confusion_matrices": matrices, "per_class_metrics": per_class,
        }
        write_json(run_dir / "validation_metrics.json", report)
        experiments.append({"name": name, "boundary_weight": 0.0,
                            "class_weight_mode": config["model"]["class_weight_mode"],
                            "config_path": str(config_path), "run_dir": str(run_dir)})
    write_json(root / "manifest.json", {
        "schema_version": 1, "suite_signature": "six-class-fixture",
        "selection": {"metric": "all_dimensions_accuracy", "greater_is_better": True},
        "data": {"validation": {"sha256": "f" * 64}}, "experiments": experiments,
    })
    return root


class SixClassExperimentTests(unittest.TestCase):
    def test_six_by_six_reports_and_zero_ten_endpoints(self):
        with tempfile.TemporaryDirectory() as directory:
            root = make_suite(Path(directory))
            result = summarize_suite(root)
            self.assertEqual(result["score_values"], list(DEFAULT_SCORE_VALUES))
            self.assertEqual(result["selected_model"]["experiment"], "weighted_ce")
            self.assertEqual(result["reference_experiment"], "ce")
            self.assertEqual(len(result["per_score"]), 36)
            ce, weighted = result["experiments"]
            self.assertAlmostEqual(ce["score_0_recall"], 2 / 3)
            self.assertEqual(ce["score_10_recall"], 1)
            self.assertAlmostEqual(weighted["delta_exact_accuracy_pp"], 100 / 18)
            self.assertNotIn("low_to_nonlow_rate", ce)
            markdown = (root / "comparison.md").read_text(encoding="utf-8")
            self.assertIn("0 分召回率", markdown)
            self.assertIn("10 分召回率", markdown)
            self.assertNotIn("3 分误判率", markdown)

    def test_equal_class_count_with_different_scale_is_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            root = make_suite(Path(directory))
            path = root / "ce" / "validation_metrics.json"
            report = json.loads(path.read_text())
            report["score_values"] = [1, 2, 3, 4, 5, 6]
            write_json(path, report)
            with self.assertRaisesRegex(ValueError, "score_values"):
                summarize_suite(root)

    def test_missing_sixth_matrix_class_is_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            root = make_suite(Path(directory))
            path = root / "ce" / "validation_metrics.json"
            report = json.loads(path.read_text())
            report["confusion_matrices"][NEW_DIMENSION_NAMES[0]].pop()
            write_json(path, report)
            with self.assertRaisesRegex(ValueError, "6x6"):
                summarize_suite(root)

    def test_new_scale_runner_defaults_to_ce_and_preserves_zero_policy(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            backbone = root / "backbone"
            write_json(backbone / "config.json", {"model_type": "modernbert"})
            (backbone / "model.safetensors").write_bytes(b"plan only")
            train, validation = root / "train.jsonl", root / "validation.jsonl"
            train.write_text('{"text":"train","scores":[0,0,0]}\n')
            validation.write_text('{"text":"validation","scores":[10,8,6]}\n')
            config_path = root / "config.json"
            write_json(config_path, {
                "model": {"name_or_path": str(backbone), "dimension_names": list(NEW_DIMENSION_NAMES),
                          "score_values": list(DEFAULT_SCORE_VALUES), "boundary_weight": 0.0},
                "data": {"train_file": str(train), "validation_file": str(validation), "exclude_all_three": False},
            })
            options = runner.parse_args(["--base-config", str(config_path), "--output-dir", str(root / "suite")])
            manifest, configs = runner.build_plan(options)
            self.assertEqual([e["name"] for e in manifest["experiments"]], ["ce", "weighted_ce"])
            for experiment in manifest["experiments"]:
                config = configs[experiment["name"]]
                self.assertFalse(config["data"]["exclude_all_three"])
                self.assertEqual(config["model"]["boundary_weight"], 0.0)
                self.assertIn("--include-all-three", runner.evaluation_command(experiment, config))


if __name__ == "__main__":
    unittest.main()
