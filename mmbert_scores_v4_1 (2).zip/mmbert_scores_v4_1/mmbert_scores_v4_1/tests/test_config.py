"""Configuration invariants that prevent label-order/count mistakes."""

import json

import pytest
import yaml

from five_scores.config import load_config
from five_scores.schema import DEFAULT_SCORE_VALUES, NEW_DIMENSION_NAMES


def write_config(tmp_path, value):
    path = tmp_path / "config.yaml"
    path.write_text(json.dumps(value), encoding="utf-8")
    return path


@pytest.mark.parametrize("count", [1, 5, 7])
def test_dimensions_and_equal_weights_derive_from_names(tmp_path, count):
    names = [f"dimension_{index}" for index in range(count)]
    config = load_config(write_config(tmp_path, {"model": {"dimension_names": names}}))
    assert config["model"]["num_dimensions"] == count
    assert config["model"]["dimension_names"] == names
    assert config["model"]["dimension_weights"] == [1.0] * count


def test_defaults_use_all_rows_three_names_six_scores_and_epoch_eval(tmp_path):
    config = load_config(write_config(tmp_path, {}))
    assert config["model"]["dimension_names"] == list(NEW_DIMENSION_NAMES)
    assert config["model"]["score_values"] == list(DEFAULT_SCORE_VALUES)
    assert config["data"]["max_train_samples"] is None
    assert config["training"]["eval_strategy"] == "epoch"
    assert config["training"]["output_dir"] == "outputs/mmbert-scores-v4"
    assert config["training"]["metric_for_best_model"] == "all_dimensions_accuracy"
    assert config["training"]["greater_is_better"] is None
    assert config["model"]["boundary_weight"] == 0.0
    assert config["model"]["class_weight_mode"] == "none"
    assert config["model"]["class_weights"] is None
    assert config["data"]["exclude_all_three"] is False
    assert config["conversion"]["exclude_all_three"] is False


@pytest.mark.parametrize("model", [
    {"dimension_names": []},
    {"dimension_names": ["a", " a "]},
    {"dimension_names": ["a"], "num_dimensions": 7},
    {"dimension_names": ["a"], "dimension_weights": [1, 1]},
    {"dimension_names": ["a"], "dimension_weights": [True]},
    {"dimension_names": ["a"], "dimension_weights": [0]},
])
def test_invalid_schema_fails_early(tmp_path, model):
    with pytest.raises(ValueError):
        load_config(write_config(tmp_path, {"model": model}))


@pytest.mark.parametrize("value", [0, -1, True, 2.5, "1000"])
def test_sample_limits_are_positive_integers_or_null(tmp_path, value):
    with pytest.raises(ValueError, match="max_train_samples"):
        load_config(write_config(tmp_path, {"data": {"max_train_samples": value}}))


def test_split_ratios_need_remaining_training_rows(tmp_path):
    with pytest.raises(ValueError, match="ratio"):
        load_config(write_config(tmp_path, {"data": {"validation_ratio": 0.5, "test_ratio": 0.5}}))


def test_unknown_option_is_not_silently_ignored(tmp_path):
    with pytest.raises(ValueError, match="Unknown data options"):
        load_config(write_config(tmp_path, {"data": {"max_training_samples": 20}}))


def test_every_step_evaluation_can_save_its_best_model(tmp_path):
    with pytest.raises(ValueError, match="save_steps must equal eval_steps"):
        load_config(write_config(tmp_path, {"training": {
            "eval_strategy": "steps", "eval_steps": 10, "save_steps": 20,
        }}))


@pytest.mark.parametrize("value", [-0.1, float("nan"), float("inf"), True, "0.2"])
def test_boundary_coefficient_must_be_finite_nonnegative_number(tmp_path, value):
    with pytest.raises(ValueError, match="boundary_weight"):
        load_config(write_config(tmp_path, {"model": {"boundary_weight": value}}))


def test_explicit_manual_weights_preserve_order_for_later_training_normalization(tmp_path):
    weights = [[1, 2, 3, 4, 5], [5, 4, 3, 2, 1]]
    config = load_config(write_config(tmp_path, {"model": {
        "dimension_names": ["a", "b"], "class_weight_mode": "manual", "class_weights": weights,
    }}))
    assert config["model"]["class_weights"] == weights


@pytest.mark.parametrize("model", [
    {"class_weight_mode": "inverse"},
    {"class_weight_mode": "manual"},
    {"class_weight_mode": "sqrt_inverse", "class_weights": [[1] * 5] * 7},
    {"class_weight_mode": "none", "class_weights": [[1] * 5] * 7},
    {"class_weight_mode": "manual", "class_weights": [[1] * 5]},
    {"class_weight_mode": "manual", "class_weights": [[1] * 4] * 7},
    {"class_weight_mode": "manual", "class_weights": [[0] * 5] * 7},
    {"class_weight_mode": "manual", "class_weights": [[True] * 5] * 7},
])
def test_class_weight_configuration_is_explicit_and_dimensioned(tmp_path, model):
    with pytest.raises(ValueError, match="class_weight"):
        load_config(write_config(tmp_path, {"model": model}))


@pytest.mark.parametrize("section", ["data", "conversion"])
def test_failed_teacher_filter_requires_boolean(tmp_path, section):
    with pytest.raises(ValueError, match="exclude_all_three"):
        load_config(write_config(tmp_path, {section: {"exclude_all_three": "false"}}))


@pytest.mark.parametrize("options", [
    {"metric_for_best_model": ""}, {"metric_for_best_model": " mae "},
    {"greater_is_better": "true"}, {"greater_is_better": 1},
])
def test_selection_config_rejects_ambiguous_types(tmp_path, options):
    with pytest.raises(ValueError):
        load_config(write_config(tmp_path, {"training": options}))


def test_json_scientific_notation_remains_numeric(tmp_path):
    path = tmp_path / "resolved_config.json"
    path.write_text('{"training":{"learning_rate":2e-05,"head_learning_rate":1e-04}}', encoding="utf-8")
    config = load_config(path)
    assert isinstance(config["training"]["learning_rate"], float)
    assert config["training"]["learning_rate"] == 2e-5
    assert isinstance(config["training"]["head_learning_rate"], float)
    assert config["training"]["head_learning_rate"] == 1e-4


def test_json_to_generated_yaml_roundtrip_preserves_numeric_training_options(tmp_path):
    original = tmp_path / "resolved_config.json"
    original.write_text(json.dumps({"training": {"learning_rate": 2e-5, "head_learning_rate": 1e-4}}), encoding="utf-8")
    resolved = load_config(original)
    generated = tmp_path / "baseline.yaml"
    generated.write_text(yaml.safe_dump(resolved, sort_keys=False), encoding="utf-8")
    loaded = load_config(generated)
    assert loaded == resolved
    assert isinstance(loaded["training"]["learning_rate"], float)
