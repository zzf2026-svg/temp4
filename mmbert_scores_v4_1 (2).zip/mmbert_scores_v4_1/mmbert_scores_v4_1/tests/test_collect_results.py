"""Result bundles must contain diagnostics, never training texts or checkpoints."""

import json
from pathlib import Path
import zipfile

import pytest

from collect_experiment_results import collect_results


def _suite(tmp_path):
    suite = tmp_path / "suite"
    run = suite / "baseline"
    (run / "final").mkdir(parents=True)
    (suite / "configs").mkdir()
    configuration = suite / "configs" / "baseline.yaml"
    configuration.write_text("model: {}\n", encoding="utf-8")
    manifest = {"schema_version": 1, "experiments": [
        {"name": "baseline", "run_dir": str(run), "config_path": str(configuration)},
    ]}
    (suite / "manifest.json").write_text(json.dumps(manifest), encoding="utf-8")
    (run / "validation_metrics.json").write_text('{"examples": 1}', encoding="utf-8")
    (run / "final" / "training_summary.json").write_text('{"global_step": 1}', encoding="utf-8")
    return suite, run


def test_bundle_collects_partial_diagnostics_without_raw_data_or_weights(tmp_path):
    suite, run = _suite(tmp_path)
    (run / "validation_predictions.csv").write_text("text,score\nprivate input,4\n", encoding="utf-8")
    (run / "final" / "model.safetensors").write_bytes(b"model weights")
    (suite / "train.jsonl").write_text('{"text":"private training input"}', encoding="utf-8")
    destination = tmp_path / "results.zip"
    result = collect_results(suite, destination)
    assert result["report_files"] == 4
    with zipfile.ZipFile(destination) as archive:
        names = archive.namelist()
        assert "suite/baseline/validation_metrics.json" in names
        assert not any(name.endswith((".safetensors", "predictions.csv", "train.jsonl")) for name in names)
    with pytest.raises(FileExistsError):
        collect_results(suite, destination)


def test_bundle_rejects_manifest_paths_outside_suite(tmp_path):
    suite, run = _suite(tmp_path)
    external = tmp_path / "external"
    external.mkdir()
    (external / "validation_metrics.json").write_text("{}", encoding="utf-8")
    manifest_path = suite / "manifest.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    manifest["experiments"][0]["run_dir"] = str(external)
    manifest_path.write_text(json.dumps(manifest), encoding="utf-8")
    with pytest.raises(ValueError, match="outside the suite"):
        collect_results(suite, tmp_path / "results.zip")
    assert not (tmp_path / "results.zip").exists()
