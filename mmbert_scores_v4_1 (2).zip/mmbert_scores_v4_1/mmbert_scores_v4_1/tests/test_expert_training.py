"""Offline checks for expert adaptation, source balance, and resume integrity."""

from copy import deepcopy
import json
from pathlib import Path
from types import SimpleNamespace
import sys

import pytest
import torch
from datasets import Dataset
from transformers import AutoConfig, AutoTokenizer, TrainingArguments, set_seed

import train
from five_scores.config import DEFAULTS, load_config, validate_config
from five_scores.modeling import ModernBertForFiveScores
from five_scores.replay import (
    build_training_provenance, sample_replay_features, validate_alignment_separation,
    validate_replay_runtime, validate_resume_checkpoint, validate_resume_provenance,
)
from five_scores.schema import DEFAULT_SCORE_VALUES, NEW_DIMENSION_NAMES


@pytest.fixture
def scoring_config(tiny_pretrained):
    config = AutoConfig.from_pretrained(tiny_pretrained / "model", local_files_only=True)
    config.score_dim_names = list(NEW_DIMENSION_NAMES)
    config.score_values = list(DEFAULT_SCORE_VALUES)
    config.score_model_version = 4
    config.score_dropout = 0.0
    config.score_max_length = 128
    config._attn_implementation = "sdpa"
    return config


def feature(index=0, label=0):
    return {"input_ids": [1, 5 + index % 10, 8, 2], "attention_mask": [1] * 4,
            "labels": [label] * 3, "length": 4}


def trainer_for(tmp_path, tiny_pretrained, scoring_config, **options):
    tokenizer = AutoTokenizer.from_pretrained(tiny_pretrained / "model", local_files_only=True)
    args_options = options.pop("args_options", {})
    args = TrainingArguments(
        output_dir=str(tmp_path), use_cpu=True, report_to=[], disable_tqdm=True,
        per_device_train_batch_size=2, per_device_eval_batch_size=2,
        **args_options,
    )
    return train.FiveScoreTrainer(
        model=ModernBertForFiveScores(deepcopy(scoring_config)), args=args,
        processing_class=tokenizer, data_collator=train.ScoreCollator(tokenizer, pad_to_multiple_of=None),
        train_dataset=Dataset.from_list([feature(i, i % 6) for i in range(10)]),
        eval_dataset=Dataset.from_list([feature(1, 1), feature(2, 2)]), **options,
    )


def test_freeze_only_encoder_keeps_head_gradients_and_optimizer(tmp_path, tiny_pretrained, scoring_config):
    trainer = trainer_for(tmp_path, tiny_pretrained, scoring_config, freeze_backbone=True)
    trainer.model.train()
    loss = trainer.compute_loss(trainer.model, trainer.data_collator([feature(0, 1), feature(1, 2)]))
    loss.backward()
    assert all(not p.requires_grad and p.grad is None for p in trainer.model.model.parameters())
    assert all(p.requires_grad and p.grad is not None for p in trainer.model.classifier.parameters())
    assert not trainer.model.model.training and trainer.model.dropout.training
    optimized = {id(p) for group in trainer.create_optimizer().param_groups for p in group["params"]}
    assert optimized == {id(p) for p in trainer.model.classifier.parameters()}
    assert trainer.model.config.score_freeze_backbone is True


def test_replay_is_source_mean_not_pool_size_ratio(tmp_path, tiny_pretrained, scoring_config):
    class RepeatedPool:
        def __init__(self, size):
            self.size = size

        def __len__(self):
            return self.size

        def __getitem__(self, index):
            return feature(3, 5)

    trainer = trainer_for(tmp_path, tiny_pretrained, scoring_config,
                          replay_dataset=RepeatedPool(1), replay_weight=0.2)
    inputs = trainer.data_collator([feature(0, 0), feature(1, 1)])
    trainer.model.train()
    primary = trainer.model(**inputs).loss
    replay = trainer.model(**trainer.data_collator([feature(3, 5)] * 2)).loss
    actual, outputs = trainer.compute_loss(trainer.model, inputs, return_outputs=True,
                                          num_items_in_batch=torch.tensor(6000))
    torch.testing.assert_close(actual, primary + 0.2 * replay)
    trainer.replay_dataset = RepeatedPool(200000)
    torch.testing.assert_close(trainer.compute_loss(trainer.model, inputs), actual)
    assert outputs.logits.shape == (2, 3, 6)
    assert trainer.model_accepts_loss_kwargs is False


def test_replay_gradient_accumulation_scales_once(tmp_path, tiny_pretrained, scoring_config):
    trainer = trainer_for(tmp_path, tiny_pretrained, scoring_config,
                          replay_dataset=[feature(3, 5)], replay_weight=0.15,
                          args_options={"gradient_accumulation_steps": 2})
    expected = deepcopy(trainer.model).train()
    examples = [feature(i, i % 6) for i in range(4)]
    expected_loss = expected(**trainer.data_collator(examples)).loss
    expected_loss += 0.15 * expected(**trainer.data_collator([feature(3, 5)] * 4)).loss
    expected_loss.backward()
    trainer.current_gradient_accumulation_steps = 2
    trainer.create_optimizer()
    for microbatch in (examples[:2], examples[2:]):
        trainer.training_step(trainer.model, trainer.data_collator(microbatch), num_items_in_batch=torch.tensor(12))
    for name, parameter in trainer.model.named_parameters():
        torch.testing.assert_close(parameter.grad, dict(expected.named_parameters())[name].grad,
                                   atol=1e-6, rtol=1e-5)


def test_validation_does_not_sample_or_mix_replay_loss(tmp_path, tiny_pretrained, scoring_config, monkeypatch):
    trainer = trainer_for(tmp_path, tiny_pretrained, scoring_config,
                          replay_dataset=[feature(3, 5)], replay_weight=100)
    trainer.model.eval()
    expected = trainer.model(**trainer.data_collator([feature(1, 1), feature(2, 2)])).loss.item()

    def forbidden(*args, **kwargs):
        raise AssertionError("Evaluation must never sample replay")

    monkeypatch.setattr(train, "sample_replay_features", forbidden)
    metrics = trainer.evaluate()
    assert metrics["eval_loss"] == pytest.approx(expected, abs=1e-6)
    assert len(trainer.get_train_dataloader()) == 5


def test_replay_rng_roundtrip_and_runtime_guard():
    pool = [feature(i, i % 6) for i in range(20)]
    torch.manual_seed(72)
    state = torch.get_rng_state()
    first = sample_replay_features(pool, 10)
    torch.set_rng_state(state)
    assert sample_replay_features(pool, 10) == first
    for options in ({"world_size": 2}, {"n_gpu": 2}, {"ignore_data_skip": True}, {"save_only_model": True},
                    {"dataloader_num_workers": 1}):
        args = {"world_size": 1, "n_gpu": 0, "ignore_data_skip": False, "save_only_model": False, **options}
        with pytest.raises(ValueError):
            validate_replay_runtime(SimpleNamespace(**args))


@pytest.mark.parametrize("checkpoint_step", [1, 3, 4])
def test_replay_checkpoint_resume_matches_uninterrupted_training(tmp_path, tiny_pretrained, scoring_config,
                                                               checkpoint_step):
    scoring_config.score_dropout = 0.15
    options = {"max_steps": 5, "save_steps": 1, "save_strategy": "steps", "logging_strategy": "no",
               "gradient_accumulation_steps": 2, "group_by_length": True, "seed": 29, "data_seed": 29,
               "dataloader_num_workers": 0}
    set_seed(29)
    full = trainer_for(tmp_path / "full", tiny_pretrained, scoring_config,
                       replay_dataset=[feature(i, i % 6) for i in range(5)], replay_weight=0.1,
                       args_options=options)
    full.train()
    expected = {key: value.clone() for key, value in full.model.state_dict().items()}
    set_seed(29)
    resumed = trainer_for(tmp_path / "resume", tiny_pretrained, scoring_config,
                          replay_dataset=full.replay_dataset, replay_weight=0.1, args_options=options)
    resumed.train(resume_from_checkpoint=str(tmp_path / "full" / f"checkpoint-{checkpoint_step}"))
    assert resumed.state.global_step == full.state.global_step == 5
    for key, value in resumed.model.state_dict().items():
        torch.testing.assert_close(value, expected[key], atol=0, rtol=0)
    with pytest.raises(ValueError, match="rng_state"):
        resumed._load_rng_state(tmp_path / "missing_rng")


@pytest.mark.parametrize("missing", ["optimizer.pt", "scheduler.pt", "rng_state.pth"])
def test_resume_rejects_incomplete_optimizer_or_rng_checkpoint(tmp_path, missing):
    for name in ("config.json", "trainer_state.json", "optimizer.pt", "scheduler.pt", "rng_state.pth"):
        if name != missing:
            (tmp_path / name).write_text("fixture")
    with pytest.raises(ValueError, match=missing.replace(".", r"\.")):
        validate_resume_checkpoint(tmp_path)


def write_rows(path, rows):
    path.write_text("".join(json.dumps(row, ensure_ascii=False) + "\n" for row in rows), encoding="utf-8")
    return str(path)


def row(text, **extra):
    return {"text": text, "scores": [0, 2, 4], "dimension_names": list(NEW_DIMENSION_NAMES),
            "score_values": list(DEFAULT_SCORE_VALUES), **extra}


def dataset_config(tmp_path):
    config = deepcopy(DEFAULTS)
    config["training"].update(stage="expert", freeze_backbone=True, replay_weight=0.1)
    for split, key in (("train", "train_file"), ("validation", "validation_file"), ("replay", "replay_file")):
        config["data"][key] = write_rows(tmp_path / f"{split}.jsonl", [row(split, group_id=split)])
    return validate_config(config)


@pytest.mark.parametrize("bad_replay", [
    {"score_values": [1, 2, 3, 4, 5]}, {"dimension_names": list(reversed(NEW_DIMENSION_NAMES))},
    {"scores": [1, 2, 4]}, {"scores": [0, 2]},
])
def test_replay_rejects_schema_mismatch(tmp_path, bad_replay):
    config = dataset_config(tmp_path)
    write_rows(Path(config["data"]["replay_file"]), [row("replay", **bad_replay)])
    with pytest.raises(ValueError):
        validate_alignment_separation(config["data"], config["model"])


def test_replay_requires_explicit_scale(tmp_path):
    config = dataset_config(tmp_path)
    record = row("replay")
    record.pop("score_values")
    write_rows(Path(config["data"]["replay_file"]), [record])
    with pytest.raises(ValueError, match="declare score_values"):
        validate_alignment_separation(config["data"], config["model"])


@pytest.mark.parametrize("replacement", [row(" train\r\n"), row("new", group_id="validation"),
                                          row("new", metadata={"group_id": "train"})])
def test_replay_rejects_text_and_group_overlap(tmp_path, replacement):
    config = dataset_config(tmp_path)
    write_rows(Path(config["data"]["replay_file"]), [replacement])
    with pytest.raises(ValueError, match="overlap"):
        validate_alignment_separation(config["data"], config["model"])


def test_expert_train_and_validation_must_be_disjoint(tmp_path):
    config = dataset_config(tmp_path)
    write_rows(Path(config["data"]["validation_file"]), [row("train")])
    with pytest.raises(ValueError, match="overlap"):
        validate_alignment_separation(config["data"], config["model"])


@pytest.mark.parametrize("training", [{"freeze_backbone": "true"}, {"replay_weight": True},
                                       {"replay_weight": -0.1}, {"replay_weight": float("nan")},
                                       {"replay_weight": 0.1}, {"stage": "unknown"}])
def test_new_config_options_are_strict(tmp_path, training):
    path = tmp_path / "config.json"
    path.write_text(json.dumps({"training": training}))
    with pytest.raises(ValueError):
        load_config(path)


def test_resume_checks_data_bytes_freezing_and_replay_settings(tmp_path, tiny_pretrained):
    config = dataset_config(tmp_path)
    original = build_training_provenance(config, str(tiny_pretrained / "model"))
    resumed = build_training_provenance(config, str(tiny_pretrained / "model"), saved=original, resume=True)
    assert resumed["run_id"] == original["run_id"]
    assert "model.safetensors" in original["source_checkpoint"]["files"]
    for field, value in (("freeze_backbone", False), ("replay_weight", 0.5), ("stage", "pseudo")):
        changed = deepcopy(config)
        changed["training"][field] = value
        with pytest.raises(ValueError, match="Resume provenance mismatch"):
            build_training_provenance(changed, "unused", saved=original, resume=True)
    train_file = Path(config["data"]["train_file"])
    # Same labels/counts but different text still must fail resume.
    write_rows(train_file, [row("changed", group_id="train")])
    with pytest.raises(ValueError, match="fingerprint mismatch for train"):
        build_training_provenance(config, "unused", saved=original, resume=True)
    with pytest.raises(ValueError, match="no verifiable training provenance"):
        validate_resume_provenance(None, original)


def test_warmstart_is_new_run_recomputes_weights_and_fresh_optimizer(tmp_path, tiny_pretrained,
                                                                  scoring_config, monkeypatch):
    source = tmp_path / "source"
    scoring_config.score_class_weight_mode = "sqrt_inverse"
    scoring_config.score_class_weights = [[0.5, 1, 1, 1, 1, 2]] * 3
    scoring_config.score_class_counts = [[100] * 6] * 3
    scoring_config.score_training_provenance = {"version": 1, "run_id": "source-run"}
    ModernBertForFiveScores(scoring_config).save_pretrained(source)
    AutoTokenizer.from_pretrained(tiny_pretrained / "model", local_files_only=True).save_pretrained(source)
    (source / "optimizer.pt").write_text("must never be loaded by warmstart")
    config = dataset_config(tmp_path)
    config["data"].update(replay_file=None, num_proc=1, max_length=32)
    config["model"].update(name_or_path=str(source), class_weight_mode="none")
    config["training"].update(output_dir=str(tmp_path / "new-run"), replay_weight=0, use_cpu=True,
                               max_steps=1, eval_strategy="steps", eval_steps=1, save_steps=1,
                               logging_steps=1, early_stopping_patience=0, dataloader_num_workers=0,
                               gradient_accumulation_steps=1, per_device_train_batch_size=1)
    path = tmp_path / "expert.json"
    path.write_text(json.dumps(config))
    calls = []
    original_train = train.FiveScoreTrainer.train

    def record_train(self, *args, **kwargs):
        calls.append(kwargs.get("resume_from_checkpoint"))
        assert not self.create_optimizer().state
        return original_train(self, *args, **kwargs)

    monkeypatch.setattr(train.FiveScoreTrainer, "train", record_train)
    monkeypatch.setattr(sys, "argv", ["train.py", "--config", str(path)])
    train.main()
    final = tmp_path / "new-run" / "final"
    saved = json.loads((final / "config.json").read_text())
    provenance = json.loads((final / "provenance.json").read_text())
    summary = json.loads((final / "training_summary.json").read_text())
    assert calls == [None]
    assert saved["score_class_weight_mode"] == "none"
    assert saved["score_class_weights"] == [[1.0] * 6] * 3
    assert [sum(counts) for counts in saved["score_class_counts"]] == [1, 1, 1]
    assert provenance["run_id"] != "source-run" and provenance["optimizer_initialization"] == "fresh"
    assert provenance["training_stage"] == "expert" and provenance["freeze_backbone"] is True
    assert summary["global_step"] == 1
