"""CSV and JSONL prediction contracts with a lightweight mock predictor."""

from __future__ import annotations

import csv
import json
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

import predict
from five_scores.excel import build_input_text, resolve_settings
from five_scores.schema import DEFAULT_DIMENSION_NAMES


class MockPredictor:
    def __init__(self, names=DEFAULT_DIMENSION_NAMES, template=None):
        self.dimension_names = list(names)
        self.config = SimpleNamespace(score_text_template=template)
        self.texts = []

    def predict(self, texts, *, batch_size, include_probabilities, reject_truncation):
        self.texts.extend(texts)
        outputs = []
        for _ in texts:
            row = {
                "scores": {name: 4 for name in self.dimension_names},
                "max_probabilities": {name: 0.7 for name in self.dimension_names},
                "expected_scores": {name: 3.8 for name in self.dimension_names},
                "input_tokens": 12, "used_tokens": 12, "truncated": False,
            }
            if include_probabilities:
                row["probabilities"] = {name: [0.0, 0.1, 0.1, 0.7, 0.1] for name in self.dimension_names}
            outputs.append(row)
        return outputs


class PredictionCSVTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name)
        self.source = self.root / "source.csv"
        self.destination = self.root / "prediction.csv"
        self.predictor = MockPredictor()

    def write_csv(self, rows, *, encoding="utf-8-sig", delimiter=","):
        with self.source.open("w", encoding=encoding, newline="") as output:
            writer = csv.DictWriter(output, fieldnames=list(rows[0]), delimiter=delimiter)
            writer.writeheader()
            writer.writerows(rows)

    def run_prediction(self, *args):
        with patch("predict.predictor_from_args", return_value=self.predictor):
            predict.main([
                "--model", str(self.root / "model"), "--input", str(self.source),
                "--output", str(self.destination), "--batch-size", "1", *args,
            ])

    def read_csv(self, *, delimiter=","):
        with self.destination.open(encoding="utf-8-sig", newline="") as source:
            reader = csv.DictReader(source, delimiter=delimiter)
            return reader.fieldnames, list(reader)

    def test_raw_csv_preserves_all_columns_values_order_and_failed_teacher_rows(self):
        base = {
            "id": "00001", "core_elements": "人员与设备", "scene_description": 'A,B\n他说："继续"',
            "pain_analysis": "实际困扰", "solution": "解决方法", "domains": "领域",
            "score_status": "failed", **{name: "3" for name in DEFAULT_DIMENSION_NAMES},
            "teacher_model": "teacher-id", "score": "3.0",
        }
        second = {**base, "id": "00002", "scene_description": "另一个场景", "authenticity": "5"}
        originals = [base, second]
        self.write_csv(originals)
        input_bytes = self.source.read_bytes()
        self.run_prediction("--include-probabilities", "--include-text")
        headers, rows = self.read_csv()
        self.assertEqual(headers[:len(base)], list(base))
        self.assertEqual(len(rows), 2)
        for original, row in zip(originals, rows, strict=True):
            self.assertEqual({key: row[key] for key in original}, original)
            self.assertEqual(row["pred_authenticity"], "4")
            self.assertEqual(float(row["pred_confidence_authenticity"]), 0.7)
            self.assertEqual(json.loads(row["pred_probabilities_authenticity"]), [0.0, 0.1, 0.1, 0.7, 0.1])
        settings = resolve_settings({"model": {"dimension_names": list(DEFAULT_DIMENSION_NAMES)}})
        self.assertEqual(self.predictor.texts, [build_input_text(row, settings) for row in originals])
        self.assertEqual(self.source.read_bytes(), input_bytes)

    def test_standard_text_csv_requires_no_raw_fields_and_retains_teacher_scores(self):
        self.write_csv([{"id": "0009", "text": "already rendered text", "scores": "[3,3,3,3,3,3,3]"}])
        self.run_prediction()
        _, rows = self.read_csv()
        self.assertEqual(self.predictor.texts, ["already rendered text"])
        self.assertEqual(rows[0]["scores"], "[3,3,3,3,3,3,3]")

    def test_shared_conversion_config_and_nondefault_csv_encoding(self):
        self.predictor = MockPredictor(["first", "second"])
        config = self.root / "custom.yaml"
        config.write_text(json.dumps({
            "model": {"dimension_names": ["first", "second"]},
            "conversion": {
                "text_columns": ["who", "context"], "required_text_columns": ["context"],
                "text_labels": {"who": "画像", "context": "触发场景"},
                "csv_encoding": "gb18030", "csv_delimiter": ";",
            },
        }), encoding="utf-8")
        self.write_csv([{"who": "老人", "context": "独处", "first": "5", "second": "1"}], encoding="gb18030", delimiter=";")
        self.run_prediction("--config", str(config))
        headers, rows = self.read_csv(delimiter=";")
        self.assertEqual(self.predictor.texts, ["【画像】老人\n【触发场景】独处"])
        self.assertEqual(headers[:4], ["who", "context", "first", "second"])
        self.assertEqual((rows[0]["first"], rows[0]["second"], rows[0]["pred_first"]), ("5", "1", "4"))

    def test_saved_template_and_explicit_template_override(self):
        saved = resolve_settings({
            "model": {"dimension_names": list(DEFAULT_DIMENSION_NAMES)},
            "conversion": {"text_columns": ["source"], "required_text_columns": ["source"], "text_labels": {"source": "训练输入"}},
        }).text_template()
        self.predictor.config.score_text_template = saved
        self.write_csv([{"source": "内容"}])
        self.run_prediction()
        self.assertEqual(self.predictor.texts, ["【训练输入】内容"])
        overridden = json.loads(json.dumps(saved))
        overridden["sections"][0]["label"] = "指定输入"
        template_file = self.root / "text_template.json"
        template_file.write_text(json.dumps(overridden), encoding="utf-8")
        self.run_prediction("--overwrite", "--text-template-file", str(template_file))
        self.assertEqual(self.predictor.texts[-1], "【指定输入】内容")

    def test_existing_prediction_columns_are_never_overwritten(self):
        self.write_csv([{"text": "input", "pred_authenticity": "existing"}])
        with self.assertRaisesRegex(ValueError, "no source column will be overwritten"):
            self.run_prediction()
        self.assertFalse(self.destination.exists())

    def test_late_invalid_csv_record_keeps_previous_output_unchanged(self):
        self.write_csv([{"text": "valid"}])
        with self.source.open("a", encoding="utf-8", newline="") as handle:
            handle.write("too,many,cells\n")
        self.destination.write_bytes(b"previous result")
        with self.assertRaisesRegex(ValueError, "cells; expected"):
            self.run_prediction("--overwrite")
        self.assertEqual(self.destination.read_bytes(), b"previous result")
        self.assertEqual(list(self.root.glob(".prediction.csv.*.tmp")), [])

    def test_jsonl_output_remains_compatible_and_does_not_filter_teacher_labels(self):
        self.source = self.root / "source.jsonl"
        self.destination = self.root / "prediction.jsonl"
        self.source.write_text(json.dumps({"id": "001", "text": "input", "scores": [3] * 7}) + "\n", encoding="utf-8")
        self.run_prediction("--include-text", "--include-probabilities")
        row = json.loads(self.destination.read_text())
        self.assertEqual(row["id"], "001")
        self.assertEqual(row["text"], "input")
        self.assertEqual(row["scores"], {name: 4 for name in DEFAULT_DIMENSION_NAMES})
        self.assertIn("expected_scores", row)
        self.assertIn("max_probabilities", row)
        self.assertIn("probabilities", row)
        self.assertFalse(any(key.startswith("pred_") for key in row))
