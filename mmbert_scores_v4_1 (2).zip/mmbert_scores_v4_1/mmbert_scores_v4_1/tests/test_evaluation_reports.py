"""Evaluation keeps filtered teacher labels, source records, and predictions aligned."""

from __future__ import annotations

import csv
import json
from pathlib import Path

import pytest

import evaluate


@pytest.fixture
def fake_predictor(monkeypatch):
    instances = []

    class FakePredictor:
        def __init__(self, model_dir, **kwargs):
            self.model_dir = Path(model_dir)
            self.dimension_names = ["quality", "feasibility"]
            self.num_dimensions, self.num_classes, self.max_length = 2, 5, 6
            self.device, self.precision = "cpu", "fp32"
            self.seen_texts = []
            instances.append(self)

        def predict(self, texts, batch_size=32, include_probabilities=False, reject_truncation=False):
            self.seen_texts.extend(texts)
            scores_by_text = {"low-high": [3, 3], "within": [2, 4], "middle": [2, 4]}
            rows = []
            for text in texts:
                if text == "explode":
                    raise ValueError("synthetic inference failure")
                scores = scores_by_text[text]
                truncated = text == "middle"
                if reject_truncation and truncated:
                    raise ValueError("synthetic rejected truncation")
                row = {
                    "scores": dict(zip(self.dimension_names, scores)),
                    "input_tokens": 10 if truncated else 5,
                    "used_tokens": 6 if truncated else 5,
                    "truncated": truncated,
                }
                if include_probabilities:
                    row["probabilities"] = {
                        name: [0.8 if candidate == score else 0.05 for candidate in range(1, 6)]
                        for name, score in zip(self.dimension_names, scores)
                    }
                rows.append(row)
            return rows

    monkeypatch.setattr(evaluate, "ScorePredictor", FakePredictor)
    return instances


def _arguments(tmp_path, source, predictions=None):
    arguments = [
        "--model", str(tmp_path / "model"), "--data", str(source),
        "--output", str(tmp_path / "report.json"), "--device", "cpu", "--batch-size", "2",
    ]
    if predictions is not None:
        arguments += ["--predictions-output", str(predictions)]
    return arguments


def test_csv_preserves_source_ids_reserved_fields_and_boundary_masks(tmp_path, fake_predictor, capsys):
    source = tmp_path / "data.csv"
    rows = [
        {"id": "kept-a", "text": "low-high", "qa": "2", "qb": "4", "source_row": "original-a", "probabilities": "keep this"},
        {"id": "failed", "text": "teacher-failed", "qa": "3", "qb": "3", "source_row": "original-failed", "probabilities": "failure"},
        {"id": "kept-b", "text": "within", "qa": "1", "qb": "5", "source_row": "original-b", "probabilities": "still source"},
        {"id": "kept-c", "text": "middle", "qa": "3", "qb": "4", "source_row": "original-c", "probabilities": "source-c"},
    ]
    with source.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    predictions = tmp_path / "predictions.csv"
    evaluate.main(_arguments(tmp_path, source, predictions) + ["--score-columns", "qa", "qb"])
    report = json.loads((tmp_path / "report.json").read_text(encoding="utf-8"))
    with predictions.open("r", encoding="utf-8", newline="") as handle:
        exported = list(csv.DictReader(handle))
    assert fake_predictor[0].seen_texts == ["low-high", "within", "middle"]
    assert report["examples"] == 3
    assert report["data_filtering"]["input_rows"] == 4
    assert report["data_filtering"]["excluded_all_three"] == 1
    assert report["data_filtering"]["retained_rows"] == 3
    assert report["metrics"]["accuracy"] == pytest.approx(1 / 6)
    assert report["metrics"]["row_exact_match"] == 0
    assert report["metrics"]["endpoint_boundary_error_rate"] == pytest.approx(2 / 5)
    assert report["metrics"]["group_mismatch_rate"] == pytest.approx(3 / 6)
    assert report["truncated_examples"] == 1
    assert report["truncation_rate"] == pytest.approx(1 / 3)
    assert report["metrics"]["quality_high_to_nonhigh_rate"] is None
    assert [row["source_row"] for row in exported] == ["1", "3", "4"]
    assert [row["input.id"] for row in exported] == ["kept-a", "kept-b", "kept-c"]
    assert exported[0]["input.source_row"] == "original-a"
    assert exported[0]["input.probabilities"] == "keep this"
    assert json.loads(exported[0]["original_record"]) == rows[0]
    assert exported[0]["gold.quality"] == "2"
    assert exported[0]["predicted.quality"] == "3"
    assert json.loads(exported[0]["probabilities.quality"]) == pytest.approx([0.05, 0.05, 0.8, 0.05, 0.05])
    assert exported[0]["exact.quality"] == "False"
    assert exported[0]["boundary_violation.quality"] == "True"
    assert exported[0]["boundary_violation.feasibility"] == "True"
    assert exported[1]["exact.quality"] == "False"
    assert exported[1]["exact.feasibility"] == "False"
    assert exported[1]["row_any_boundary_violation"] == "False"
    assert exported[2]["group_mismatch.quality"] == "True"
    assert exported[2]["boundary_violation.quality"] == "False"
    assert exported[2]["input_tokens"] == "10"
    assert exported[2]["used_tokens"] == "6"
    assert exported[2]["truncated"] == "True"
    assert len(report["confusion_matrices"]["quality"]) == 5
    assert len(report["group_confusion_matrices"]["quality"]) == 3
    assert "excluded_all_three" in capsys.readouterr().err


def test_jsonl_preserves_nested_originals_and_physical_row_numbers(tmp_path, fake_predictor):
    source = tmp_path / "data.jsonl"
    failed = {"id": "bad", "text": "teacher-failed", "scores": [3, 3]}
    original = {
        "id": 47, "text": "within", "scores": [1, 5], "dimension_names": ["quality", "feasibility"],
        "gold_scores": "original field", "metadata": {"x": [1, None, "汉字"]},
    }
    # JSONL source_row is the physical line, including a skipped blank line.
    source.write_text(json.dumps(failed) + "\n\n" + json.dumps(original, ensure_ascii=False) + "\n", encoding="utf-8")
    destination = tmp_path / "predictions.jsonl"
    evaluate.main(_arguments(tmp_path, source, destination))
    records = [json.loads(line) for line in destination.read_text(encoding="utf-8").splitlines()]
    assert len(records) == 1
    assert records[0]["source_row"] == 3
    assert records[0]["input"] == original
    assert records[0]["gold_scores"] == {"quality": 1, "feasibility": 5}
    assert records[0]["predicted_scores"] == {"quality": 2, "feasibility": 4}
    assert records[0]["exact_match"] == {"quality": False, "feasibility": False}
    assert records[0]["row_exact_match"] is False
    assert records[0]["row_any_boundary_violation"] is False
    assert set(records[0]["probabilities"]) == {"quality", "feasibility"}


def test_csv_keeps_fields_introduced_in_later_json_records(tmp_path, fake_predictor):
    source = tmp_path / "data.jsonl"
    rows = [
        {"id": 1, "text": "within", "scores": [1, 5]},
        {"id": 2, "text": "middle", "scores": [3, 4], "later": ["new", None]},
    ]
    source.write_text("".join(json.dumps(row) + "\n" for row in rows), encoding="utf-8")
    destination = tmp_path / "predictions.csv"
    evaluate.main(_arguments(tmp_path, source, destination))
    with destination.open("r", encoding="utf-8", newline="") as handle:
        exported = list(csv.DictReader(handle))
    assert exported[0]["input.later"] == ""
    assert json.loads(exported[1]["input.later"]) == ["new", None]
    assert "later" not in json.loads(exported[0]["original_record"])


@pytest.mark.parametrize("conflict", ["report_source", "predictions_source", "destinations", "existing_report", "existing_predictions"])
def test_rejects_source_aliases_colliding_outputs_and_accidental_overwrites(tmp_path, fake_predictor, conflict):
    source = tmp_path / "data.jsonl"
    source.write_text('{"text":"within","scores":[1,5]}\n', encoding="utf-8")
    report, predictions = tmp_path / "report.json", tmp_path / "predictions.jsonl"
    arguments = _arguments(tmp_path, source, predictions)
    if conflict == "report_source":
        arguments[arguments.index("--output") + 1] = str(source)
        arguments += ["--overwrite"]
    elif conflict == "predictions_source":
        arguments[arguments.index("--predictions-output") + 1] = str(source)
        arguments += ["--overwrite"]
    elif conflict == "destinations":
        arguments[arguments.index("--output") + 1] = str(predictions)
        arguments += ["--overwrite"]
    elif conflict == "existing_report":
        report.write_text("preserve report", encoding="utf-8")
    else:
        predictions.write_text("preserve predictions", encoding="utf-8")
    with pytest.raises(SystemExit):
        evaluate.main(arguments)
    assert not fake_predictor
    assert json.loads(source.read_text(encoding="utf-8"))["scores"] == [1, 5]
    if conflict == "existing_report":
        assert report.read_text(encoding="utf-8") == "preserve report"
    if conflict == "existing_predictions":
        assert predictions.read_text(encoding="utf-8") == "preserve predictions"


def test_symlink_cannot_be_used_to_overwrite_labeled_source(tmp_path, fake_predictor):
    source = tmp_path / "data.jsonl"
    source.write_text('{"text":"within","scores":[1,5]}\n', encoding="utf-8")
    alias = tmp_path / "alias.jsonl"
    alias.symlink_to(source)
    with pytest.raises(SystemExit):
        evaluate.main(_arguments(tmp_path, source, alias) + ["--overwrite"])
    assert not fake_predictor
    assert json.loads(source.read_text(encoding="utf-8"))["text"] == "within"


def test_failure_does_not_publish_partial_reports_or_replace_existing_outputs(tmp_path, fake_predictor):
    source = tmp_path / "data.jsonl"
    rows = [{"text": "within", "scores": [1, 5]}, {"text": "explode", "scores": [2, 4]}]
    source.write_text("".join(json.dumps(row) + "\n" for row in rows), encoding="utf-8")
    destination = tmp_path / "predictions.csv"
    report = tmp_path / "report.json"
    report.write_text("old report", encoding="utf-8")
    destination.write_text("old predictions", encoding="utf-8")
    arguments = _arguments(tmp_path, source, destination) + ["--batch-size", "1", "--overwrite"]
    with pytest.raises(ValueError, match="inference failure"):
        evaluate.main(arguments)
    assert report.read_text(encoding="utf-8") == "old report"
    assert destination.read_text(encoding="utf-8") == "old predictions"
    assert list(tmp_path.glob(".*.tmp")) == []


def test_all_failed_labels_produce_no_evaluation_outputs(tmp_path, fake_predictor):
    source = tmp_path / "data.jsonl"
    source.write_text('{"text":"teacher-failed","scores":[3,3]}\n', encoding="utf-8")
    predictions = tmp_path / "predictions.jsonl"
    with pytest.raises(ValueError, match="no valid labeled rows"):
        evaluate.main(_arguments(tmp_path, source, predictions))
    assert fake_predictor[0].seen_texts == []
    assert not (tmp_path / "report.json").exists()
    assert not predictions.exists()
    assert list(tmp_path.glob(".*.tmp")) == []


def test_atomic_no_overwrite_commit_refuses_a_late_destination(tmp_path):
    temporary, destination = tmp_path / "staged.tmp", tmp_path / "result.json"
    temporary.write_text("new", encoding="utf-8")
    destination.write_text("another process", encoding="utf-8")
    with pytest.raises(FileExistsError):
        evaluate._commit_file(temporary, destination, overwrite=False)
    assert destination.read_text(encoding="utf-8") == "another process"
    assert temporary.read_text(encoding="utf-8") == "new"


def test_evaluation_fingerprints_preserve_semantics_and_detect_order_changes(tmp_path, fake_predictor):
    source = tmp_path / "data.jsonl"
    rows = [
        {"id": "a", "text": "within", "scores": [1, 5]},
        {"id": "b", "text": "middle", "scores": [3, 4]},
    ]

    def run(records, batch_size):
        source.write_text("".join(json.dumps(row) + "\n" for row in records), encoding="utf-8")
        evaluate.main(_arguments(tmp_path, source) + ["--batch-size", str(batch_size), "--overwrite"])
        return json.loads((tmp_path / "report.json").read_text(encoding="utf-8"))

    first = run(rows, 1)
    second = run(rows, 2)
    assert first["input_sha256"] == second["input_sha256"]
    assert first["evaluated_data_sha256"] == second["evaluated_data_sha256"]
    # Neither metadata nor excluded failed labels change the evaluated examples.
    annotated = [{**row, "note": "metadata"} for row in rows]
    annotated.insert(1, {"text": "teacher-failed", "scores": [3, 3]})
    third = run(annotated, 2)
    assert first["input_sha256"] != third["input_sha256"]
    assert first["evaluated_data_sha256"] == third["evaluated_data_sha256"]
    fourth = run(list(reversed(rows)), 2)
    assert first["evaluated_data_sha256"] != fourth["evaluated_data_sha256"]
    assert first["input_schema"]["exclude_all_three"] is True


def test_changed_evaluation_source_is_not_published(tmp_path, fake_predictor, monkeypatch):
    source = tmp_path / "data.jsonl"
    original = '{"text":"within","scores":[1,5]}\n'
    source.write_text(original, encoding="utf-8")
    predictor = evaluate.ScorePredictor
    previous_predict = predictor.predict

    def mutate_after_prediction(self, *args, **kwargs):
        results = previous_predict(self, *args, **kwargs)
        source.write_text(original + "\n", encoding="utf-8")
        return results

    monkeypatch.setattr(predictor, "predict", mutate_after_prediction)
    with pytest.raises(ValueError, match="input changed"):
        evaluate.main(_arguments(tmp_path, source, tmp_path / "predictions.csv"))
    assert not (tmp_path / "report.json").exists()
    assert not (tmp_path / "predictions.csv").exists()
    assert list(tmp_path.glob(".*.tmp")) == []
