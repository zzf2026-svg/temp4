# 验证记录：v4 三维六分类

日期：2026-11-09。

## 实际完成的验证

| 检查 | 结果 |
| --- | --- |
| 全量 pytest 回归 | **311 passed，0 failed，0 error，0 skipped** |
| 真实上传 Excel 的默认配置转换 | 1 条输入、1 条保留、0 条拒绝 |
| 重复表头修复 | D 列文本映射为 solution，E 列仍为 novelty_score 标签 |
| 全 0 标签 | 保留为 `[0,0,0]` |
| 新分类头 | 输出 `[batch,3,6]`，损失与反向传播通过 |
| 标签及推理映射 | 0/2/4/6/8/10 与内部 0–5 完整映射，强制端点输出测试通过 |
| 持久化与兼容 | v4 保存/加载、缺分值元数据拒绝、旧模型保持旧标尺 |
| 评估 | 6×6 矩阵、真实分值 MAE、档位 MAE、CSV/JSONL 行对齐 |
| CSV 推理 | 重复头修复、保留原始字段、标准 text 列跳过物理表头规则 |
| 实验与比较 | 新 CE/weighted CE，旧量表兼容，错配标尺与矩阵拒绝 |
| 端到端 CPU 自检 | fixture、train、predict、evaluate、benchmark、resume、predict_resumed 七阶段全部通过 |

完整 pytest 有 1 条来自 Starlette/AnyIO 的依赖弃用提示，没有测试失败。采用项目声明的 FastAPI 0.116.1 / Uvicorn 0.35.0 验证 HTTP 路径。

## 端到端自检条件

- CPU，PyTorch `2.8.0+cpu`。
- Transformers `4.57.1`、Datasets `4.3.0`、Accelerate `1.10.1`。
- 本地随机初始化的 tiny ModernBERT；合成数据；测试过程中不下载模型。
- 三个维度：`novelty_score`、`demand_score`、`quality_score`。
- 六个实际分值：`[0,2,4,6,8,10]`。
- 初次训练 2 个优化器 step；保存、重新加载后预测 3 行；恢复 checkpoint 继续到 `global_step=3`。

该测试改变续训步数仅用于证明 Trainer 状态能够恢复，不是推荐的正式学习率调度方式。

## 证据文件

- `validation/pytest.xml`：最终全量回归 JUnit 报告。
- `validation/integration_cpu.json`：端到端阶段结果。
- `validation/integration_logs/`：相应阶段日志。
- `validation/environment.json`：实际验证版本。
- `validation/validation_summary.json`：机器可读摘要。
- `examples/from_uploaded_sample/`：真实附件的转换报告、文本模板和标签。

## 尚未验证的内容

此次交付是代码和数据格式适配，没有使用完整业务数据训练真实 mmBERT，也没有进行 GPU 训练或 GPU 性能测试。因此不报告业务一致率、预期收敛轮数或生产吞吐量。样例工作簿只有 1 条有效记录，不能据此推断模型效果。

在服务器复现：

```bash
python -m pip install -r requirements-dev.txt
python -m pytest -q
python scripts/smoke_test.py \
  --num-dimensions 3 --score-values 0 2 4 6 8 10 \
  --device cpu --work-dir /tmp/mmbert-v4-smoke
```
