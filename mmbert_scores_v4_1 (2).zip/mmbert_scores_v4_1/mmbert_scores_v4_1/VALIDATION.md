# 验证记录：v4.1 专家对齐

日期：2026-11-15（UTC）。基础代码包为 `mmbert_scores_v4.zip`；原 v4 的验证记录独立保留在 `validation/v4_original/`，以下均为本次新增或重跑的结果。

## 1. 完整回归

```text
404 passed, 1 warning in 12.93s
0 failed, 0 error, 0 skipped
```

执行命令：

```bash
python -m pytest -q --junitxml=validation/pytest.xml
```

覆盖原 v4 的格式转换、三维六分类、分数映射、推理、CSV、评估、服务、旧量表兼容，以及本次数据分源、训练与比较的新逻辑。唯一 warning 来自 Starlette/AnyIO 的依赖弃用提示，没有影响用例结果。

新增测试包括 48 项数据准备检查、28 项专家训练检查、17 项运行器/比较检查。专家阶段的真实 CPU 续训测试包含 dropout、梯度累积 2、长度分组：从 checkpoint 1、3、4 分别恢复到第 5 步，所有最终参数与连续训练逐位一致。缺优化器、调度器、随机状态或不匹配数据指纹的恢复会被拒绝。

## 2. 新专家对齐流程：真实 CPU 端到端

运行：

```bash
python scripts/smoke_alignment.py --work-dir /tmp/mmbert-v41-alignment-smoke
```

| 检查 | 结果 |
| --- | --- |
| fixture / 数据准备 | 通过；使用本地随机 tiny ModernBERT，无网络下载 |
| `staged` | 自动标签训练 → 专家微调 → 专家验证选择 → 显式选择后测试，通过 |
| `staged_replay` | 通过来源校验复用同一第一阶段，完成专家 + 0.1 回放训练与验证 |
| `expert_only` | 从原始 tiny 底座完成独立专家训练与验证 |
| 三方法比较 | 合并五个候选（两个 baseline、两个 adapted、一个 expert_only），只依据专家验证选择 |
| 冻结实际效果 | 专家阶段编码器参数逐 tensor 完全不变，classifier 确实更新 |
| 推理与评分 | 选中模型保存/加载后输出 3 条预测，三个维度均为六档合法值；概率 argmax 解码一致 |
| 来源与配置完整性 | 流程中的实际代码、数据、来源权重及配置通过指纹检查 |

自检将每段训练压缩到 2 个优化器 step，并显式设 `warmup_ratio=0`，保证首个被验证的 checkpoint 已发生参数更新。它验证程序链路，不能用于判断默认正式训练参数是否最优，也不能用合成指标判断业务效果。

本版回放已验证范围是单进程、CPU、数据加载 worker 为 0。生产回放入口允许单 GPU，并明确拒绝多 GPU/DDP 或 worker 非 0 的组合；本次未实测 GPU。

## 3. 原有核心流程重新验证

```bash
python scripts/smoke_test.py \
  --num-dimensions 3 --score-values 0 2 4 6 8 10 \
  --device cpu --work-dir /tmp/mmbert-v41-core-smoke
```

fixture、train、predict、evaluate、benchmark、resume、predict_resumed 七阶段全部通过。首轮训练预算为 3 steps，恢复 checkpoint-2 时仍使用相同的 3-step 预算及相同数据，没有修改学习率调度合同。预测输出 3 条，六档标签与概率映射正确。

本地 benchmark 仅属于功能检查；其 tiny 随机模型的时间不能代表真实 mmBERT 的生产性能。

## 4. 300 专家 + 20 万自动标签的准备规模检查

| 项目 | 结果 |
| --- | ---: |
| 合成专家记录 | 300 |
| 合成自动标签记录 | 200,000 |
| 剔除与专家重叠的自动标签案例 | 300 |
| 保留自动标签 | 199,700 |
| 专家 train / validation / test | 210 / 45 / 45 |
| 自动标签 train / validation | 189,716 / 9,984 |
| 回放训练记录 | 5,000 |
| 数据准备耗时 | 17.70 秒 |
| 包括生成、准备及逐行核验的耗时 | 24.32 秒 |
| 该独立 Python 进程峰值 RSS | 73.49 MiB |

输出六个分片均通过 SHA256、字节数、行数、schema 和来源检查。自动标签使用短合成英文文本及两行一组的结构；更长的实际中文文本、更多元数据与不同组大小会改变耗时、内存和行数比例。这里测量的是数据准备，不是 20 万条真实数据的模型训练。

另验证了同时含大模型分数列与 `expert_*` 分数列的 CSV：`configs/convert_expert_columns.yaml` 正确选择专家 `[2,8,10]`，忽略大模型 `[10,0,0]` 标签列，所有分数均未进入输入文本。

## 5. 证据与环境

- `validation/pytest.xml`、`validation/pytest.log`：本次 404 项回归结果。
- `validation/integration_core_cpu.json`、`validation/integration_core_logs/`：原有七阶段核心自检。
- `validation/integration_alignment_cpu.json`、`validation/integration_alignment_logs/`：新三方法完整流程及训练/评估日志。
- `validation/alignment_data_scale_check.json`：20 万条规模验证的可复现命令、数据构造和范围说明。
- `validation/environment.json`：实际运行环境与依赖版本。
- `validation/validation_summary.json`：机器可读总结果。
- `validation/changed_files.json`：相对于原始 v4 的文件变化和内容指纹。

运行环境：Python 3.12.14、PyTorch 2.8.0+cpu、Transformers 4.57.1、Datasets 4.3.0、Accelerate 1.10.1。完整版本见环境文件。

## 6. 实际效果仍需真实专家数据确认

未提供完整 20 万条业务数据和几百条真实专家结果，因此本次没有训练业务 mmBERT，没有测量专家一致率提升，没有验证 GPU/DDP、生产吞吐量或跨环境逐位复现。

默认的冻结、学习率、12 轮上限与 0.1 回放权重是可复现的工程起点。真实数据上应按专家验证结果比较候选，固定方案后再评估尚未用于选择的专家测试集。工具允许保留未适配模型，不会把“训练完成”自动解释为“效果提高”。
