#!/usr/bin/env python3
"""Train with pseudo labels, adapt to a small expert set, and select on experts.

All split files must come from prepare_alignment_data.py. ``staged`` and
``staged_replay`` compare the unadapted source against the adapted model;
``expert_only`` provides a baseline trained directly from the original backbone.
The selected_model.json result points to existing weights, it does not copy them.
"""

from __future__ import annotations

import argparse
from copy import deepcopy
from datetime import datetime, timezone
import json
import math
import os
from pathlib import Path
import sys
from typing import Any

import yaml

from compare_alignment import checkpoint_identity, read_json, validate_selection
from five_scores.config import load_config, validate_config
from run_experiments import (
    atomic_json, code_identity, file_sha256, package_versions, resolve_backbone,
    run_logged, validate_execution_device, value_sha256,
)


PROJECT_ROOT = Path(__file__).resolve().parent
PROVENANCE_FILE = "alignment_source_provenance.json"
METHODS = ("staged", "staged_replay", "expert_only")
SPLITS = ("expert_train", "expert_validation", "expert_test", "pseudo_train", "pseudo_validation", "replay_train")
EXPERT_DEFAULTS = {
    "training": {
        "freeze_backbone": True, "num_train_epochs": 12, "max_steps": -1,
        "learning_rate": 5e-6, "head_learning_rate": 2e-5,
        "per_device_train_batch_size": 16, "gradient_accumulation_steps": 1,
        "early_stopping_patience": 3, "replay_weight": 0.1, "dataloader_num_workers": 0,
    },
    "model": {"class_weight_mode": "none", "class_weights": None},
}


def _load_alignment_config(path: Path) -> dict[str, Any]:
    with path.open(encoding="utf-8") as handle:
        supplied = (json.load(handle) if path.suffix.lower() == ".json" else yaml.safe_load(handle)) or {}
    if not isinstance(supplied, dict):
        raise ValueError("Alignment configuration must be a mapping")
    extra = set(supplied) - {"base_config", "stage1", "expert", "selection"}
    if extra:
        raise ValueError(f"Unknown alignment options: {sorted(extra)}")
    result = {"base_config": "configs/train.yaml", "stage1": {}, "expert": {}, "selection": {}}
    result.update(supplied)
    if not isinstance(result["base_config"], str) or not result["base_config"]:
        raise ValueError("base_config must name a YAML/JSON training configuration")
    for name in ("stage1", "expert"):
        if not isinstance(result[name], dict) or set(result[name]) - {"model", "data", "training"}:
            raise ValueError(f"{name} must contain only model/data/training override mappings")
    result["selection"] = validate_selection(result["selection"])
    return result


def _override(base: dict[str, Any], override: dict[str, Any]) -> dict[str, Any]:
    result = deepcopy(base)
    for section, values in override.items():
        if section not in {"model", "data", "training"} or not isinstance(values, dict):
            raise ValueError("Stage overrides must be model/data/training mappings")
        extra = set(values) - set(result[section])
        if extra:
            raise ValueError(f"Unknown {section} stage options: {sorted(extra)}")
        result[section].update(values)
    return result


def dataset_fingerprint(manifest: dict[str, Any]) -> str:
    """Portable identity: bind all expert splits, pseudo/replay pools, and policy."""
    return value_sha256({
        "dimension_names": manifest["dimension_names"], "score_values": manifest["score_values"],
        "files": {name: {key: manifest["files"][name][key] for key in ("sha256", "rows", "label_source")} for name in SPLITS},
        "overlap_policy": manifest["overlap_policy"],
    })


def _verify_source_training(model: Path, prepared: dict[str, Any]) -> tuple[dict[str, Any] | None, list[str]]:
    provenance_path = model / "provenance.json"
    if not provenance_path.is_file():
        return None, ["missing final/provenance.json from train.py"]
    training = read_json(provenance_path)
    errors = []
    if training.get("training_stage") != "pseudo":
        errors.append("source training_stage was not pseudo")
    for key, split in (("train", "pseudo_train"), ("validation", "pseudo_validation")):
        if (training.get("data_files", {}).get(key) or {}).get("sha256") != prepared["files"][split]["sha256"]:
            errors.append(f"source {key} file hash differs from the current {split} split")
    if training.get("replay_weight", 0) != 0 or training.get("data_files", {}).get("replay") is not None:
        errors.append("pseudo source unexpectedly included replay data")
    return training, errors


def verify_source_checkpoint(model: Path, prepared: dict[str, Any], *, allow_unverified: bool) -> tuple[dict[str, Any], dict[str, Any]]:
    identity = checkpoint_identity(model, names=prepared["dimension_names"], values=prepared["score_values"])
    record_path = model / PROVENANCE_FILE
    errors = []
    if not record_path.is_file():
        errors.append(f"missing {PROVENANCE_FILE}")
        record = None
    else:
        record = read_json(record_path)
        if record.get("schema_version") != 1 or record.get("stage") != "pseudo_pretraining":
            errors.append("source alignment provenance has an unsupported schema/stage")
        if record.get("dataset_fingerprint") != dataset_fingerprint(prepared):
            errors.append("source dataset fingerprint differs from current prepared expert/pseudo splits")
        if record.get("model_sha256") != identity["sha256"]:
            errors.append("source serving files differ from their alignment provenance")
    training, training_errors = _verify_source_training(model, prepared)
    errors.extend(training_errors)
    if record is not None and training is not None:
        if record.get("training_provenance_sha256") != file_sha256(model / "provenance.json"):
            errors.append("source training provenance changed after the pseudo stage completed")
    if errors and not allow_unverified:
        raise ValueError(
            "Cannot verify that --source-model was trained on the current expert-excluded pseudo splits: "
            + "; ".join(errors)
            + ". Retrain stage 1 on the prepared data, or explicitly use --allow-unverified-source "
              "to retain an unverified/leakage-risk label in every result."
        )
    verification = {
        "status": "unverified" if errors else "verified", "reused_source": True,
        "reasons": errors, "allow_unverified_source": bool(allow_unverified),
        "scope": "Local provenance/file consistency, not an independent audit of historical data access.",
    }
    return identity, verification


def _paths_disjoint(first: Path, second: Path, description: str) -> None:
    if first == second or first.is_relative_to(second) or second.is_relative_to(first):
        raise ValueError(f"Output and {description} must not contain one another")


def _prepare_stage(config: dict[str, Any], prepared: dict[str, Any], data_dir: Path,
                   output: Path, name: str, options: argparse.Namespace, selection: dict[str, Any]) -> dict[str, Any]:
    data, training, model = config["data"], config["training"], config["model"]
    if model["dimension_names"] != prepared["dimension_names"] or model["score_values"] != prepared["score_values"]:
        raise ValueError(f"{name} model dimension names/order and score_values must match the prepared manifest")
    if len(model["dimension_names"]) != 3 or model["score_values"] != [0, 2, 4, 6, 8, 10]:
        raise ValueError("Expert alignment is defined here for three dimensions with scores [0,2,4,6,8,10]")
    if data["max_train_samples"] is not None or data["max_eval_samples"] is not None:
        raise ValueError("Alignment uses the full prepared splits; set data.max_train_samples and max_eval_samples to null")
    if training["resume_from_checkpoint"]:
        raise ValueError("Alignment stages are new runs; do not use resume_from_checkpoint. Reuse stage 1 with --source-model")
    if data["text_column"] != "text" or data["scores_column"] != "scores" or data["score_columns"] is not None or data["exclude_all_three"]:
        raise ValueError("Prepared alignment data requires canonical text/scores with exclude_all_three=false")
    train_split, validation_split = (("pseudo_train", "pseudo_validation") if name == "stage1" else ("expert_train", "expert_validation"))
    for split in (train_split, validation_split):
        if prepared["files"][split]["rows"] < 1:
            raise ValueError(f"Required split is empty: {split}")
    data.update({"train_file": str(data_dir / prepared["files"][train_split]["path"]),
                 "validation_file": str(data_dir / prepared["files"][validation_split]["path"]),
                 "replay_file": None})
    training.update({"output_dir": str(output / name), "resume_from_checkpoint": None,
                     "stage": "pseudo" if name == "stage1" else "expert"})
    if name == "expert":
        training.update({"metric_for_best_model": selection["metric"], "greater_is_better": True})
    else:
        training["greater_is_better"] = True
    if name == "expert" and options.method == "staged_replay":
        if prepared["files"]["replay_train"]["rows"] < 1:
            raise ValueError("staged_replay requires a nonempty replay_train split")
        if training["replay_weight"] <= 0:
            raise ValueError("staged_replay requires expert.training.replay_weight > 0")
        data["replay_file"] = str(data_dir / prepared["files"]["replay_train"]["path"])
    else:
        training["replay_weight"] = 0.0
    if options.seed is not None:
        training["seed"] = options.seed
    if options.precision is not None:
        training["precision"] = options.precision
    if options.cpu:
        training.update({"use_cpu": True, "precision": "fp32", "tf32": False})
    if options.text_template_file is not None:
        data["text_template_file"] = options.text_template_file
    if data["text_template_file"]:
        template_path = Path(data["text_template_file"]).expanduser().resolve()
        if not template_path.is_file():
            raise ValueError(f"Text template does not exist: {template_path}")
        template = read_json(template_path)
        if template.get("dimension_names") != model["dimension_names"] or template.get("score_values") != model["score_values"]:
            raise ValueError("Text template dimension names/order or score_values differ from the prepared task")
        data["text_template_file"] = str(template_path)
    metric = training["metric_for_best_model"].removeprefix("eval_")
    if metric not in {"accuracy", "exact_accuracy", "row_exact_match", "all_dimensions_accuracy"}:
        raise ValueError("Alignment stages must select checkpoints using an exact-agreement validation metric")
    training["metric_for_best_model"] = metric
    epochs, steps = training["num_train_epochs"], training["max_steps"]
    if isinstance(epochs, bool) or not isinstance(epochs, (int, float)) or not math.isfinite(epochs) or epochs <= 0:
        raise ValueError("num_train_epochs must be finite and positive")
    if isinstance(steps, bool) or not isinstance(steps, int) or steps == 0 or steps < -1:
        raise ValueError("max_steps must be -1 or a positive integer")
    return validate_config(config)


def build_plan(options: argparse.Namespace) -> tuple[dict[str, Any], dict[str, dict[str, Any]]]:
    from five_scores.alignment_data import load_alignment_manifest

    if options.source_model and options.method == "expert_only":
        raise ValueError("expert_only starts from an original pretrained backbone; --source-model is only for staged methods")
    if options.source_model and options.model:
        raise ValueError("Choose --model for original pretraining, or --source-model for stage-1 reuse, not both")
    if options.allow_unverified_source and not options.source_model:
        raise ValueError("--allow-unverified-source requires --source-model")
    output = Path(options.output_dir).expanduser().resolve()
    if output.exists() and (not output.is_dir() or any(output.iterdir())):
        raise FileExistsError(f"Output must be a new or empty directory: {output}. To reuse stage 1, choose a new output and --source-model")
    config_path = Path(options.config).expanduser().resolve()
    requested = _load_alignment_config(config_path)
    base_path = Path(requested["base_config"]).expanduser()
    base_path = (PROJECT_ROOT / base_path).resolve() if not base_path.is_absolute() else base_path.resolve()
    base = load_config(base_path)
    prepared_path = (Path(options.data_dir).expanduser().resolve() / "alignment_manifest.json")
    prepared = load_alignment_manifest(prepared_path, verify_files=True)
    data_dir = prepared_path.parent
    _paths_disjoint(output, data_dir, "prepared data")
    if not prepared.get("overlap_policy", {}).get("excludes_all_expert_from_pseudo"):
        raise ValueError("The prepared manifest must exclude all expert cases from every pseudo pool")
    if options.evaluate_test and prepared["files"]["expert_test"]["rows"] < 1:
        raise ValueError("--evaluate-test requires a nonempty held-out expert_test split")
    expert = _prepare_stage(_override(_override(base, EXPERT_DEFAULTS), requested["expert"]), prepared, data_dir, output, "expert", options, requested["selection"])
    configs = {}
    verification = {"status": "verified", "reused_source": False, "reasons": [],
                    "scope": "Original pretrained backbone plus this run's recorded expert-excluded prepared data; local consistency only."}
    if options.source_model:
        source_model = Path(options.source_model).expanduser().resolve()
        _paths_disjoint(output, source_model, "source checkpoint")
        identity, verification = verify_source_checkpoint(source_model, prepared, allow_unverified=options.allow_unverified_source)
        source_config = read_json(source_model / "config.json")
        if source_config.get("score_pooling", "mean") != expert["model"]["pooling"]:
            raise ValueError("Expert pooling differs from the source checkpoint; preserve the source pooling")
        if source_config.get("score_max_length") != expert["data"]["max_length"]:
            raise ValueError("Expert max_length must equal the source checkpoint score_max_length so a selected baseline retains the evaluated inference behavior")
        if expert["data"]["text_template_file"]:
            supplied_template = read_json(Path(expert["data"]["text_template_file"]))
            if source_config.get("score_text_template") != supplied_template:
                raise ValueError("The explicit expert text template differs from or is missing in the source checkpoint; preserve the source's preprocessing for a comparable baseline")
        source = str(source_model)
    else:
        initial = deepcopy(expert) if options.method == "expert_only" else _prepare_stage(
            _override(base, requested["stage1"]), prepared, data_dir, output, "stage1", options, requested["selection"])
        if options.model:
            initial["model"]["name_or_path"] = options.model
        source, identity = resolve_backbone(initial["model"]["name_or_path"], initial["model"]["revision"], dry_run=options.dry_run)
        if identity.get("path"):
            _paths_disjoint(output, Path(identity["path"]), "pretrained backbone")
        if options.method != "expert_only":
            stage1 = initial
            stage1["model"]["name_or_path"] = source
            if identity.get("resolved_commit"):
                stage1["model"]["revision"] = identity["resolved_commit"]
            if stage1["model"]["pooling"] != expert["model"]["pooling"]:
                raise ValueError("Stage 1 and expert adaptation must use the same pooling")
            if stage1["data"]["max_length"] != expert["data"]["max_length"]:
                raise ValueError("Stage 1 and expert adaptation must use the same max_length so baseline selection preserves inference behavior")
            template_values = [read_json(Path(config["data"]["text_template_file"])) if config["data"]["text_template_file"] else None for config in (stage1, expert)]
            if template_values[0] != template_values[1]:
                raise ValueError("Stage 1 and expert adaptation must use the same text template")
            configs["stage1"] = stage1
            source = str(output / "stage1" / "final")
    expert["model"]["name_or_path"] = source
    configs["expert"] = expert
    if any(config["training"]["use_cpu"] != expert["training"]["use_cpu"] for config in configs.values()):
        raise ValueError("All stages must run on the same CPU/GPU mode")
    data = {name: {**prepared["files"][name], "path": str(data_dir / prepared["files"][name]["path"])} for name in SPLITS}
    candidate_names = ["expert_only"] if options.method == "expert_only" else ["baseline", "adapted"]
    templates = {config["data"]["text_template_file"] for config in configs.values() if config["data"]["text_template_file"]}
    manifest = {
        "pipeline": "mmbert_scores.run_alignment.v1", "schema_version": 1, "method": options.method,
        "output_dir": str(output), "alignment_config": {"path": str(config_path), "sha256": file_sha256(config_path)},
        "base_config": {"path": str(base_path), "sha256": file_sha256(base_path)},
        "data_manifest": {"path": str(prepared_path), "sha256": file_sha256(prepared_path)},
        "dataset_fingerprint": dataset_fingerprint(prepared), "data": data,
        "schema": {"dimension_names": prepared["dimension_names"], "score_values": prepared["score_values"]},
        "text_templates": {path: file_sha256(Path(path)) for path in sorted(templates)},
        "source_identity": identity, "source_verification": verification,
        "selection": requested["selection"], "candidate_names": candidate_names,
        "evaluate_test": options.evaluate_test,
        "test_policy": "Only the expert-validation-selected candidate is optionally evaluated on expert_test; no test result enters selection.",
        "stages": [{"name": name, "config_path": str(output / "configs" / f"{name}.json"),
                    "config_sha256": value_sha256(config), "run_dir": config["training"]["output_dir"],
                    "training_stage": config["training"]["stage"], "freeze_backbone": config["training"]["freeze_backbone"],
                    "replay_weight": config["training"]["replay_weight"], "replay_file": config["data"]["replay_file"]}
                   for name, config in configs.items()],
        "code_sha256": code_identity(), "package_versions": package_versions(),
        "checkpoint_selection_note": "Within expert training, checkpoints use the primary exact metric. The final source/adapted comparison uses secondary_metric and prefers baseline on full ties.",
    }
    manifest["pipeline_signature"] = value_sha256(manifest)
    return manifest, configs


def _check_inputs(manifest: dict[str, Any]) -> None:
    for entry in [manifest["data_manifest"], manifest["alignment_config"], manifest["base_config"], *manifest["data"].values()]:
        if file_sha256(Path(entry["path"])) != entry["sha256"]:
            raise ValueError(f"Input changed during the pipeline: {entry['path']}")
    for path, fingerprint in manifest["text_templates"].items():
        if file_sha256(Path(path)) != fingerprint:
            raise ValueError(f"Text template changed during the pipeline: {path}")
    if code_identity() != manifest["code_sha256"]:
        raise ValueError("Training/evaluation code changed during the pipeline")
    source = manifest["source_identity"]
    if source.get("path"):
        for relative, fingerprint in source["files"].items():
            if file_sha256(Path(source["path"]) / relative) != fingerprint:
                raise ValueError("Source model files changed during the pipeline")


def evaluation_command(model: str, data: str, report: Path, predictions: Path, config: dict[str, Any]) -> list[str]:
    return [
        sys.executable, str(PROJECT_ROOT / "evaluate.py"), "--model", model, "--data", data,
        "--output", str(report), "--predictions-output", str(predictions),
        "--device", "cpu" if config["training"]["use_cpu"] else "cuda",
        "--precision", config["training"]["precision"],
        "--batch-size", str(config["training"]["per_device_eval_batch_size"]),
        "--max-length", str(config["data"]["max_length"]),
        "--attn-implementation", config["model"]["attn_implementation"], "--include-all-three",
    ]


def initialize_pipeline(manifest: dict[str, Any], configs: dict[str, dict[str, Any]]) -> None:
    output = Path(manifest["output_dir"])
    if output.exists() and (not output.is_dir() or any(output.iterdir())):
        raise FileExistsError(f"Output must be new or empty: {output}")
    output.mkdir(parents=True, exist_ok=True)
    # mkdir is the ownership operation. A competing invocation cannot write
    # configs into this run after acquiring the same directory concurrently.
    (output / "configs").mkdir(exist_ok=False)
    for stage in manifest["stages"]:
        atomic_json(Path(stage["config_path"]), configs[stage["name"]])
    atomic_json(output / "pipeline_manifest.json", manifest)


def execute_pipeline(manifest: dict[str, Any], configs: dict[str, dict[str, Any]]) -> dict[str, Any]:
    from compare_alignment import summarize_alignment
    from five_scores.alignment_data import load_alignment_manifest

    output = Path(manifest["output_dir"])
    state: dict[str, Any] = {"pipeline_signature": manifest["pipeline_signature"], "status": "running", "completed_stages": []}
    atomic_json(output / "pipeline_state.json", state)
    try:
        for stage in manifest["stages"]:
            _check_inputs(manifest)
            if value_sha256(load_config(stage["config_path"])) != stage["config_sha256"]:
                raise ValueError("Generated stage configuration changed before training")
            name = stage["name"]
            if name == "expert" and "stage1" in configs:
                prepared = load_alignment_manifest(manifest["data_manifest"]["path"], verify_files=True)
                verify_source_checkpoint(Path(configs["expert"]["model"]["name_or_path"]), prepared, allow_unverified=False)
            run_logged([sys.executable, str(PROJECT_ROOT / "train.py"), "--config", stage["config_path"]], output / "logs" / f"{name}.train.log")
            final = Path(stage["run_dir"]) / "final"
            summary = read_json(final / "training_summary.json")
            if not isinstance(summary.get("global_step"), int) or summary["global_step"] <= 0:
                raise RuntimeError(f"{name} did not complete any optimization steps")
            identity = checkpoint_identity(final, names=manifest["schema"]["dimension_names"], values=manifest["schema"]["score_values"])
            _check_inputs(manifest)
            if name == "stage1":
                prepared = load_alignment_manifest(manifest["data_manifest"]["path"], verify_files=True)
                _, errors = _verify_source_training(final, prepared)
                if errors:
                    raise RuntimeError("Stage 1 training provenance mismatch: " + "; ".join(errors))
                atomic_json(final / PROVENANCE_FILE, {
                    "schema_version": 1, "stage": "pseudo_pretraining",
                    "dataset_fingerprint": manifest["dataset_fingerprint"],
                    "prepared_manifest_sha256": manifest["data_manifest"]["sha256"],
                    "pipeline_signature": manifest["pipeline_signature"], "stage_config_sha256": stage["config_sha256"],
                    "model_sha256": identity["sha256"], "training_provenance_sha256": file_sha256(final / "provenance.json"),
                    "excluded_expert_splits": {key: manifest["data"][key]["sha256"] for key in ("expert_train", "expert_validation", "expert_test")},
                    "note": "All expert cases were excluded from the prepared pseudo pools. This records local pipeline provenance, not an independent historical-access audit.",
                })
            state["completed_stages"].append(name)
            atomic_json(output / "pipeline_state.json", state)
        expert_config = configs["expert"]
        candidates = []
        for name in manifest["candidate_names"]:
            model = expert_config["model"]["name_or_path"] if name == "baseline" else str(output / "expert" / "final")
            report = output / "validation" / f"{name}.json"
            predictions = output / "validation" / f"{name}.predictions.jsonl"
            before = checkpoint_identity(model)
            run_logged(evaluation_command(model, manifest["data"]["expert_validation"]["path"], report, predictions, expert_config), output / "logs" / f"{name}.validation.log")
            after = checkpoint_identity(model)
            if before != after:
                raise ValueError("Candidate checkpoint changed during evaluation")
            candidates.append({"name": name, "model": model, "model_identity": after,
                               "validation_report": str(report), "validation_report_sha256": file_sha256(report),
                               "validation_predictions": str(predictions), "validation_predictions_sha256": file_sha256(predictions)})
            _check_inputs(manifest)
        atomic_json(output / "validation_candidates.json", {"pipeline_signature": manifest["pipeline_signature"], "candidates": candidates})
        comparison = summarize_alignment([output])
        selected = comparison["selected_model"]
        state["selected_model"] = selected
        state["test_evaluated"] = False
        atomic_json(output / "pipeline_state.json", state)
        if manifest["evaluate_test"]:
            run_logged(evaluation_command(selected["model_path"], manifest["data"]["expert_test"]["path"], output / "expert_test_metrics.json", output / "expert_test_predictions.jsonl", expert_config), output / "logs" / "selected.test.log")
            state["test_evaluated"] = True
            state["test_metrics_sha256"] = file_sha256(output / "expert_test_metrics.json")
        _check_inputs(manifest)
        state.update({"status": "complete", "completed_utc": datetime.now(timezone.utc).isoformat()})
        atomic_json(output / "pipeline_state.json", state)
        return comparison
    except BaseException as error:
        state.update({"status": "failed", "error": str(error)})
        atomic_json(output / "pipeline_state.json", state)
        raise


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", default=str(PROJECT_ROOT / "configs" / "alignment.yaml"), help="Alignment YAML/JSON; base_config paths are relative to the project root")
    parser.add_argument("--data-dir", required=True, help="Directory created by prepare_alignment_data.py, containing alignment_manifest.json")
    parser.add_argument("--output-dir", default="outputs/alignment-staged", help="New or empty output; runs are never merged or resumed implicitly")
    parser.add_argument("--method", choices=METHODS, default="staged")
    parser.add_argument("--model", help="Original pretrained mmBERT directory or Hub repository, for a fresh stage 1/expert_only run")
    parser.add_argument("--source-model", help="Local stage1/final checkpoint; skip pseudo training and begin a NEW expert run")
    parser.add_argument("--allow-unverified-source", action="store_true", help="Explicitly accept missing/mismatched source provenance; every result remains marked unverified and may contain expert leakage")
    parser.add_argument("--text-template-file", help="Converted original-field template, copied into each stage's inference metadata")
    parser.add_argument("--seed", type=int)
    parser.add_argument("--precision", choices=["auto", "bf16", "fp16", "fp32"])
    parser.add_argument("--cpu", action="store_true", help="For tiny functional checks; forces fp32")
    parser.add_argument("--dry-run", action="store_true", help="Validate data/config/source provenance and print a plan without training, writing outputs or downloading a Hub model")
    parser.add_argument("--evaluate-test", action="store_true", help="After validation-only selection, evaluate ONLY the selected candidate on held-out expert_test; reserve for the final chosen method")
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> None:
    options = parse_args(argv)
    if any(key in os.environ for key in ("RANK", "LOCAL_RANK", "WORLD_SIZE")):
        raise ValueError("Launch run_alignment.py with ordinary python, not torchrun/DDP; it controls one process/GPU")
    manifest, configs = build_plan(options)
    if options.dry_run:
        print(json.dumps({"dry_run": True, "manifest": manifest, "resolved_stage_configs": configs}, ensure_ascii=False, indent=2, allow_nan=False))
        return
    validate_execution_device(configs["expert"])
    initialize_pipeline(manifest, configs)
    result = execute_pipeline(manifest, configs)
    print(json.dumps({"status": "complete", "selected_model": result["selected_model"],
                      "note": "selected_model.json points to existing checkpoint weights; no model copy was made."}, ensure_ascii=False, indent=2, allow_nan=False))


if __name__ == "__main__":
    try:
        main()
    except (ValueError, FileExistsError, RuntimeError) as error:
        print(f"ERROR: {error}", file=sys.stderr)
        sys.exit(1)
