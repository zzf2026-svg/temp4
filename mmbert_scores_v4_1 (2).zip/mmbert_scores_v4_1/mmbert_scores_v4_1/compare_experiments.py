#!/usr/bin/env python3
"""Compare one controlled suite using held-out validation reports, never test labels."""

from __future__ import annotations

import argparse
from copy import deepcopy
import csv
import hashlib
import json
import math
import os
from pathlib import Path
import re
import tempfile
from typing import Any

from five_scores.config import load_config
from five_scores.schema import LEGACY_SCORE_VALUES, validate_score_values


SUMMARY_METRICS = (
    "exact_accuracy", "all_dimensions_accuracy", "low_to_nonlow_rate",
    "high_to_nonhigh_rate", "middle_to_nonmiddle_rate", "endpoint_boundary_error_rate",
    "row_any_boundary_violation_rate", "group_mismatch_rate", "macro_f1", "qwk", "mae",
    "severe_error_rate", "max_endpoint_directional_error_rate", "endpoint_directional_coverage",
)
CONDITIONAL = ("low_to_nonlow", "high_to_nonhigh", "middle_to_nonmiddle", "endpoint_boundary_error")
DIMENSION_LABELS = {
    "authenticity": "真实性", "value": "价值感", "relevance": "相关性",
    "severity": "严重程度", "effectiveness": "解决效果", "innovativeness": "创新程度",
    "feasibility": "实现可行性",
    "novelty_score": "新颖性", "demand_score": "需求性", "quality_score": "质量",
}


def _read_json(path: Path) -> dict[str, Any]:
    with path.open(encoding="utf-8") as handle:
        value = json.load(handle)
    if not isinstance(value, dict):
        raise ValueError(f"Expected a JSON object: {path}")
    return value


def _path(value: str, suite_dir: Path) -> Path:
    path = Path(value).expanduser()
    return (path if path.is_absolute() else suite_dir / path).resolve()


def _prefix(name: str) -> str:
    return re.sub(r"[^\w]+", "_", name, flags=re.UNICODE).strip("_")


def _close(actual: Any, expected: float | int | None, context: str) -> None:
    if expected is None:
        if actual is not None:
            raise ValueError(f"{context}: undefined denominator must produce null")
    elif (isinstance(actual, bool) or not isinstance(actual, (int, float))
          or not math.isfinite(actual) or not math.isclose(actual, expected, rel_tol=1e-9, abs_tol=1e-10)):
        raise ValueError(f"{context}: {actual!r} does not match expected {expected!r}")


def _ratio(numerator: int, denominator: int) -> float | None:
    return numerator / denominator if denominator else None


def _config_for_comparison(config: dict[str, Any], *, remove_objective: bool) -> dict[str, Any]:
    value = deepcopy(config)
    training = value["training"]
    training.pop("output_dir", None)
    training.pop("resume_from_checkpoint", None)
    training["metric_for_best_model"] = training["metric_for_best_model"].removeprefix("eval_")
    if training["greater_is_better"] is None:
        metric = training["metric_for_best_model"]
        training["greater_is_better"] = not (
            metric in {"loss", "mae", "mse", "rmse"}
            or metric.endswith(("_loss", "_mae", "_mse", "_rmse", "_error_rate"))
            or ("_to_" in metric and metric.endswith("_rate"))
        )
    if remove_objective:
        for key in ("boundary_weight", "class_weight_mode", "class_weights"):
            value["model"].pop(key, None)
    return value


def _validate_report(report: dict[str, Any], config: dict[str, Any], experiment: dict[str, Any],
                     manifest: dict[str, Any], run_dir: Path) -> tuple[list[str], list[list[int]]]:
    name = experiment["name"]
    names = report.get("dimensions")
    if names != config["model"]["dimension_names"]:
        raise ValueError(f"{name}: evaluation dimensions/order differ from its training config")
    values = validate_score_values(report.get("score_values", LEGACY_SCORE_VALUES))
    if values != list(config["model"].get("score_values", LEGACY_SCORE_VALUES)):
        raise ValueError(f"{name}: evaluation score_values differ from its training config")
    classes = len(values)
    legacy = tuple(values) == LEGACY_SCORE_VALUES
    count = report.get("examples")
    if isinstance(count, bool) or not isinstance(count, int) or count <= 0:
        raise ValueError(f"{name}: examples must be a positive integer")
    if report.get("num_dimensions") != len(names) or report.get("num_classes") != classes:
        raise ValueError(f"{name}: report dimension/class schema is inconsistent")
    if report.get("input_sha256") != manifest["data"]["validation"]["sha256"]:
        raise ValueError(f"{name}: input_sha256 does not match the suite validation file")
    for key in ("evaluated_data_sha256", "model_config_sha256"):
        if not isinstance(report.get(key), str) or not re.fullmatch(r"[0-9a-f]{64}", report[key]):
            raise ValueError(f"{name}: missing or invalid {key}; regenerate with this version of evaluate.py")
    saved_model_config = run_dir / "final" / "config.json"
    if saved_model_config.is_file():
        current_sha256 = hashlib.sha256(saved_model_config.read_bytes()).hexdigest()
        if current_sha256 != report["model_config_sha256"]:
            raise ValueError(f"{name}: final/config.json changed after evaluation; regenerate the report")
    if Path(report.get("model", "")).resolve() != (run_dir / "final").resolve():
        raise ValueError(f"{name}: report was not produced from this experiment's final model")
    if report.get("max_length") != config["data"]["max_length"]:
        raise ValueError(f"{name}: evaluation max_length differs from training")
    expected_schema = {key: config["data"][key] for key in ("text_column", "scores_column", "score_columns")}
    expected_schema["exclude_all_three"] = config["data"]["exclude_all_three"]
    if report.get("input_schema") != expected_schema:
        raise ValueError(f"{name}: evaluation input_schema differs from its training input schema")
    metrics = report.get("metrics", {})
    if not isinstance(metrics, dict) or any(
        value is not None and (isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value))
        for value in metrics.values()
    ):
        raise ValueError(f"{name}: metrics must contain finite numbers or null")
    for key, expected in (("num_examples", count), ("num_decisions", count * len(names))):
        _close(metrics.get(key), expected, f"{name}.{key}")
    matrices = report.get("confusion_matrices", {})
    supports: list[list[int]] = []
    total_correct = 0
    pooled_events = {key: [0, 0] for key in CONDITIONAL} if legacy else {}
    for dimension in names:
        prefix = _prefix(dimension)
        matrix = matrices.get(dimension)
        if (not isinstance(matrix, list) or len(matrix) != classes
                or any(not isinstance(row, list) or len(row) != classes for row in matrix)
                or any(isinstance(x, bool) or not isinstance(x, int) or x < 0 for row in matrix for x in row)
                or sum(map(sum, matrix)) != count):
            raise ValueError(f"{name}.{dimension}: invalid {classes}x{classes} confusion matrix or sample total")
        teacher = [sum(row) for row in matrix]
        predicted = [sum(row[i] for row in matrix) for i in range(classes)]
        supports.append(teacher)
        correct = sum(matrix[i][i] for i in range(classes))
        total_correct += correct
        _close(metrics.get(f"{prefix}_exact_accuracy"), correct / count, f"{name}.{dimension}.exact_accuracy")
        conditions = {}
        if legacy:
            conditions = {
                "low_to_nonlow": (sum(sum(matrix[i][2:]) for i in (0, 1)), sum(teacher[:2])),
                "high_to_nonhigh": (sum(sum(matrix[i][:3]) for i in (3, 4)), sum(teacher[3:])),
                "middle_to_nonmiddle": (sum(matrix[2]) - matrix[2][2], teacher[2]),
            }
            conditions["endpoint_boundary_error"] = tuple(
                conditions["low_to_nonlow"][i] + conditions["high_to_nonhigh"][i] for i in (0, 1)
            )
        for metric, (events, support) in conditions.items():
            pooled_events[metric][0] += events
            pooled_events[metric][1] += support
            for suffix, expected in (("count", events), ("support", support), ("rate", _ratio(events, support))):
                _close(metrics.get(f"{prefix}_{metric}_{suffix}"), expected, f"{name}.{dimension}.{metric}_{suffix}")
        for i, score in enumerate(values):
            current = report.get("per_class_metrics", {}).get(dimension, {}).get(str(score), {})
            for key, expected in (
                ("support", teacher[i]), ("predicted_count", predicted[i]), ("correct_count", matrix[i][i]),
                ("recall", _ratio(matrix[i][i], teacher[i])), ("precision", _ratio(matrix[i][i], predicted[i])),
            ):
                _close(current.get(key), expected, f"{name}.{dimension}.score_{score}.{key}")
    for metric, (events, support) in pooled_events.items():
        for suffix, expected in (("count", events), ("support", support), ("rate", _ratio(events, support))):
            _close(metrics.get(f"{metric}_{suffix}"), expected, f"{name}.{metric}_{suffix}")
    for key, expected in (("exact_match_count", total_correct), ("exact_accuracy", total_correct / (count * len(names))),
                          ("accuracy", total_correct / (count * len(names)))):
        _close(metrics.get(key), expected, f"{name}.{key}")
    row_count = metrics.get("row_exact_match_count")
    if isinstance(row_count, bool) or not isinstance(row_count, int) or not 0 <= row_count <= count:
        raise ValueError(f"{name}: invalid row_exact_match_count")
    lower_bound = max(0, total_correct - count * (len(names) - 1))
    upper_bound = min(sum(matrices[d][i][i] for i in range(classes)) for d in names)
    if not lower_bound <= row_count <= upper_bound:
        raise ValueError(f"{name}: row exact matches are inconsistent with dimension-level exact matches")
    for key in ("all_dimensions_accuracy", "row_exact_match"):
        _close(metrics.get(key), row_count / count, f"{name}.{key}")
    return names, supports


def _atomic_text(path: Path, text: str) -> None:
    with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8", dir=path.parent, delete=False) as handle:
        temporary = Path(handle.name)
        handle.write(text)
    try:
        os.replace(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)


def _write_json(path: Path, value: Any) -> None:
    _atomic_text(path, json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n")


def _write_csv(path: Path, rows: list[dict[str, Any]], empty_fields: tuple[str, ...]) -> None:
    fields = list(dict.fromkeys(key for row in rows for key in row)) or list(empty_fields)
    with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8-sig", newline="", dir=path.parent, delete=False) as handle:
        temporary = Path(handle.name)
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)
    try:
        os.replace(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)


def _pct(value: float | None) -> str:
    return "—" if value is None else f"{100 * value:.2f}%"


def _markdown(result: dict[str, Any]) -> str:
    rows = result["experiments"]
    values = result["score_values"]
    minimum, maximum = values[0], values[-1]
    legacy = tuple(values) == LEGACY_SCORE_VALUES
    reference = result["reference_experiment"] or "参考实验"
    headings = ["实验", "逐维精确一致率", "全维全对率", f"{minimum} 分召回率", f"{maximum} 分召回率"]
    keys = ["exact_accuracy", "all_dimensions_accuracy", f"score_{minimum}_recall", f"score_{maximum}_recall"]
    if legacy:
        headings += ["低分越界率", "高分越界率", "3 分误判率"]
        keys += ["low_to_nonlow_rate", "high_to_nonhigh_rate", "middle_to_nonmiddle_rate"]
    lines = [
        "# mmBERT 评分模型对照结果", "", f"状态：**{'全部完成' if result['status'] == 'complete' else '尚未全部完成'}**。",
        "", f"分数集合：`{values}`。所有分数不一致均计错。下表来自相同验证集，尚未用于报告独立测试集效果。",
        *( ["", "旧量表中 1↔2 和 4↔5 仍计入精确一致率的错误。"] if legacy else [] ),
        "", "## 总体结果", "",
        "| " + " | ".join(headings) + " |",
        "|---|" + "---:|" * len(keys),
    ]
    for row in rows:
        lines.append("| " + row["experiment"] + " | " + " | ".join(_pct(row[key]) for key in keys) + " |")
    if result["pending_experiments"]:
        lines += ["", "待完成：" + ", ".join(result["pending_experiments"]) + "。没有生成可选模型文件。"]
    if result["selected_model"] is not None:
        selected = result["selected_model"]
        lines += [
            "", "## 验证集选择", "",
            f"按 `{selected['selection_metric']}` {'最大' if selected['greater_is_better'] else '最小'}选择 **{selected['experiment']}**，"
            f"该指标为 **{selected['selection_value']:.6f}**。",
            "", "主指标相同时按逐维精确一致率较高者选择，再按实验名排序。这里只处理实验间并列；训练过程中的 checkpoint 并列仍沿用 Trainer 原有规则。",
            "", f"模型目录：`{selected['model_dir']}`。此记录是验证集候选，不能据此宣称已达到零错误或保证未来完全一致。",
        ]
    if result["warnings"]:
        lines += ["", "## 需要一起检查的变化", ""]
        lines += ["- " + warning for warning in result["warnings"]]
    lines += [
        "", "## 分维度结果", "",
        f"| 实验 | 维度 | 精确一致率 | {minimum} 分召回率 | {minimum} 分精确率 | {maximum} 分召回率 | {maximum} 分精确率 |",
        "|---|---|---:|---:|---:|---:|---:|",
    ]
    for row in result["per_dimension"]:
        keys = ("exact_accuracy", f"score_{minimum}_recall", f"score_{minimum}_precision",
                f"score_{maximum}_recall", f"score_{maximum}_precision")
        dimension = DIMENSION_LABELS.get(row["dimension"], row["dimension"])
        lines.append("| " + row["experiment"] + " | " + dimension + " | " + " | ".join(_pct(row[key]) for key in keys) + " |")
    lines += [
        "", "## 文件与口径", "",
        f"- `summary.csv`：每个实验一行，包含主指标、端点分数表现及相对 {reference} 的百分点变化。",
        "- `per_dimension.csv`：每个实验、每个维度一行；`per_score.csv`：每个实验、维度、分数一行，包含教师数、预测数、命中数、召回率与精确率。",
        "- `comparison.json`：机器可读汇总、检查依据和候选选择；`selected_model.json` 仅在全部实验完成时生成。",
        "- CSV / JSON 的比例使用 0～1；`delta_*_pp` 是百分点差值。缺少分母时写空值 / null，表内显示 —。",
        "- 召回率分母是教师该分数的数量，精确率分母是学生预测该分数的数量。",
        f"- 总体 {minimum}/{maximum} 分召回率与精确率合并全部配置维度的计数计算；Macro-F1 与 QWK 沿用逐维计算后汇总的评估口径。",
        "- MAE 使用真实分值；例如 0 预测为 2，误差是 2 分。mae_steps（如有）使用类别档位差。",
        "- 类别权重只改变训练损失权重；所有不同分数仍按错误计算。",
        *( ["- 旧量表的低分越界率分母是教师 1/2，高分越界率分母是教师 4/5，3 分误判率分母是教师 3。"]
           if legacy else ["- 当前量表未定义低/中/高业务边界，因此不沿用旧量表的分组容错及边界指标。"] ),
        "- 文件哈希、逐条文本与标签顺序哈希、维度顺序、教师计数及配置都经过一致性检查。分数分布相同本身并不证明逐条预测一致。",
        "", "## 后续评估", "",
        "先核对候选的精确一致率及各方向错误变化，再对最终选定的一个模型运行独立测试集评估。不要根据各组测试集结果继续挑配置。",
    ]
    return "\n".join(lines) + "\n"


def summarize_suite(suite_dir: str | Path, allow_incomplete: bool = False) -> dict[str, Any]:
    """Validate a controlled suite, publish tables, and select only when complete.

    Existing metric files alone do not prove comparability. Both raw-file and
    canonical ordered text/label hashes are checked, alongside schemas and
    actual training configurations. No raw input text is copied into summaries.
    """
    root = Path(suite_dir).expanduser().resolve()
    manifest = _read_json(root / "manifest.json")
    if manifest.get("schema_version") != 1 or not isinstance(manifest.get("suite_signature"), str):
        raise ValueError("Unsupported or incomplete experiment manifest")
    experiments = manifest.get("experiments")
    if not isinstance(experiments, list) or not experiments:
        raise ValueError("Manifest must contain at least one experiment")
    names = [item["name"] for item in experiments]
    if len(set(names)) != len(names):
        raise ValueError("Duplicate experiment names in manifest")
    selection = manifest["selection"]
    metric = selection["metric"].removeprefix("eval_")
    greater = selection["greater_is_better"]
    if not isinstance(greater, bool):
        raise ValueError("Manifest selection.greater_is_better must be explicit true/false")
    # A changed/partial suite must never retain an earlier deployable candidate.
    selected_path = root / "selected_model.json"
    selected_path.unlink(missing_ok=True)
    rows: list[dict[str, Any]] = []
    dimension_rows: list[dict[str, Any]] = []
    score_rows: list[dict[str, Any]] = []
    provenance: list[dict[str, Any]] = []
    pending: list[str] = []
    invariant = None
    evaluation_identity = None
    training_budget = None
    budget_presence: list[bool] = []
    environments: list[dict[str, Any]] = []
    score_values = list(LEGACY_SCORE_VALUES)
    summary_metric_names = SUMMARY_METRICS
    for experiment in experiments:
        name = experiment["name"]
        run_dir = _path(experiment["run_dir"], root)
        config = load_config(_path(experiment["config_path"], root))
        score_values = list(config["model"].get("score_values", LEGACY_SCORE_VALUES))
        legacy = tuple(score_values) == LEGACY_SCORE_VALUES
        summary_metric_names = SUMMARY_METRICS if legacy else (
            "exact_accuracy", "all_dimensions_accuracy", "macro_f1", "qwk", "mae", "mae_steps",
            "two_or_more_steps_error_rate",
        )
        conditional_names = CONDITIONAL if legacy else ()
        if (config["model"]["boundary_weight"] != experiment["boundary_weight"]
                or config["model"]["class_weight_mode"] != experiment["class_weight_mode"]):
            raise ValueError(f"{name}: objective does not match manifest")
        common = _config_for_comparison(config, remove_objective=True)
        if invariant is not None and common != invariant:
            raise ValueError(f"{name}: shared training/data/model configuration differs between experiments")
        invariant = common
        if (common["training"]["metric_for_best_model"], common["training"]["greater_is_better"]) != (metric, greater):
            raise ValueError(f"{name}: model selection rule differs from the manifest")
        path = run_dir / "validation_metrics.json"
        if not path.is_file():
            pending.append(name)
            continue
        resolved = run_dir / "resolved_config.json"
        if not resolved.is_file():
            raise ValueError(f"{name}: missing resolved_config.json; cannot verify actual training setup")
        if _config_for_comparison(load_config(resolved), remove_objective=False) != _config_for_comparison(config, remove_objective=False):
            raise ValueError(f"{name}: actual resolved_config differs from the planned experiment")
        report = _read_json(path)
        dimensions, teacher_supports = _validate_report(report, config, experiment, manifest, run_dir)
        identity = {
            "dimensions": dimensions, "examples": report["examples"], "teacher_supports": teacher_supports,
            "score_values": score_values,
            "input_sha256": report["input_sha256"], "evaluated_data_sha256": report["evaluated_data_sha256"],
            "max_length": report["max_length"], "precision": report.get("precision"),
            "batch_size": report.get("batch_size"), "attn_implementation": report.get("attn_implementation"),
            "input_schema": report.get("input_schema"),
        }
        if evaluation_identity is not None and identity != evaluation_identity:
            raise ValueError(f"{name}: validation rows/order/schema/precision differ across experiments")
        evaluation_identity = identity
        summary_path = run_dir / "final" / "training_summary.json"
        budget_presence.append(summary_path.is_file())
        summary = _read_json(summary_path) if summary_path.is_file() else {}
        steps = summary.get("global_step")
        if steps is not None:
            if isinstance(steps, bool) or not isinstance(steps, int) or steps < 1:
                raise ValueError(f"{name}: invalid completed training global_step")
            if training_budget is not None and steps != training_budget:
                raise ValueError(f"{name}: actual training steps differ across experiments")
            training_budget = steps
        environment_path = run_dir / "environment.json"
        if environment_path.is_file():
            environment = _read_json(environment_path)
            environments.append({key: environment.get(key) for key in (
                "torch", "transformers", "datasets", "precision", "world_size", "effective_batch_size",
                "resolved_revision",
            )})
        metrics = report["metrics"]
        value = metrics.get(metric)
        if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
            raise ValueError(f"{name}: selection metric {metric} is missing or undefined")
        row: dict[str, Any] = {
            "experiment": name, "boundary_weight": experiment["boundary_weight"],
            "class_weight_mode": experiment["class_weight_mode"], "examples": report["examples"],
            "dimensions": len(dimensions), "num_decisions": metrics["num_decisions"],
            "exact_match_count": metrics["exact_match_count"], "row_exact_match_count": metrics["row_exact_match_count"],
            "selection_metric": metric, "selection_value": value,
            **{key: metrics.get(key) for key in summary_metric_names},
            "training_steps": steps, "truncation_rate": report.get("truncation_rate"),
            "model_config_verified": (run_dir / "final" / "config.json").is_file(),
        }
        for conditional in conditional_names:
            for suffix in ("count", "support"):
                row[f"{conditional}_{suffix}"] = metrics[f"{conditional}_{suffix}"]
        for score in (score_values[0], score_values[-1]):
            cells = [report["per_class_metrics"][dimension][str(score)] for dimension in dimensions]
            support, predicted, correct = (sum(cell[key] for cell in cells) for key in ("support", "predicted_count", "correct_count"))
            row.update({
                f"score_{score}_support": support, f"score_{score}_predicted_count": predicted,
                f"score_{score}_correct_count": correct, f"score_{score}_recall": _ratio(correct, support),
                f"score_{score}_precision": _ratio(correct, predicted),
            })
        row.update({"model_dir": str(run_dir / "final"), "validation_report": str(path)})
        rows.append(row)
        for dimension in dimensions:
            prefix = _prefix(dimension)
            dimension_row: dict[str, Any] = {
                "experiment": name, "dimension": dimension, "examples": report["examples"],
                **{key: metrics.get(f"{prefix}_{key}") for key in (
                    ("exact_accuracy", "macro_f1", "qwk", "mae", "severe_error_rate", "group_mismatch_rate")
                    if legacy else ("exact_accuracy", "macro_f1", "qwk", "mae", "mae_steps", "two_or_more_steps_error_rate")
                )},
            }
            for conditional in conditional_names:
                for suffix in ("rate", "count", "support"):
                    dimension_row[f"{conditional}_{suffix}"] = metrics[f"{prefix}_{conditional}_{suffix}"]
            for score in score_values:
                cell = report["per_class_metrics"][dimension][str(score)]
                score_rows.append({"experiment": name, "dimension": dimension, "score": score, **cell})
                if score in (score_values[0], score_values[-1]):
                    dimension_row.update({f"score_{score}_{key}": value for key, value in cell.items()})
            dimension_rows.append(dimension_row)
        provenance.append({
            "experiment": name, "model_config_sha256": report["model_config_sha256"],
            "validation_report": str(path), "resolved_config": str(resolved),
            "input_sha256": report["input_sha256"], "evaluated_data_sha256": report["evaluated_data_sha256"],
        })
    if pending and not allow_incomplete:
        raise ValueError("Experiments are incomplete: " + ", ".join(pending) + "; use --allow-incomplete for a partial table")
    if environments and any(item != environments[0] for item in environments[1:]):
        raise ValueError("Actual runtime versions, precision, effective batch size, or backbone revision differ across experiments")
    reference_name = "baseline" if "baseline" in names else "ce" if "ce" in names else None
    baseline = next((row for row in rows if row["experiment"] == reference_name), None)
    endpoint_metrics = tuple(f"score_{score}_{key}" for score in (score_values[0], score_values[-1])
                             for key in ("recall", "precision"))
    for row in rows:
        for key in summary_metric_names + endpoint_metrics:
            if key in {"macro_f1", "qwk", "mae", "mae_steps"}:
                continue
            row[f"delta_{key}_pp"] = (
                100 * (row[key] - baseline[key]) if baseline is not None and row[key] is not None and baseline[key] is not None else None
            )
    warnings: list[str] = []
    if not baseline:
        warnings.append(f"{reference_name or '参考实验（baseline/ce）'} 尚未完成或不在本组中；相对参考实验的差值留空。")
    if budget_presence and not all(budget_presence):
        warnings.append("部分或全部实验缺少 training_summary.json，未完整验证实际训练步数；请保留训练报告。")
    if len(environments) != len(rows):
        warnings.append("部分或全部实验缺少 environment.json，无法对全部实验核对实际运行环境。")
    if any(not row["model_config_verified"] for row in rows):
        warnings.append("部分 final/config.json 不在本机，已核对报告中的模型来源记录，但未核对对应模型当前配置文件；使用候选前请确认模型仍在。")
    selected = None
    if rows and not pending:
        ranked = sorted(rows, key=lambda row: (
            -row["selection_value"] if greater else row["selection_value"],
            -row["exact_accuracy"], row["experiment"],
        ))
        winner = ranked[0]
        selected = {
            "status": "complete", "experiment": winner["experiment"], "model_dir": winner["model_dir"],
            "validation_report": winner["validation_report"], "selection_metric": metric,
            "selection_value": winner["selection_value"], "greater_is_better": greater,
            "tie_breakers": ["exact_accuracy descending", "experiment name ascending"],
            "validation_only": True, "suite_signature": manifest["suite_signature"],
            "model_config_verified": winner["model_config_verified"],
        }
        ties = [row["experiment"] for row in rows if row["selection_value"] == winner["selection_value"]]
        if len(ties) > 1:
            warnings.append("主指标并列：" + ", ".join(ties) + "。候选由预设次级规则确定，不代表已证明这些实验存在性能差异。")
        if baseline is not None and winner is not baseline:
            if winner["exact_accuracy"] < baseline["exact_accuracy"]:
                warnings.append(f"候选的逐维精确一致率低于 {reference_name}；主指标选择不等于全部指标改善，请先核对这个取舍。")
            for key, label in (("low_to_nonlow_rate", "低分越界率"), ("high_to_nonhigh_rate", "高分越界率"),
                               ("middle_to_nonmiddle_rate", "3 分误判率")):
                if winner.get(key) is not None and baseline.get(key) is not None and winner[key] > baseline[key]:
                    warnings.append(f"候选的{label}比 {reference_name} 高 {100 * (winner[key] - baseline[key]):.2f} 个百分点。")
    result = {
        "schema_version": 1, "suite_signature": manifest["suite_signature"],
        "status": "partial" if pending else "complete", "selection": selection,
        "score_values": score_values, "reference_experiment": reference_name,
        "completed_experiments": [row["experiment"] for row in rows], "pending_experiments": pending,
        "evaluation_identity": evaluation_identity, "experiments": rows, "per_dimension": dimension_rows,
        "per_score": score_rows, "selected_model": selected, "warnings": warnings, "provenance": provenance,
        "notes": [
            "Validation-only comparison; choose a configuration before evaluating its independent test split.",
            "All unequal configured scores remain errors.",
            f"Rate columns are fractions; delta_*_pp columns are percentage-point differences against {reference_name}.",
            "Null recall/precision/boundary rates denote no eligible support, not measured zero error.",
            "Matching teacher histograms is insufficient; canonical ordered text-and-label digests must match.",
            "The training checkpoint tie policy is unchanged; the exact-accuracy tie-break is for experiments only.",
        ],
    }
    _write_csv(root / "summary.csv", rows, ("experiment", "exact_accuracy", "all_dimensions_accuracy"))
    _write_csv(root / "per_dimension.csv", dimension_rows, ("experiment", "dimension", "exact_accuracy"))
    _write_csv(root / "per_score.csv", score_rows, ("experiment", "dimension", "score", "support", "predicted_count", "correct_count", "recall", "precision"))
    _write_json(root / "comparison.json", result)
    _atomic_text(root / "comparison.md", _markdown(result))
    if selected is not None:
        _write_json(selected_path, selected)
    return result


def main(argv: list[str] | None = None) -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--suite-dir", required=True)
    parser.add_argument("--allow-incomplete", action="store_true")
    options = parser.parse_args(argv)
    try:
        result = summarize_suite(options.suite_dir, allow_incomplete=options.allow_incomplete)
    except (OSError, ValueError, KeyError, TypeError) as exc:
        parser.error(str(exc))
    print(json.dumps({
        "status": result["status"], "completed": result["completed_experiments"],
        "pending": result["pending_experiments"], "selected_model": result["selected_model"],
        "summary": str(Path(options.suite_dir).expanduser().resolve() / "comparison.md"),
    }, ensure_ascii=False, indent=2, allow_nan=False))


if __name__ == "__main__":
    main()
