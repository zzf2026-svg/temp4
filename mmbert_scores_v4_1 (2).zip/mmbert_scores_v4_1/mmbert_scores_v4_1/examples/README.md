# 示例说明

- `alignment/`：专家数据的空白 CSV 表头模板及说明；填写真实专家结果后使用。完整两来源训练流程见 `EXPERT_ALIGNMENT.md`。
- `sample_input.xlsx`：本次上传的工作簿的原样副本，只有 1 条有效记录。
- `sample_input.csv`：该工作簿 Sheet1 的 CSV 导出，保留原始重复表头，便于验证两种输入格式。
- `from_uploaded_sample/`：使用新配置对真实上传样例的转换结果。三个 0 分均保留；第 4 列文本进入 solution。
- `train.jsonl`、`validation.jsonl`、`test.jsonl`：脚本生成的三维六分类虚构样本，只用于流程验证。不能用于判断实际业务精度。
- `predict.jsonl`：用于预测命令的文本示例。

真实上传样例不足以划分训练/验证/测试集。不要复制同一条记录凑数量；正式训练使用自己的完整数据。
