# 专家数据格式模板

这两个 CSV 只有表头，没有虚构的专家标签。填入真实专家结果后才能用于训练；空模板本身不能切分或训练。

- `expert_template.csv`：专家分数占用 `novelty_score`、`demand_score`、`quality_score` 三列，使用 `configs/train.yaml` 转换。与自动标注表分开保存，不能把同一行的自动分数误当作专家分数。
- `expert_separate_columns_template.csv`：专家分数占用 `expert_novelty_score`、`expert_demand_score`、`expert_quality_score` 三列，使用 `configs/convert_expert_columns.yaml` 转换。即使原表还保留自动分数列，转换器也只把指定的专家三列当作标签。

三个维度都必须有明确分数，且只能取 `0、2、4、6、8、10`。未知评分保持缺失并补标；不能用 0 代替未知，因为 0 是合法且有意义的分数。不要平均两位专家的评分后得到 1、3、5 等非法标签；有分歧时先确定一致的最终标签。

文本只由场景、痛点、解决方案组成。专家评语、打分理由、已有分数不进入输入文本。

若同一个案例有多个版本、同一项目有多个相似条目，建议增加稳定的 `group_id` 列，并把所用转换配置的 `conversion.group_column` 改为 `group_id`。自动标注表与专家表应采用相同的分组含义。不要用每份表都从 1 开始的行号作为跨表分组键。

完整命令与训练策略见项目根目录 `EXPERT_ALIGNMENT.md`。只想验证代码链路时，运行 `scripts/smoke_alignment.py`；它自行生成明确标记的合成数据。
