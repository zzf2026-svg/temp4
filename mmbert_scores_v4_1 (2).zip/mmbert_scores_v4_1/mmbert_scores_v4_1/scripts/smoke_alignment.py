#!/usr/bin/env python3
"""Exercise expert alignment on a local random tiny ModernBERT, without downloads.

Runs staged training, reuses its verified source for replay, trains expert_only,
compares expert validation, and checks prediction/test outputs. Synthetic scores
only verify code paths; they provide no evidence about production model quality.
"""

from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import time


PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT))
from scripts.smoke_test import check_predictions, read_json, require


def _write_json(path: Path, value) -> None:
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")


def _check_frozen_backbone(source: Path, adapted: Path) -> None:
    from safetensors.torch import load_file
    import torch

    before = load_file(str(source / "model.safetensors"))
    after = load_file(str(adapted / "model.safetensors"))
    require(set(before) == set(after), "Source and adapted checkpoint tensor names differ")
    head = [name for name in before if name.startswith("classifier.")]
    backbone = [name for name in before if name not in head]
    require(bool(head) and bool(backbone), "Cannot identify the classifier and encoder tensors")
    require(all(torch.equal(before[name], after[name]) for name in backbone), "Frozen encoder weights changed during expert adaptation")
    require(any(not torch.equal(before[name], after[name]) for name in head), "Expert adaptation did not update the classifier")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--work-dir", type=Path, help="New or empty directory; retain logs and models here")
    parser.add_argument("--stage-timeout", type=int, default=600, help="Maximum seconds for each complete subprocess")
    args = parser.parse_args()
    if args.stage_timeout < 1:
        parser.error("--stage-timeout must be positive")
    keep = args.work_dir is not None
    work = args.work_dir.expanduser().resolve() if keep else Path(tempfile.mkdtemp(prefix="mmbert-alignment-smoke-"))
    if keep and work.exists() and (not work.is_dir() or any(work.iterdir())):
        parser.error("--work-dir must be new or empty")
    work.mkdir(parents=True, exist_ok=True)
    (work / "logs").mkdir()
    env = os.environ.copy()
    env.update({"HF_HUB_OFFLINE": "1", "TRANSFORMERS_OFFLINE": "1", "TOKENIZERS_PARALLELISM": "false"})
    env["HF_HOME"] = str(work / "hf-cache")
    env.setdefault("OMP_NUM_THREADS", "1")
    env.setdefault("MKL_NUM_THREADS", "1")
    env["PYTHONPATH"] = str(PROJECT_ROOT) + (os.pathsep + env["PYTHONPATH"] if env.get("PYTHONPATH") else "")
    stages = []

    def run(name: str, script: str, *arguments) -> None:
        command = [sys.executable, str(PROJECT_ROOT / script), *map(str, arguments)]
        log = work / "logs" / f"{len(stages) + 1:02d}_{name}.log"
        print(json.dumps({"stage": name, "status": "running"}), flush=True)
        start = time.perf_counter()
        # Streaming subprocess output directly to a file avoids retaining full
        # training logs in RAM and preserves diagnostics even after a timeout.
        with log.open("w", encoding="utf-8") as handle:
            handle.write(json.dumps(command, ensure_ascii=False) + "\n")
            handle.flush()
            try:
                result = subprocess.run(command, cwd=PROJECT_ROOT, env=env, stdout=handle,
                                        stderr=subprocess.STDOUT, timeout=args.stage_timeout)
            except subprocess.TimeoutExpired as exc:
                raise RuntimeError(f"Stage {name} timed out; inspect {log}") from exc
        if result.returncode:
            raise RuntimeError(f"Stage {name} failed with exit code {result.returncode}; inspect {log}")
        stages.append({"stage": name, "status": "passed", "seconds": round(time.perf_counter() - start, 3)})

    try:
        fixture, data = work / "fixture", work / "prepared"
        names, values = ["novelty_score", "demand_score", "quality_score"], [0, 2, 4, 6, 8, 10]
        run("fixture", "scripts/create_tiny_fixture.py", "--output", fixture, "--train-rows", 40,
            "--num-dimensions", 3, "--score-values", *values)
        run("prepare", "prepare_alignment_data.py", "--expert-input", fixture / "validation.jsonl",
            "--pseudo-input", fixture / "train.jsonl", "--output-dir", data,
            "--expert-validation-ratio", .2, "--expert-test-ratio", .2,
            "--pseudo-validation-ratio", .2, "--replay-max-samples", 12)
        base = work / "base.json"
        _write_json(base, {
            "model": {"name_or_path": str(fixture / "model"), "dimension_names": names,
                      "score_values": values, "dropout": 0.0, "attn_implementation": "sdpa"},
            "data": {"max_length": 64, "num_proc": 1},
            "training": {"max_steps": 2, "per_device_train_batch_size": 2, "per_device_eval_batch_size": 2,
                         "gradient_accumulation_steps": 1, "eval_strategy": "steps", "eval_steps": 1,
                         "save_steps": 1, "logging_steps": 1, "early_stopping_patience": 0,
                         # With only two steps, warmup would give step 1 LR=0;
                         # tied validation could then save an unchanged head.
                         "warmup_ratio": 0.0,
                         "dataloader_num_workers": 0, "group_by_length": False,
                         "use_cpu": True, "precision": "fp32", "tf32": False},
        })
        alignment = work / "alignment.json"
        _write_json(alignment, {
            "base_config": str(base), "stage1": {"training": {"max_steps": 2}},
            "expert": {"training": {"max_steps": 2, "per_device_train_batch_size": 2,
                                      "early_stopping_patience": 0, "replay_weight": .1}},
        })
        staged, replay, expert = (work / name for name in ("staged", "staged_replay", "expert_only"))
        common = ("--config", alignment, "--data-dir", data, "--cpu")
        run("staged", "run_alignment.py", *common, "--method", "staged", "--output-dir", staged, "--evaluate-test")
        require(read_json(staged / "pipeline_state.json")["test_evaluated"] is True, "Selected model was not tested")
        require(read_json(staged / "expert_test_metrics.json")["score_values"] == values, "Expert test scale changed")
        source = staged / "stage1" / "final"
        _check_frozen_backbone(source, staged / "expert" / "final")
        run("staged_replay", "run_alignment.py", *common, "--method", "staged_replay",
            "--output-dir", replay, "--source-model", source)
        replay_manifest = read_json(replay / "pipeline_manifest.json")
        require([stage["name"] for stage in replay_manifest["stages"]] == ["expert"], "Reuse retrained the pseudo stage")
        require(replay_manifest["source_verification"]["status"] == "verified", "Source provenance failed verification")
        provenance = read_json(replay / "expert" / "final" / "provenance.json")
        require(provenance["replay_weight"] == .1 and provenance["data_files"]["replay"] is not None,
                "Replay file/weight not recorded by training")
        _check_frozen_backbone(source, replay / "expert" / "final")
        run("expert_only", "run_alignment.py", *common, "--method", "expert_only", "--output-dir", expert)
        comparison = work / "comparison"
        run("compare", "compare_alignment.py", "--run-dirs", staged, replay, expert, "--output-dir", comparison)
        result = read_json(comparison / "comparison.json")
        require(len(result["candidates"]) == 5 and result["test_used_for_selection"] is False,
                "Comparison lost a candidate or used a test metric")
        selected = read_json(comparison / "selected_model.json")
        require(selected["selection_split"] == "expert_validation", "Selection used the wrong split")
        predictions = work / "predictions.jsonl"
        run("predict", "predict.py", "--model", selected["model_path"], "--device", "cpu", "--precision", "fp32",
            "--input", fixture / "predict.jsonl", "--output", predictions, "--include-probabilities", "--batch-size", 2)
        rows = check_predictions(predictions, names, values)
        for root in (staged, replay, expert):
            require(read_json(root / "pipeline_state.json")["status"] == "complete", "An alignment run did not complete")
            require(read_json(root / "expert" / "final" / "training_summary.json")["global_step"] == 2,
                    "Expert stage did not complete two optimizer steps")
        report = {
            "status": "passed", "device": "cpu", "network": "disabled", "stages": stages,
            "num_dimensions": 3, "score_values": values, "prediction_rows": rows,
            "source_reused_without_retraining": True, "frozen_encoder_exactly_unchanged": True,
            "expert_head_changed": True, "test_used_for_selection": False,
            "methods": ["staged", "staged_replay", "expert_only"],
            "work_directory": str(work) if keep else None, "outputs_retained": keep,
            "note": "Local random tiny ModernBERT with synthetic labels; functional correctness only. No production accuracy, generalization, GPU speed, or expert-alignment improvement is claimed.",
        }
        _write_json(work / "smoke_report.json", report)
        if not keep:
            shutil.rmtree(work)
        print(json.dumps(report, ensure_ascii=False, indent=2, allow_nan=False))
        return 0
    except Exception as error:
        report = {"status": "failed", "error": str(error), "completed_stages": stages, "work_directory": str(work)}
        _write_json(work / "smoke_report.json", report)
        print(json.dumps(report, ensure_ascii=False, indent=2), file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
