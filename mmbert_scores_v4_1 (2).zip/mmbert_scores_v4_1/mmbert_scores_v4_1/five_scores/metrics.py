"""Exact categorical agreement on explicit external score scales.

Model labels are zero-based class indices. New score scales have no implied
business groups. The original 1..5 API retains its legacy boundary diagnostics.
"""

from __future__ import annotations

import re
from typing import Any, Sequence

import numpy as np

from .schema import (
    NUM_CLASSES, LEGACY_SCORE_VALUES, default_dimension_names,
    validate_dimension_names, validate_score_values,
)


def _validate_indices(values: np.ndarray, name: str) -> np.ndarray:
    values = np.asarray(values)
    if values.ndim != 2 or values.shape[1] < 1 or values.shape[0] == 0:
        raise ValueError(f"{name} must have nonempty shape [N, D], with D >= 1")
    if not np.issubdtype(values.dtype, np.integer):
        raise ValueError(f"{name} must contain integer class indices in 0..4")
    if np.any(values < 0) or np.any(values >= NUM_CLASSES):
        raise ValueError(f"{name} contains a class index outside 0..4")
    return values.astype(np.int64, copy=False)


def _validated_pair(
    labels: np.ndarray,
    predictions: np.ndarray,
    dimension_names: Sequence[str] | None,
) -> tuple[np.ndarray, np.ndarray, list[str], list[str]]:
    labels = _validate_indices(labels, "labels")
    predictions = _validate_indices(predictions, "predictions")
    if labels.shape != predictions.shape:
        raise ValueError("labels and predictions must have the same shape")
    dimensions = labels.shape[1]
    names = validate_dimension_names(
        dimension_names if dimension_names is not None else default_dimension_names(dimensions)
    )
    if len(names) != dimensions:
        raise ValueError(f"dimension_names must contain {dimensions} nonempty strings")
    prefixes = [re.sub(r"[^\w]+", "_", name, flags=re.UNICODE).strip("_") for name in names]
    if any(not name for name in prefixes) or len(set(prefixes)) != dimensions:
        raise ValueError("dimension_names must remain nonempty and unique after punctuation normalization")
    return labels, predictions, list(names), prefixes


def _groups(indices: np.ndarray) -> np.ndarray:
    return np.where(indices <= 1, 0, np.where(indices == 2, 1, 2))


def _boundary_events(labels: np.ndarray, predictions: np.ndarray) -> dict[str, tuple[np.ndarray, np.ndarray]]:
    """Map a diagnostic to (event mask, teacher-condition mask)."""
    low, middle, high = labels <= 1, labels == 2, labels >= 3
    pred_low, pred_middle, pred_high = predictions <= 1, predictions == 2, predictions >= 3
    endpoint_violation = (low & ~pred_low) | (high & ~pred_high)
    return {
        "endpoint_boundary_error": (endpoint_violation, low | high),
        "low_to_nonlow": (low & ~pred_low, low),
        "high_to_nonhigh": (high & ~pred_high, high),
        "low_to_middle": (low & pred_middle, low),
        "high_to_middle": (high & pred_middle, high),
        "low_to_high": (low & pred_high, low),
        "high_to_low": (high & pred_low, high),
        "middle_to_nonmiddle": (middle & ~pred_middle, middle),
        "middle_to_low": (middle & pred_low, middle),
        "middle_to_high": (middle & pred_high, middle),
    }


def _add_conditional_metric(
    result: dict[str, float | int], name: str, events: np.ndarray, condition: np.ndarray,
) -> None:
    count, support = int(np.count_nonzero(events)), int(np.count_nonzero(condition))
    result[f"{name}_count"] = count
    result[f"{name}_support"] = support
    result[f"{name}_rate"] = count / support if support else 0.0
    result[f"{name}_defined"] = int(support > 0)


def _legacy_score_metrics(
    labels: np.ndarray,
    predictions: np.ndarray,
    dimension_names: Sequence[str] | None = None,
) -> dict[str, float | int]:
    """Return finite, flat metrics suitable for ``transformers.Trainer``.

    Both arguments are integer [N,D] class indices in 0..4. ``accuracy`` (also
    ``exact_accuracy``) is exact agreement over N*D decisions;
    ``all_dimensions_accuracy`` (also ``row_exact_match``) requires all D scores
    of a row to match. A 1<->2 or 4<->5 error never counts as exact agreement.

    Every conditional rate has its event ``_count``, teacher ``_support``, and
    ``_defined`` flag. Missing support gives a finite zero placeholder and a
    false defined flag; it is not an observed zero-error rate. Use
    :func:`metrics_for_report` to replace undefined placeholders with ``None``.

    Macro-F1 includes all five classes even when unsupported. QWK uses fixed
    bins 0..4. Undefined dimension QWKs are excluded from the aggregate.
    ``severe_error_rate`` retains its old absolute-distance >= 2 definition;
    it does not include the important 2->3 and 4->3 boundary errors.
    """
    labels, predictions, names, prefixes = _validated_pair(labels, predictions, dimension_names)
    differences = np.abs(labels - predictions)
    exact = labels == predictions
    group_mismatch = _groups(labels) != _groups(predictions)
    events = _boundary_events(labels, predictions)
    boundary_mask, endpoint_mask = events["endpoint_boundary_error"]
    result: dict[str, float | int] = {
        "num_examples": labels.shape[0],
        "num_decisions": labels.size,
        "exact_match_count": int(exact.sum()),
        "row_exact_match_count": int(exact.all(axis=1).sum()),
        "mae": float(differences.mean()),
        "accuracy": float(exact.mean()),
        "exact_accuracy": float(exact.mean()),
        "severe_error_rate": float((differences >= 2).mean()),
        "all_dimensions_accuracy": float(exact.all(axis=1).mean()),
        "row_exact_match": float(exact.all(axis=1).mean()),
        "group_mismatch_count": int(group_mismatch.sum()),
        "group_mismatch_rate": float(group_mismatch.mean()),
        "row_any_group_mismatch_count": int(group_mismatch.any(axis=1).sum()),
        "row_any_group_mismatch_rate": float(group_mismatch.any(axis=1).mean()),
        # This row rate uses all rows. The conditional endpoint-row rate below
        # additionally exposes whether any eligible teacher endpoints exist.
        "row_any_boundary_violation_count": int(boundary_mask.any(axis=1).sum()),
        "row_any_boundary_violation_support": labels.shape[0],
        "row_any_boundary_violation_rate": float(boundary_mask.any(axis=1).mean()),
    }
    for name, (event, condition) in events.items():
        _add_conditional_metric(result, name, event, condition)
    _add_conditional_metric(
        result, "row_endpoint_boundary_error", boundary_mask.any(axis=1), endpoint_mask.any(axis=1)
    )

    f1_values: list[float] = []
    defined_qwk: list[float] = []
    observed_directional_rates: list[float] = []
    weights = (np.arange(NUM_CLASSES)[:, None] - np.arange(NUM_CLASSES)[None, :]) ** 2 / (NUM_CLASSES - 1) ** 2
    count = labels.shape[0]
    for dimension, prefix in enumerate(prefixes):
        y_true, y_pred = labels[:, dimension], predictions[:, dimension]
        confusion = np.bincount(NUM_CLASSES * y_true + y_pred, minlength=NUM_CLASSES ** 2).reshape(
            NUM_CLASSES, NUM_CLASSES
        )
        actual = confusion.sum(axis=1)
        predicted = confusion.sum(axis=0)
        correct = np.diag(confusion)
        f1_denominator = actual + predicted
        per_class_f1 = np.divide(
            2 * correct, f1_denominator,
            out=np.zeros(NUM_CLASSES, dtype=np.float64), where=f1_denominator != 0,
        )
        f1 = float(per_class_f1.mean())
        f1_values.append(f1)
        expected = np.outer(actual, predicted) / count
        denominator = float((weights * expected).sum())
        is_defined = denominator > 0
        qwk = float(1.0 - (weights * confusion).sum() / denominator) if is_defined else 0.0
        if is_defined:
            defined_qwk.append(qwk)
        result.update({
            f"{prefix}_mae": float(differences[:, dimension].mean()),
            f"{prefix}_accuracy": float(exact[:, dimension].mean()),
            f"{prefix}_exact_accuracy": float(exact[:, dimension].mean()),
            f"{prefix}_macro_f1": f1,
            f"{prefix}_severe_error_rate": float((differences[:, dimension] >= 2).mean()),
            f"{prefix}_qwk": qwk,
            f"{prefix}_qwk_defined": int(is_defined),
            f"{prefix}_group_mismatch_count": int(group_mismatch[:, dimension].sum()),
            f"{prefix}_group_mismatch_rate": float(group_mismatch[:, dimension].mean()),
        })
        for score_index in range(NUM_CLASSES):
            score_prefix = f"{prefix}_score_{score_index + 1}"
            support = int(actual[score_index])
            predicted_count = int(predicted[score_index])
            result.update({
                f"{score_prefix}_support": support,
                f"{score_prefix}_predicted_count": predicted_count,
                f"{score_prefix}_correct_count": int(correct[score_index]),
                f"{score_prefix}_recall": float(correct[score_index] / support) if support else 0.0,
                f"{score_prefix}_recall_defined": int(support > 0),
                f"{score_prefix}_precision": float(correct[score_index] / predicted_count) if predicted_count else 0.0,
                f"{score_prefix}_precision_defined": int(predicted_count > 0),
            })
        for name, (event, condition) in events.items():
            _add_conditional_metric(result, f"{prefix}_{name}", event[:, dimension], condition[:, dimension])
        for name in ("low_to_nonlow", "high_to_nonhigh"):
            if result[f"{prefix}_{name}_defined"]:
                observed_directional_rates.append(float(result[f"{prefix}_{name}_rate"]))

    result["macro_f1"] = float(np.mean(f1_values))
    result["qwk"] = float(np.mean(defined_qwk)) if defined_qwk else 0.0
    result["qwk_defined"] = int(bool(defined_qwk))
    result["qwk_defined_dimensions"] = len(defined_qwk)
    # The maximum considers only observed teacher low/high groups in each
    # dimension. Coverage makes a missing class impossible to mistake for safety.
    total_groups = 2 * len(names)
    result["max_endpoint_directional_error_rate"] = max(observed_directional_rates, default=0.0)
    result["max_endpoint_directional_error_defined"] = int(bool(observed_directional_rates))
    result["endpoint_directional_defined_groups"] = len(observed_directional_rates)
    result["endpoint_directional_total_groups"] = total_groups
    result["endpoint_directional_coverage"] = len(observed_directional_rates) / total_groups
    result["endpoint_directional_all_groups_defined"] = int(len(observed_directional_rates) == total_groups)
    return result


def metrics_for_report(metrics: dict[str, float | int]) -> dict[str, float | int | None]:
    """Replace undefined finite logging placeholders with JSON null values."""
    converted: dict[str, float | int | None] = dict(metrics)
    for name, value in metrics.items():
        if name.endswith("_defined") and not value:
            base = name[:-len("_defined")]
            for candidate in (base, f"{base}_rate"):
                if candidate in converted:
                    converted[candidate] = None
    return converted


def _legacy_detailed_score_report(
    labels: np.ndarray,
    predictions: np.ndarray,
    dimension_names: Sequence[str] | None = None,
) -> dict[str, Any]:
    """Matrices, distributions, class recalls, and null-aware exact metrics."""
    labels, predictions, names, prefixes = _validated_pair(labels, predictions, dimension_names)
    flat = score_metrics(labels, predictions, names)
    true_groups, predicted_groups = _groups(labels), _groups(predictions)
    confusion: dict[str, list[list[int]]] = {}
    group_confusion: dict[str, list[list[int]]] = {}
    distributions: dict[str, dict[str, dict[str, int]]] = {}
    class_metrics: dict[str, dict[str, dict[str, float | int | None]]] = {}
    for dimension, (name, prefix) in enumerate(zip(names, prefixes)):
        matrix = np.bincount(
            NUM_CLASSES * labels[:, dimension] + predictions[:, dimension],
            minlength=NUM_CLASSES ** 2,
        ).reshape(NUM_CLASSES, NUM_CLASSES)
        confusion[name] = matrix.tolist()
        group_confusion[name] = np.bincount(
            3 * true_groups[:, dimension] + predicted_groups[:, dimension], minlength=9,
        ).reshape(3, 3).tolist()
        teacher, predicted = matrix.sum(axis=1), matrix.sum(axis=0)
        distributions[name] = {
            "teacher": {str(i + 1): int(teacher[i]) for i in range(NUM_CLASSES)},
            "predicted": {str(i + 1): int(predicted[i]) for i in range(NUM_CLASSES)},
        }
        class_metrics[name] = {
            str(i + 1): {
                "support": int(teacher[i]),
                "predicted_count": int(predicted[i]),
                "correct_count": int(matrix[i, i]),
                "recall": flat[f"{prefix}_score_{i + 1}_recall"] if teacher[i] else None,
                "precision": flat[f"{prefix}_score_{i + 1}_precision"] if predicted[i] else None,
            }
            for i in range(NUM_CLASSES)
        }
    return {
        "metrics": metrics_for_report(flat),
        "confusion_matrix_axes": "rows=teacher score 1..5; columns=predicted score 1..5",
        "confusion_matrices": confusion,
        "group_confusion_matrix_axes": "rows=teacher group; columns=predicted group; order=low(1,2),middle(3),high(4,5)",
        "group_confusion_matrices": group_confusion,
        "score_distributions": distributions,
        "per_class_metrics": class_metrics,
        "metric_notes": [
            "accuracy/exact_accuracy require exactly the same integer score; 1<->2 and 4<->5 remain errors.",
            "all_dimensions_accuracy/row_exact_match require every dimension of a row to match exactly.",
            "endpoint_boundary_error_rate conditions on teacher scores 1/2 or 4/5; it includes low->3 and high->3.",
            "low_to_* rates condition on teacher 1/2; high_to_* on teacher 4/5; middle_to_* on teacher 3.",
            "row_any_boundary_violation_rate uses all rows; row_endpoint_boundary_error_rate uses rows containing at least one teacher endpoint.",
            "group_mismatch_rate includes teacher-3 errors as well as endpoint errors and is not exact five-score accuracy.",
            "Each conditional rate has an event count, teacher support, and defined flag; null means no supporting teacher examples.",
            "Per-class recall divides correct_count by teacher support; precision divides by predicted_count. Undefined denominators produce null, not observed zero accuracy.",
            "max_endpoint_directional_error_rate is the maximum observed per-dimension low_to_nonlow/high_to_nonhigh rate; endpoint_directional_coverage reports observed groups out of 2*D.",
            "A measured zero error rate describes this evaluation sample and is not a guarantee of zero future errors.",
            "severe_error_rate retains absolute score difference >=2 and misses 2->3 and 4->3 errors; inspect boundary metrics as well.",
            "macro_f1 includes all five score classes, even when a class is absent; undefined QWKs are null and excluded from aggregate QWK.",
            "Predictions use per-dimension five-class probability argmax, converted to scores 1..5.",
        ],
    }


def _scale_pair(labels, predictions, dimension_names, score_values):
    values = validate_score_values(score_values)
    num_classes = len(values)
    arrays = []
    for label, array in (("labels", labels), ("predictions", predictions)):
        array = np.asarray(array)
        if array.ndim != 2 or array.shape[0] == 0 or array.shape[1] == 0:
            raise ValueError(f"{label} must have nonempty shape [N, D]")
        if not np.issubdtype(array.dtype, np.integer):
            raise ValueError(f"{label} must contain integer class indices in 0..{num_classes - 1}")
        if np.any(array < 0) or np.any(array >= num_classes):
            raise ValueError(f"{label} contains a class index outside 0..{num_classes - 1}")
        arrays.append(array.astype(np.int64, copy=False))
    labels, predictions = arrays
    if labels.shape != predictions.shape:
        raise ValueError("labels and predictions must have the same shape")
    names = validate_dimension_names(
        dimension_names if dimension_names is not None else default_dimension_names(labels.shape[1])
    )
    if len(names) != labels.shape[1]:
        raise ValueError("dimension_names must match the label dimension count")
    prefixes = [re.sub(r"[^\w]+", "_", name, flags=re.UNICODE).strip("_") for name in names]
    if any(not prefix for prefix in prefixes) or len(set(prefixes)) != len(names):
        raise ValueError("dimension_names must remain nonempty and unique after punctuation normalization")
    return labels, predictions, names, prefixes, values


def score_metrics(
    labels: np.ndarray,
    predictions: np.ndarray,
    dimension_names: Sequence[str] | None = None,
    *,
    score_values: Sequence[int] | None = None,
) -> dict[str, float | int]:
    """Exact agreement for an explicit score scale and zero-based class indices.

    Missing score_values preserves the original 1..5 API. On other scales no
    low/middle/high groups or tolerant business rules are invented. MAE uses
    external score units; mae_steps uses ordinal class distance. Every unequal
    class remains an exact-match error, including neighboring even scores.
    """
    values = validate_score_values(LEGACY_SCORE_VALUES if score_values is None else score_values)
    if values == list(LEGACY_SCORE_VALUES):
        return _legacy_score_metrics(labels, predictions, dimension_names)
    labels, predictions, names, prefixes, values = _scale_pair(labels, predictions, dimension_names, values)
    num_classes, count = len(values), labels.shape[0]
    value_array = np.asarray(values, dtype=np.float64)
    differences = np.abs(value_array[labels] - value_array[predictions])
    steps = np.abs(labels - predictions)
    exact = labels == predictions
    result: dict[str, float | int] = {
        "num_examples": count,
        "num_decisions": labels.size,
        "exact_match_count": int(exact.sum()),
        "row_exact_match_count": int(exact.all(axis=1).sum()),
        "mae": float(differences.mean()),
        "mae_steps": float(steps.mean()),
        "accuracy": float(exact.mean()),
        "exact_accuracy": float(exact.mean()),
        "all_dimensions_accuracy": float(exact.all(axis=1).mean()),
        "row_exact_match": float(exact.all(axis=1).mean()),
        "two_or_more_steps_error_rate": float((steps >= 2).mean()),
    }
    f1_values, defined_qwk = [], []
    weights = ((value_array[:, None] - value_array[None, :]) / (values[-1] - values[0])) ** 2
    for dimension, prefix in enumerate(prefixes):
        matrix = np.bincount(
            num_classes * labels[:, dimension] + predictions[:, dimension], minlength=num_classes ** 2,
        ).reshape(num_classes, num_classes)
        actual, predicted = matrix.sum(axis=1), matrix.sum(axis=0)
        correct = np.diag(matrix)
        f1_denominator = actual + predicted
        f1 = float(np.divide(2 * correct, f1_denominator, out=np.zeros(num_classes, dtype=np.float64),
                             where=f1_denominator != 0).mean())
        f1_values.append(f1)
        expected = np.outer(actual, predicted) / count
        denominator = float((weights * expected).sum())
        is_defined = denominator > 0
        qwk = float(1 - (weights * matrix).sum() / denominator) if is_defined else 0.0
        if is_defined:
            defined_qwk.append(qwk)
        result.update({
            f"{prefix}_mae": float(differences[:, dimension].mean()),
            f"{prefix}_mae_steps": float(steps[:, dimension].mean()),
            f"{prefix}_accuracy": float(exact[:, dimension].mean()),
            f"{prefix}_exact_accuracy": float(exact[:, dimension].mean()),
            f"{prefix}_macro_f1": f1,
            f"{prefix}_qwk": qwk,
            f"{prefix}_qwk_defined": int(is_defined),
            f"{prefix}_two_or_more_steps_error_rate": float((steps[:, dimension] >= 2).mean()),
        })
        for index, score in enumerate(values):
            score_prefix = f"{prefix}_score_{score}"
            support, predicted_count = int(actual[index]), int(predicted[index])
            result.update({
                f"{score_prefix}_support": support,
                f"{score_prefix}_predicted_count": predicted_count,
                f"{score_prefix}_correct_count": int(correct[index]),
                f"{score_prefix}_recall": float(correct[index] / support) if support else 0.0,
                f"{score_prefix}_recall_defined": int(support > 0),
                f"{score_prefix}_precision": float(correct[index] / predicted_count) if predicted_count else 0.0,
                f"{score_prefix}_precision_defined": int(predicted_count > 0),
            })
    result.update({
        "macro_f1": float(np.mean(f1_values)),
        "qwk": float(np.mean(defined_qwk)) if defined_qwk else 0.0,
        "qwk_defined": int(bool(defined_qwk)),
        "qwk_defined_dimensions": len(defined_qwk),
    })
    return result


def detailed_score_report(
    labels: np.ndarray,
    predictions: np.ndarray,
    dimension_names: Sequence[str] | None = None,
    *,
    score_values: Sequence[int] | None = None,
) -> dict[str, Any]:
    """Scale-labelled confusion matrices and exact metrics, with no invented groups."""
    values = validate_score_values(LEGACY_SCORE_VALUES if score_values is None else score_values)
    if values == list(LEGACY_SCORE_VALUES):
        report = _legacy_detailed_score_report(labels, predictions, dimension_names)
        report.update({"score_values": values, "num_classes": len(values)})
        return report
    labels, predictions, names, prefixes, values = _scale_pair(labels, predictions, dimension_names, values)
    flat = score_metrics(labels, predictions, names, score_values=values)
    num_classes = len(values)
    confusion, distributions, class_metrics = {}, {}, {}
    for dimension, (name, prefix) in enumerate(zip(names, prefixes)):
        matrix = np.bincount(
            num_classes * labels[:, dimension] + predictions[:, dimension], minlength=num_classes ** 2,
        ).reshape(num_classes, num_classes)
        confusion[name] = matrix.tolist()
        actual, predicted = matrix.sum(axis=1), matrix.sum(axis=0)
        distributions[name] = {
            "teacher": {str(score): int(actual[i]) for i, score in enumerate(values)},
            "predicted": {str(score): int(predicted[i]) for i, score in enumerate(values)},
        }
        class_metrics[name] = {
            str(score): {
                "support": int(actual[i]), "predicted_count": int(predicted[i]),
                "correct_count": int(matrix[i, i]),
                "recall": flat[f"{prefix}_score_{score}_recall"] if actual[i] else None,
                "precision": flat[f"{prefix}_score_{score}_precision"] if predicted[i] else None,
            }
            for i, score in enumerate(values)
        }
    return {
        "score_values": values,
        "num_classes": num_classes,
        "metrics": metrics_for_report(flat),
        "confusion_matrix_axes": f"rows=teacher scores; columns=predicted scores; both ordered as {values}",
        "confusion_matrices": confusion,
        "score_distributions": distributions,
        "per_class_metrics": class_metrics,
        "metric_notes": [
            "accuracy/exact_accuracy require exactly the same score; every unequal prediction is an error.",
            "all_dimensions_accuracy/row_exact_match require every dimension of a row to match exactly.",
            "mae measures absolute difference in the external score units; mae_steps measures ordinal class distance.",
            "two_or_more_steps_error_rate counts predictions at least two ordinal classes away (4 points on the 0,2,4,6,8,10 scale).",
            "No low/middle/high business groups or legacy boundary/tolerance metrics are assumed for this score scale.",
            "Macro-F1 includes all declared score classes; undefined QWKs are null and excluded from aggregate QWK.",
            "Per-class recall/precision with no supporting teacher/predicted samples are null, not observed zero accuracy.",
            "QWK uses squared distances between the declared external score values.",
            f"Predictions use per-dimension {num_classes}-class argmax and are decoded with score_values={values}.",
        ],
    }
