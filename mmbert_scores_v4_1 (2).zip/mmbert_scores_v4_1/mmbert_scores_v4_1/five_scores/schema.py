"""Shared score schema; task dimensions are independent of rating classes."""

from __future__ import annotations

from numbers import Integral
from typing import Sequence


# Kept for callers of the original 1..5 API. New code must derive K from its
# explicitly selected score_values, never from this compatibility constant.
NUM_CLASSES = 5
LEGACY_SCORE_VALUES = (1, 2, 3, 4, 5)
DEFAULT_SCORE_VALUES = (0, 2, 4, 6, 8, 10)
NEW_DIMENSION_NAMES = ("novelty_score", "demand_score", "quality_score")
DEFAULT_DIMENSION_NAMES = (
    "authenticity", "value", "relevance", "severity",
    "effectiveness", "innovativeness", "feasibility",
)


def validate_score_values(values: Sequence[int]) -> list[int]:
    """Return the exact, ordered external scale; never sort or round labels."""
    if not isinstance(values, (list, tuple)) or len(values) < 2:
        raise ValueError("score_values must contain at least two strictly increasing integers")
    if any(isinstance(value, bool) or not isinstance(value, Integral) for value in values):
        raise ValueError("score_values must contain integers, not booleans or floats")
    result = [int(value) for value in values]
    if any(left >= right for left, right in zip(result, result[1:])):
        raise ValueError("score_values must be distinct and strictly increasing")
    return result


def encode_scores(scores: Sequence[int], score_values: Sequence[int]) -> list[int]:
    """Map external ratings to class indices without accepting invalid labels."""
    values = validate_score_values(score_values)
    mapping = {score: index for index, score in enumerate(values)}
    result: list[int] = []
    for score in scores:
        if isinstance(score, bool) or not isinstance(score, Integral) or int(score) not in mapping:
            raise ValueError(f"Scores must be integers in {values}; got {score!r}")
        result.append(mapping[int(score)])
    return result


def decode_indices(indices: Sequence[int], score_values: Sequence[int]) -> list[int]:
    """Map model class indices back to the checkpoint's external score scale."""
    values = validate_score_values(score_values)
    result: list[int] = []
    for index in indices:
        if isinstance(index, bool) or not isinstance(index, Integral) or not 0 <= int(index) < len(values):
            raise ValueError(f"Class indices must be integers in 0..{len(values) - 1}; got {index!r}")
        result.append(values[int(index)])
    return result


def validate_num_dimensions(value: int) -> int:
    if isinstance(value, bool) or not isinstance(value, Integral) or value < 1:
        raise ValueError("num_dimensions must be a positive integer")
    return int(value)


def validate_dimension_names(names: Sequence[str]) -> list[str]:
    if not isinstance(names, (list, tuple)) or not names:
        raise ValueError("dimension_names must be a nonempty list of distinct strings")
    if any(not isinstance(name, str) or not name.strip() for name in names):
        raise ValueError("dimension_names must contain nonempty strings")
    result = [name.strip() for name in names]
    if len(set(result)) != len(result):
        raise ValueError("dimension_names must be distinct after trimming whitespace")
    return result


def default_dimension_names(num_dimensions: int | None = None) -> list[str]:
    if num_dimensions is None:
        return list(DEFAULT_DIMENSION_NAMES)
    count = validate_num_dimensions(num_dimensions)
    if count == len(NEW_DIMENSION_NAMES):
        return list(NEW_DIMENSION_NAMES)
    if count == len(DEFAULT_DIMENSION_NAMES):
        return list(DEFAULT_DIMENSION_NAMES)
    return [f"dim_{index + 1}" for index in range(count)]
