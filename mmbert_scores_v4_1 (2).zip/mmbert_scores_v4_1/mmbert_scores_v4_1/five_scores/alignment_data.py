"""Prepare separate expert/pseudo-label splits without expert-case leakage.

Inputs are canonical JSONL/CSV produced by ``convert_data.py``. The temporary
SQLite index keeps corpus text off the Python heap. Expert labels always take
precedence: every expert case is removed from the complete pseudo-label pool
*before* either source is split. A pseudo group with any overlap is removed in
its entirety. Exact normalized text is not semantic/paraphrase detection; use
shared ``group_id`` values for alternate texts from the same case.

Row ``id`` values are deliberately not cross-source identifiers by default.
``overlap_id_column`` opts into a genuinely shared case key, also used for
within-source grouping if no explicit group column exists. Identifier keys
trim surrounding whitespace and equate integer 42 with string "42" for CSV
interoperability, but keep string "042" distinct. Conflicting labels or group
assignments for expert duplicates require review rather than silent voting.
"""

from __future__ import annotations

import hashlib
import json
import math
from pathlib import Path
import re
import shutil
import sqlite3
import sys
import tempfile
from typing import Any, Mapping, Sequence
import uuid

from .data import canonical_record, iter_source_records, normalized_text, resolve_dimension_schema, text_digest
from .schema import DEFAULT_SCORE_VALUES, NEW_DIMENSION_NAMES, validate_dimension_names, validate_score_values


PIPELINE_ID = "mmbert_scores.prepare_alignment_data.v1"
SCHEMA_VERSION = 1
SPLITS = (
    "expert_train", "expert_validation", "expert_test",
    "pseudo_train", "pseudo_validation", "replay_train",
)
OUTPUT_FILES = {*(f"{split}.jsonl" for split in SPLITS), "report.json", "alignment_manifest.json"}
PROVENANCE_KEYS = (
    "metadata", "source", "source_file", "source_sheet", "source_row",
    "source_path", "source_record", "source_line",
)


def file_sha256(path: str | Path) -> str:
    """Hash a file with bounded memory; also used by the training runner."""
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _json(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, separators=(",", ":"), allow_nan=False)


def _identifier(value: Any, *, column: str, location: str) -> tuple[str | int, str]:
    if isinstance(value, bool) or not isinstance(value, (str, int)):
        raise ValueError(f"{location}: '{column}' must be a nonempty string or integer identifier")
    key = str(value).strip()
    if not key:
        raise ValueError(f"{location}: '{column}' must be a nonempty identifier")
    return value, key


def _score_counts(names: Sequence[str], values: Sequence[int]) -> dict[str, dict[str, int]]:
    return {name: {str(value): 0 for value in values} for name in names}


def _add_scores(counts: dict[str, dict[str, int]], scores: Sequence[int]) -> None:
    for name, score in zip(counts, scores, strict=True):
        counts[name][str(score)] += 1


def _validate_ratios(validation: float, test: float, *, source: str) -> tuple[float, float, float]:
    if any(isinstance(value, bool) or not isinstance(value, (int, float))
           or not math.isfinite(value) or not 0 <= value < 1 for value in (validation, test)):
        raise ValueError(f"{source} validation/test ratios must be finite numbers in [0, 1)")
    if validation + test >= 1:
        raise ValueError(f"{source} validation/test ratios must sum to less than 1")
    return 1.0 - validation - test, float(validation), float(test)


def _group_quotas(count: int, ratios: Sequence[float], *, source: str) -> list[int]:
    """Largest-remainder allocation, with at least one group per positive split."""
    active = [index for index, ratio in enumerate(ratios) if ratio > 0]
    if count < len(active):
        raise ValueError(
            f"{source}: only {count} independent groups remain, but {len(active)} positive-ratio "
            "splits were requested. Add independent cases or explicitly set a holdout ratio to 0; "
            "no outputs were published."
        )
    exact = [count * ratio for ratio in ratios]
    quotas = [math.floor(value) for value in exact]
    order = sorted(active, key=lambda index: (-(exact[index] - quotas[index]), index))
    for index in order[:count - sum(quotas)]:
        quotas[index] += 1
    for index in active:
        if quotas[index] == 0:
            donors = [candidate for candidate in active if quotas[candidate] > 1]
            donor = max(donors, key=lambda candidate: (quotas[candidate] - exact[candidate], quotas[candidate], -candidate))
            quotas[donor] -= 1
            quotas[index] = 1
    return quotas


def _check_destination(output: Path, overwrite: bool) -> None:
    if output.is_symlink():
        raise ValueError("The output directory must not be a symbolic link")
    if not output.exists():
        return
    if not output.is_dir():
        raise ValueError(f"Output path is not a directory: {output}")
    children = list(output.iterdir())
    if not children:
        return
    if not overwrite:
        raise FileExistsError(f"Output directory is not empty: {output}; use --overwrite only for generated data")
    if {child.name for child in children} != OUTPUT_FILES or any(not child.is_file() or child.is_symlink() for child in children):
        raise ValueError("--overwrite only replaces a complete directory generated by prepare_alignment_data.py")
    try:
        manifest = json.loads((output / "alignment_manifest.json").read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise ValueError("--overwrite requires a valid alignment_manifest.json from an earlier successful run") from exc
    if not isinstance(manifest, dict) or manifest.get("pipeline") != PIPELINE_ID:
        raise ValueError("--overwrite refuses a directory not generated by prepare_alignment_data.py")


def _publish(staging: Path, output: Path, overwrite: bool) -> None:
    _check_destination(output, overwrite)
    backup = None
    if output.exists():
        backup = output.with_name(f".{output.name}.backup-{uuid.uuid4().hex}")
        output.rename(backup)
    try:
        staging.rename(output)
    except BaseException:
        if backup is not None and not output.exists():
            backup.rename(output)
        raise
    if backup is not None:
        try:
            shutil.rmtree(backup)
        except OSError:
            print(f"Warning: prepared data saved; old backup could not be removed: {backup}", file=sys.stderr)


def _csv_structured_fields(raw: Mapping[str, Any], source: Path, location: str) -> dict[str, Any]:
    record = dict(raw)
    if source.suffix.lower() == ".csv":
        for key in ("dimension_names", "score_values", "metadata"):
            if key in record and isinstance(record[key], str):
                try:
                    record[key] = json.loads(record[key])
                except json.JSONDecodeError as exc:
                    raise ValueError(f"{location}: CSV '{key}' must contain valid JSON") from exc
    return record


def _overlap_reason(connection: sqlite3.Connection, digest: str, explicit_group: str | None, shared_id: str | None) -> str | None:
    if connection.execute("SELECT 1 FROM examples WHERE source='expert' AND digest=?", (digest,)).fetchone():
        return "expert_text"
    if explicit_group is not None and connection.execute("SELECT 1 FROM expert_keys WHERE kind='group' AND value=?", (explicit_group,)).fetchone():
        return "expert_group"
    if shared_id is not None and connection.execute("SELECT 1 FROM expert_keys WHERE kind='shared_id' AND value=?", (shared_id,)).fetchone():
        return "expert_shared_id"
    return None


def _ingest(
    connection: sqlite3.Connection, path: Path, source: str, *, names: list[str], values: list[int],
    group_column: str | None, overlap_id_column: str | None, seed: int,
) -> dict[str, Any]:
    stats: dict[str, Any] = {
        "input_rows": 0, "duplicates_removed": 0, "unique_rows": 0,
        "input_score_counts": _score_counts(names, values), "direct_expert_matches_raw_rows": 0,
    }
    detected = False
    resolved_group = group_column
    for row_number, raw_row in iter_source_records(path):
        location = f"{source} {path.name}: record/line {row_number}"
        raw = _csv_structured_fields(raw_row, path, location)
        record = canonical_record(raw, dimension_names=names, score_values=values, location=location)
        record.update(dimension_names=names, score_values=values, label_source=source)
        record["alignment_source"] = {"file": str(path), "record": row_number}
        for key in PROVENANCE_KEYS:
            if key in raw:
                if key == "metadata" and not isinstance(raw[key], dict):
                    raise ValueError(f"{location}: metadata must be a JSON object")
                record[key] = raw[key]
        if "id" in raw and raw["id"] is not None:
            record["id"], _ = _identifier(raw["id"], column="id", location=location)
        if not detected:
            if resolved_group is None and "group_id" in raw:
                resolved_group = "group_id"
            detected = True
        if resolved_group is None and "group_id" in raw:
            raise ValueError(f"{location}: mixed presence of group_id; provide a valid group ID on every row")
        explicit_group = None
        if resolved_group is not None:
            if resolved_group not in raw:
                raise ValueError(f"{location}: missing group column '{resolved_group}'")
            group_id, explicit_group = _identifier(raw[resolved_group], column=resolved_group, location=location)
            record["group_id"] = group_id
        shared_id = None
        if overlap_id_column is not None:
            if overlap_id_column not in raw:
                raise ValueError(f"{location}: missing overlap ID column '{overlap_id_column}'")
            original_id, shared_id = _identifier(raw[overlap_id_column], column=overlap_id_column, location=location)
            record["alignment_source"]["overlap_id"] = {"column": overlap_id_column, "value": original_id}
            # A custom --group-column controls canonical group_id. If the raw
            # field named group_id is instead the shared-case key, preserve it
            # in provenance without overwriting the actual split group.
            if overlap_id_column != "group_id" or explicit_group is None:
                record[overlap_id_column] = original_id
            if explicit_group is None:
                record["group_id"] = original_id
        digest = text_digest(record["text"]).hex()
        group_key = (f"group:{explicit_group}" if explicit_group is not None
                     else f"shared_id:{shared_id}" if shared_id is not None else f"text:{digest}")
        # A shared case may not be split by inconsistent explicit group IDs.
        if shared_id is not None:
            previous = connection.execute("SELECT group_key FROM shared_groups WHERE source=? AND shared_id=?", (source, shared_id)).fetchone()
            if previous is not None and previous[0] != group_key:
                raise ValueError(f"{location}: shared case ID '{shared_id}' has conflicting group IDs; merge its groups before splitting")
            connection.execute("INSERT OR IGNORE INTO shared_groups VALUES (?,?,?)", (source, shared_id, group_key))
        scores_json = _json(record["scores"])
        try:
            raw_json = _json(record)
        except (TypeError, ValueError) as exc:
            raise ValueError(f"{location}: metadata/provenance must be JSON-serializable with finite numbers: {exc}") from exc
        stats["input_rows"] += 1
        _add_scores(stats["input_score_counts"], record["scores"])
        reason = None
        if source == "expert":
            for kind, key in (("group", explicit_group), ("shared_id", shared_id)):
                if key is not None:
                    connection.execute("INSERT OR IGNORE INTO expert_keys VALUES (?,?)", (kind, key))
        else:
            reason = _overlap_reason(connection, digest, explicit_group, shared_id)
            if reason is not None:
                stats["direct_expert_matches_raw_rows"] += 1
                connection.execute("INSERT OR IGNORE INTO blocked_pseudo_groups VALUES (?)", (group_key,))
        group_rank = hashlib.sha256(f"{seed}\0{source}\0{group_key}".encode("utf-8")).hexdigest()
        replay_rank = hashlib.sha256(f"{seed}\0replay\0{digest}".encode("utf-8")).hexdigest()
        inserted = connection.execute(
            "INSERT OR IGNORE INTO examples(source,digest,raw_json,scores,group_key,group_rank,"
            "explicit_group,shared_id,first_row,duplicate_count,conflict_row,exclusion_reason,replay_rank) "
            "VALUES (?,?,?,?,?,?,?,?,?,0,NULL,?,?)",
            (source, digest, raw_json, scores_json, group_key, group_rank, explicit_group, shared_id, row_number, reason, replay_rank),
        ).rowcount
        if inserted:
            stats["unique_rows"] += 1
        else:
            previous = connection.execute(
                "SELECT raw_json,scores,group_key,first_row FROM examples WHERE source=? AND digest=?", (source, digest),
            ).fetchone()
            assert previous is not None
            if normalized_text(json.loads(previous[0])["text"]) != normalized_text(record["text"]):
                raise ValueError(f"{location}: text-hash collision detected; no outputs were published")
            if previous[2] != group_key:
                raise ValueError(f"{location}: normalized duplicate of record/line {previous[3]} has conflicting group IDs; merge the groups before splitting")
            if previous[1] != scores_json:
                if source == "expert":
                    raise ValueError(f"{location}: conflicting expert labels for normalized duplicate of record/line {previous[3]}; adjudicate these labels before preparation")
                # Conflicting pseudo labels are irrelevant if this whole case
                # is excluded for expert overlap; otherwise fail after ingest.
                connection.execute("UPDATE examples SET conflict_row=? WHERE source=? AND digest=?", (row_number, source, digest))
            connection.execute("UPDATE examples SET duplicate_count=duplicate_count+1 WHERE source=? AND digest=?", (source, digest))
            stats["duplicates_removed"] += 1
        if stats["input_rows"] % 10000 == 0:
            connection.commit()
        if stats["input_rows"] % 100000 == 0:
            print(f"Scanned {source}: {stats['input_rows']:,} rows; {stats['unique_rows']:,} unique normalized texts", file=sys.stderr)
    if not stats["input_rows"]:
        raise ValueError(f"{source}: input contains no labeled records")
    stats["group_column"] = resolved_group
    stats["split_group_key"] = resolved_group or overlap_id_column or "normalized_text_sha256"
    connection.commit()
    return stats


def _assign_groups(connection: sqlite3.Connection, source: str, ratios: Sequence[float]) -> dict[str, int]:
    connection.execute(
        "INSERT INTO split_groups(source,group_key,rank) SELECT source,group_key,MIN(group_rank) "
        "FROM examples WHERE source=? AND exclusion_reason IS NULL GROUP BY source,group_key", (source,),
    )
    count = connection.execute("SELECT COUNT(*) FROM split_groups WHERE source=?", (source,)).fetchone()[0]
    quotas = _group_quotas(count, ratios, source=source)
    names = ("train", "validation", "test")
    boundaries = (quotas[0], quotas[0] + quotas[1])
    updates = []
    for index, (key,) in enumerate(connection.execute("SELECT group_key FROM split_groups WHERE source=? ORDER BY rank,group_key", (source,))):
        split = names[0 if index < boundaries[0] else 1 if index < boundaries[1] else 2]
        updates.append((split, source, key))
        if len(updates) >= 1000:
            connection.executemany("UPDATE split_groups SET split=? WHERE source=? AND group_key=?", updates)
            updates.clear()
    if updates:
        connection.executemany("UPDATE split_groups SET split=? WHERE source=? AND group_key=?", updates)
    connection.commit()
    return dict(zip(names, quotas, strict=True))


def _write_split(
    connection: sqlite3.Connection, staging: Path, name: str, *, names: list[str], values: list[int], replay_limit: int,
) -> dict[str, Any]:
    source, split = ("pseudo", "train") if name == "replay_train" else name.split("_", 1)
    query = (
        "SELECT e.raw_json,e.scores,e.group_key FROM examples e JOIN split_groups g "
        "ON e.source=g.source AND e.group_key=g.group_key "
        "WHERE e.source=? AND e.exclusion_reason IS NULL AND g.split=? "
    )
    parameters: tuple[Any, ...] = (source, split)
    if name == "replay_train":
        query += "ORDER BY e.replay_rank,e.digest LIMIT ?"
        parameters += (replay_limit,)
    else:
        query += "ORDER BY e.first_row"
    counts = _score_counts(names, values)
    rows = 0
    path = staging / f"{name}.jsonl"
    with path.open("w", encoding="utf-8", newline="\n") as handle:
        for raw_json, scores, _ in connection.execute(query, parameters):
            handle.write(raw_json + "\n")
            _add_scores(counts, json.loads(scores))
            rows += 1
    # Regular splits already have a group index; do not sort/read corpus text
    # again just to count groups. Replay counts its bounded selected subset.
    if name == "replay_train":
        groups = connection.execute(f"SELECT COUNT(DISTINCT group_key) FROM ({query})", parameters).fetchone()[0]
    else:
        groups = connection.execute("SELECT COUNT(*) FROM split_groups WHERE source=? AND split=?", (source, split)).fetchone()[0]
    return {
        "path": path.name, "sha256": file_sha256(path), "bytes": path.stat().st_size,
        "rows": rows, "groups": groups, "label_source": source,
        "num_dimensions": len(names), "dimension_names": names, "score_values": values,
        "score_counts": counts,
        "missing_score_values": {dimension: [score for score in values if not histogram[str(score)]] for dimension, histogram in counts.items()},
    }


def prepare_alignment_dataset(
    expert_input: str | Path,
    pseudo_input: str | Path,
    output_dir: str | Path,
    *,
    dimension_names: Sequence[str] = NEW_DIMENSION_NAMES,
    score_values: Sequence[int] = DEFAULT_SCORE_VALUES,
    num_dimensions: int | None = None,
    seed: int = 42,
    expert_validation_ratio: float = 0.15,
    expert_test_ratio: float = 0.15,
    pseudo_validation_ratio: float = 0.05,
    replay_max_samples: int = 5000,
    group_column: str | None = None,
    overlap_id_column: str | None = None,
    overwrite: bool = False,
    config_path: str | Path | None = None,
) -> dict[str, Any]:
    """Atomically produce six source-specific JSONL files and integrity records.

    Splits use seeded SHA-256 ordering of independent groups, followed by
    proportional group-count allocation. Positive-ratio splits are nonempty
    when enough groups exist; otherwise preparation fails. This is neither
    score-stratified nor a chronological split. Per-split score supports expose
    rare/missing classes. ``replay_max_samples=0`` writes an empty replay file.

    The returned report is identical to ``report.json``. Original inputs are
    never edited. ``overwrite`` accepts only this tool's generated directories.
    """
    count, names = resolve_dimension_schema(num_dimensions=num_dimensions, dimension_names=dimension_names)
    assert names is not None
    values = validate_score_values(score_values)
    if isinstance(seed, bool) or not isinstance(seed, int) or seed < 0:
        raise ValueError("seed must be a non-negative integer")
    if isinstance(replay_max_samples, bool) or not isinstance(replay_max_samples, int) or replay_max_samples < 0:
        raise ValueError("replay_max_samples must be a non-negative integer")
    if not isinstance(overwrite, bool):
        raise ValueError("overwrite must be a boolean")
    for key, column in (("group_column", group_column), ("overlap_id_column", overlap_id_column)):
        if column is not None and (not isinstance(column, str) or not column.strip() or column != column.strip()):
            raise ValueError(f"{key} must be a nonempty column name without surrounding whitespace")
    if overlap_id_column in {"text", "scores", "dimension_names", "score_values", "metadata", "alignment_source", "label_source"}:
        raise ValueError("overlap_id_column must identify a case, not overwrite a canonical data/provenance field")
    expert_ratios = _validate_ratios(expert_validation_ratio, expert_test_ratio, source="expert")
    pseudo_ratios = _validate_ratios(pseudo_validation_ratio, 0.0, source="pseudo")
    sources = {"expert": Path(expert_input).expanduser().resolve(), "pseudo": Path(pseudo_input).expanduser().resolve()}
    output = Path(output_dir).expanduser().absolute()
    if sources["expert"] == sources["pseudo"]:
        raise ValueError("expert_input and pseudo_input must be separate source files")
    protected_inputs = [*sources.values()]
    if config_path is not None:
        protected_inputs.append(Path(config_path).expanduser().resolve())
    for source in protected_inputs:
        if not source.is_file():
            raise FileNotFoundError(f"Input file does not exist: {source}")
        if output.resolve() == source or output.resolve() in source.parents:
            raise ValueError("Output directory must not contain or replace any input/configuration file")
    for source in sources.values():
        if source.suffix.lower() not in {".jsonl", ".ndjson", ".csv"}:
            raise ValueError("Alignment preparation accepts canonical JSONL/CSV; convert raw tables with convert_data.py first")
    _check_destination(output, overwrite)
    inputs = {name: {"path": str(path), "sha256": file_sha256(path), "bytes": path.stat().st_size} for name, path in sources.items()}
    if config_path is not None:
        config_file = Path(config_path).expanduser().resolve()
        inputs["config"] = {"path": str(config_file), "sha256": file_sha256(config_file), "bytes": config_file.stat().st_size}
    output.parent.mkdir(parents=True, exist_ok=True)
    staging = Path(tempfile.mkdtemp(prefix=f".{output.name}.staging-", dir=output.parent))
    connection: sqlite3.Connection | None = None
    try:
        database = staging / "index.sqlite3"
        connection = sqlite3.connect(database)
        connection.executescript(
            "PRAGMA journal_mode=OFF; PRAGMA synchronous=OFF; PRAGMA temp_store=FILE; PRAGMA cache_size=-32768;"
            "CREATE TABLE examples (source TEXT NOT NULL,digest TEXT NOT NULL,raw_json TEXT NOT NULL,scores TEXT NOT NULL,"
            "group_key TEXT NOT NULL,group_rank TEXT NOT NULL,explicit_group TEXT,shared_id TEXT,first_row INTEGER NOT NULL,"
            "duplicate_count INTEGER NOT NULL,conflict_row INTEGER,exclusion_reason TEXT,replay_rank TEXT NOT NULL,PRIMARY KEY(source,digest));"
            "CREATE TABLE expert_keys (kind TEXT NOT NULL,value TEXT NOT NULL,PRIMARY KEY(kind,value));"
            "CREATE TABLE shared_groups (source TEXT NOT NULL,shared_id TEXT NOT NULL,group_key TEXT NOT NULL,PRIMARY KEY(source,shared_id));"
            "CREATE TABLE blocked_pseudo_groups (group_key TEXT PRIMARY KEY);"
            "CREATE TABLE split_groups (source TEXT NOT NULL,group_key TEXT NOT NULL,rank TEXT NOT NULL,split TEXT,PRIMARY KEY(source,group_key));"
            "CREATE INDEX split_order ON split_groups(source,rank,group_key);"
        )
        stats = {}
        for source, path in sources.items():
            stats[source] = _ingest(connection, path, source, names=names, values=values, group_column=group_column,
                                    overlap_id_column=overlap_id_column, seed=seed)
        connection.execute(
            "UPDATE examples SET exclusion_reason='linked_pseudo_group' WHERE source='pseudo' AND exclusion_reason IS NULL "
            "AND group_key IN (SELECT group_key FROM blocked_pseudo_groups)"
        )
        conflict = connection.execute(
            "SELECT first_row,conflict_row FROM examples WHERE source='pseudo' AND exclusion_reason IS NULL AND conflict_row IS NOT NULL LIMIT 1"
        ).fetchone()
        if conflict is not None:
            raise ValueError(f"pseudo {sources['pseudo'].name}: conflicting pseudo labels for normalized duplicate records/lines {conflict[0]} and {conflict[1]}; review retained teacher labels")
        removals = {reason: {"unique_rows": 0, "raw_rows": 0} for reason in ("expert_text", "expert_group", "expert_shared_id", "linked_pseudo_group")}
        for reason, unique, raw in connection.execute(
            "SELECT exclusion_reason,COUNT(*),SUM(1+duplicate_count) FROM examples WHERE source='pseudo' AND exclusion_reason IS NOT NULL GROUP BY exclusion_reason"
        ):
            removals[reason] = {"unique_rows": unique, "raw_rows": raw}
        stats["pseudo"].update(
            excluded_unique_rows=sum(info["unique_rows"] for info in removals.values()),
            excluded_raw_rows=sum(info["raw_rows"] for info in removals.values()), exclusion_reasons=removals,
        )
        stats["pseudo"]["retained_unique_rows"] = stats["pseudo"]["unique_rows"] - stats["pseudo"]["excluded_unique_rows"]
        stats["expert"]["retained_unique_rows"] = stats["expert"]["unique_rows"]
        group_counts = {"expert": _assign_groups(connection, "expert", expert_ratios), "pseudo": _assign_groups(connection, "pseudo", pseudo_ratios)}
        connection.execute("CREATE INDEX example_group ON examples(source,group_key)")
        connection.execute("CREATE INDEX example_source_order ON examples(source,first_row)")
        connection.commit()
        files = {name: _write_split(connection, staging, name, names=names, values=values, replay_limit=replay_max_samples) for name in SPLITS}
        overlap_policy = {
            "excludes_all_expert_from_pseudo": True,
            "normalized_text": "Unicode NFC; LF line endings; outer whitespace trimmed; internal whitespace and case preserved",
            "explicit_group_id": True,
            "overlap_id_column": overlap_id_column,
            "row_id_exclusion_enabled": overlap_id_column == "id",
            "remove_entire_overlapping_pseudo_group": True,
            "identifier_comparison": "Trim surrounding whitespace; integer 42 equals string '42'; '042' remains distinct",
            "semantic_deduplication": False,
        }
        warnings = [
            "Splits are allocated by group counts, not by row counts or score stratification; inspect score_counts and missing_score_values.",
            "Exact normalized text does not detect paraphrases; provide shared group_id values or a genuine shared case ID to protect alternate versions.",
            "Hashes detect changed files and accidental mismatches; this manifest is not a signed security attestation.",
        ]
        if bool(stats["expert"]["group_column"]) != bool(stats["pseudo"]["group_column"]):
            warnings.append("Only one source has group IDs; cross-source variants can be excluded only through matching normalized text or a supplied shared case ID.")
        report = {
            "pipeline": PIPELINE_ID, "schema_version": SCHEMA_VERSION, "num_dimensions": count,
            "dimension_names": names, "score_values": values, "seed": seed, "inputs": inputs,
            "sources": stats, "overlap_policy": overlap_policy,
            "split_method": "Seeded SHA-256 order of group keys, largest-remainder group-count allocation, minimum one group per positive split",
            "ratios": {"expert": dict(zip(("train", "validation", "test"), expert_ratios, strict=True)),
                       "pseudo": dict(zip(("train", "validation", "test"), pseudo_ratios, strict=True))},
            "split_groups": group_counts,
            "replay": {"source": "pseudo_train", "max_samples": replay_max_samples, "rows": files["replay_train"]["rows"],
                       "sampling": "Smallest seeded SHA-256 ranks of normalized text; without replacement"},
            "splits": files, "warnings": warnings,
        }
        report_path = staging / "report.json"
        report_path.write_text(json.dumps(report, ensure_ascii=False, indent=2, sort_keys=True, allow_nan=False) + "\n", encoding="utf-8")
        manifest = {
            "pipeline": PIPELINE_ID, "schema_version": SCHEMA_VERSION, "num_dimensions": count,
            "dimension_names": names, "score_values": values, "seed": seed, "inputs": inputs,
            "files": files, "report": {"path": "report.json", "sha256": file_sha256(report_path), "bytes": report_path.stat().st_size},
            "overlap_policy": overlap_policy,
        }
        (staging / "alignment_manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2, sort_keys=True, allow_nan=False) + "\n", encoding="utf-8")
        for source in protected_inputs:
            key = next((name for name, info in inputs.items() if info["path"] == str(source)), None)
            if key is not None and file_sha256(source) != inputs[key]["sha256"]:
                raise ValueError(f"Input/configuration changed during preparation: {source}; no outputs were published")
        connection.close()
        connection = None
        database.unlink()
        _publish(staging, output, overwrite)
        return report
    finally:
        if connection is not None:
            connection.close()
        if staging.exists():
            shutil.rmtree(staging)


def _validate_file_entry(entry: Any, *, filename: str, location: str) -> dict[str, Any]:
    if not isinstance(entry, dict) or entry.get("path") != filename:
        raise ValueError(f"{location}: expected fixed relative path '{filename}'; paths cannot be swapped or redirected")
    if not isinstance(entry.get("sha256"), str) or re.fullmatch(r"[0-9a-f]{64}", entry["sha256"]) is None:
        raise ValueError(f"{location}: invalid SHA256 digest")
    if isinstance(entry.get("bytes"), bool) or not isinstance(entry.get("bytes"), int) or entry["bytes"] < 0:
        raise ValueError(f"{location}: bytes must be a non-negative integer")
    return entry


def load_alignment_manifest(
    path: str | Path,
    *,
    verify_files: bool = True,
    expected_dimension_names: Sequence[str] | None = None,
    expected_score_values: Sequence[int] | None = None,
) -> dict[str, Any]:
    """Read a portable manifest and reject schema, path, source, or hash mismatch.

    Paths are always the six fixed basenames, relative to the manifest folder.
    With ``verify_files=True`` every JSONL record's source/schema and total row
    count are checked as well as bytes/SHA256. Original input files need not be
    present. This checks integrity, not authenticity against deliberate changes
    to both a manifest and its files.
    """
    manifest_path = Path(path).expanduser().absolute()
    if manifest_path.is_dir():
        manifest_path /= "alignment_manifest.json"
    if manifest_path.is_symlink():
        raise ValueError("alignment_manifest.json must not be a symbolic link")
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    if not isinstance(manifest, dict) or manifest.get("pipeline") != PIPELINE_ID or type(manifest.get("schema_version")) is not int or manifest["schema_version"] != SCHEMA_VERSION:
        raise ValueError("Not a supported expert alignment manifest")
    names = validate_dimension_names(manifest.get("dimension_names"))
    values = validate_score_values(manifest.get("score_values"))
    if type(manifest.get("num_dimensions")) is not int or manifest["num_dimensions"] != len(names):
        raise ValueError("Manifest num_dimensions does not match its dimension_names")
    if expected_dimension_names is not None and names != validate_dimension_names(expected_dimension_names):
        raise ValueError("Manifest dimension_names/order do not match the requested model schema")
    if expected_score_values is not None and values != validate_score_values(expected_score_values):
        raise ValueError("Manifest score_values do not match the requested model schema")
    if not isinstance(manifest.get("overlap_policy"), dict) or manifest["overlap_policy"].get("excludes_all_expert_from_pseudo") is not True:
        raise ValueError("Manifest does not certify removal of all expert cases from the pseudo-label pool")
    files = manifest.get("files")
    if not isinstance(files, dict) or set(files) != set(SPLITS):
        raise ValueError("Manifest must declare exactly the six alignment split files")
    base = manifest_path.parent
    for name in SPLITS:
        entry = _validate_file_entry(files[name], filename=f"{name}.jsonl", location=name)
        if type(entry.get("rows")) is not int or entry["rows"] < 0:
            raise ValueError(f"{name}: rows must be a non-negative integer")
        source = "expert" if name.startswith("expert_") else "pseudo"
        if entry.get("label_source") != source:
            raise ValueError(f"{name}: label_source must be '{source}'")
        if entry.get("dimension_names") != names or entry.get("score_values") != values or type(entry.get("num_dimensions")) is not int or entry["num_dimensions"] != len(names):
            raise ValueError(f"{name}: split schema does not match manifest schema")
        if not verify_files:
            continue
        file_path = base / entry["path"]
        if file_path.is_symlink() or not file_path.is_file():
            raise ValueError(f"{name}: split file is missing or is a symbolic link")
        if file_path.stat().st_size != entry["bytes"]:
            raise ValueError(f"{name}: file size mismatch; prepared data has changed")
        digest = hashlib.sha256()
        rows = 0
        with file_path.open("rb") as handle:
            for line_number, line in enumerate(handle, start=1):
                digest.update(line)
                if not line.strip():
                    raise ValueError(f"{name}: unexpected blank line {line_number}")
                try:
                    record = json.loads(line)
                except (json.JSONDecodeError, UnicodeDecodeError) as exc:
                    raise ValueError(f"{name}: invalid JSONL line {line_number}") from exc
                if not isinstance(record, dict) or record.get("label_source") != source or record.get("dimension_names") != names or record.get("score_values") != values:
                    raise ValueError(f"{name}: record {line_number} has incorrect label_source/schema")
                canonical_record(record, dimension_names=names, score_values=values, location=f"{name}: line {line_number}")
                rows += 1
        if digest.hexdigest() != entry["sha256"]:
            raise ValueError(f"{name}: SHA256 mismatch; prepared data has changed")
        if rows != entry["rows"]:
            raise ValueError(f"{name}: row count mismatch (manifest {entry['rows']}, file {rows})")
    report_entry = _validate_file_entry(manifest.get("report"), filename="report.json", location="report")
    if verify_files:
        report_path = base / "report.json"
        if report_path.is_symlink() or not report_path.is_file():
            raise ValueError("report.json is missing or is a symbolic link")
        if report_path.stat().st_size != report_entry["bytes"] or file_sha256(report_path) != report_entry["sha256"]:
            raise ValueError("report.json integrity mismatch")
    return manifest
