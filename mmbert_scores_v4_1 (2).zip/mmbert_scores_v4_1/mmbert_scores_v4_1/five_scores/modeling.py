"""A checkpoint-compatible ModernBERT encoder with D categorical score heads.

The backbone attribute is named ``model`` to match ModernBertForMaskedLM's
checkpoint keys. No vocabulary-sized MLM head is constructed or evaluated.
Labels inside the model are int64 class indices in [0, K-1]. External ratings
are stored explicitly in score_values; data and inference perform conversion.
"""

from __future__ import annotations

import math
from typing import Optional

import torch
from torch import nn
from torch.nn import functional as F
from transformers import ModernBertConfig, ModernBertModel
from transformers.modeling_outputs import SequenceClassifierOutput
from transformers.models.modernbert.modeling_modernbert import ModernBertPreTrainedModel

from .schema import (
    LEGACY_SCORE_VALUES, default_dimension_names, validate_dimension_names,
    validate_num_dimensions, validate_score_values,
)

SCORE_MODEL_VERSION = 4


def validate_score_config(config: ModernBertConfig) -> None:
    """Validate and persist all task metadata alongside the HF configuration."""
    names = validate_dimension_names(getattr(config, "score_dim_names", default_dimension_names()))
    dimensions = len(names)
    declared_dimensions = getattr(config, "score_num_dimensions", dimensions)
    if validate_num_dimensions(declared_dimensions) != dimensions:
        raise ValueError("score_num_dimensions must equal len(score_dim_names)")
    has_values = hasattr(config, "score_values")
    version = getattr(config, "score_model_version", SCORE_MODEL_VERSION if has_values else 3)
    if type(version) is not int or version not in {1, 2, 3, SCORE_MODEL_VERSION}:
        raise ValueError(f"Unsupported score_model_version: {version}")
    if version >= 4 and not has_values:
        raise ValueError("Version-4 checkpoints must declare score_values explicitly")
    values = validate_score_values(getattr(config, "score_values", list(LEGACY_SCORE_VALUES)))
    if version < 4 and values != list(LEGACY_SCORE_VALUES):
        raise ValueError("Non-legacy score_values require score_model_version=4")
    num_classes = len(values)
    declared_classes = getattr(config, "score_num_classes", num_classes)
    if type(declared_classes) is not int or declared_classes != num_classes:
        raise ValueError("score_num_classes must equal len(score_values)")
    if version == 1 and dimensions != 5:
        raise ValueError("Legacy score_model_version=1 checkpoints must have five dimensions")
    config.score_dim_names = names
    config.score_pooling = getattr(config, "score_pooling", "mean")
    if config.score_pooling not in {"mean", "cls"}:
        raise ValueError("score_pooling must be 'mean' or 'cls'")
    config.score_dropout = float(getattr(config, "score_dropout", 0.1))
    if not 0 <= config.score_dropout < 1:
        raise ValueError("score_dropout must be in [0, 1)")
    config.score_ordinal_weight = float(getattr(config, "score_ordinal_weight", 0.0))
    if not math.isfinite(config.score_ordinal_weight) or config.score_ordinal_weight < 0:
        raise ValueError("score_ordinal_weight must be finite and non-negative")
    # Missing fields in v1/v2 checkpoints keep their original CE objective.
    # New runs opt in explicitly through the training configuration.
    boundary_weight = getattr(config, "score_boundary_weight", 0.0)
    if isinstance(boundary_weight, bool) or not isinstance(boundary_weight, (int, float)):
        raise ValueError("score_boundary_weight must be finite and non-negative")
    config.score_boundary_weight = float(boundary_weight)
    if not math.isfinite(config.score_boundary_weight) or config.score_boundary_weight < 0:
        raise ValueError("score_boundary_weight must be finite and non-negative")
    if config.score_boundary_weight and values != list(LEGACY_SCORE_VALUES):
        raise ValueError("score_boundary_weight must be 0 for non-legacy score_values; "
                         "the old low/middle/high groups only apply to scores 1..5")
    weights = getattr(config, "score_dim_weights", [1.0] * dimensions)
    if not isinstance(weights, (list, tuple)) or len(weights) != dimensions:
        raise ValueError(f"score_dim_weights must contain {dimensions} finite positive values")
    try:
        parsed_weights = [float(w) for w in weights]
    except (ValueError, TypeError, OverflowError) as exc:
        raise ValueError("score_dim_weights must contain finite positive values") from exc
    if any(isinstance(w, bool) for w in weights) or any(
        not math.isfinite(w) or w <= 0 for w in parsed_weights
    ):
        raise ValueError("score_dim_weights must contain finite positive values")
    config.score_dim_weights = parsed_weights
    mode = getattr(config, "score_class_weight_mode", "none")
    if mode not in {"none", "sqrt_inverse", "manual"}:
        raise ValueError("score_class_weight_mode must be none, sqrt_inverse or manual")
    class_weights = getattr(config, "score_class_weights", None)
    if class_weights is None:
        class_weights = [[1.0] * num_classes for _ in range(dimensions)]
    if (not isinstance(class_weights, (list, tuple)) or len(class_weights) != dimensions
            or any(not isinstance(row, (list, tuple)) or len(row) != num_classes for row in class_weights)):
        raise ValueError(f"score_class_weights must have shape [{dimensions}, {num_classes}]")
    if any(isinstance(weight, bool) or not isinstance(weight, (int, float))
           or not math.isfinite(weight) or weight <= 0 for row in class_weights for weight in row):
        raise ValueError("score_class_weights must contain finite positive numbers")
    config.score_class_weight_mode = mode
    config.score_class_weights = [[float(weight) for weight in row] for row in class_weights]
    counts = getattr(config, "score_class_counts", None)
    if counts is not None:
        if (not isinstance(counts, (list, tuple)) or len(counts) != dimensions
                or any(not isinstance(row, (list, tuple)) or len(row) != num_classes for row in counts)
                or any(type(value) is not int or value < 0 for row in counts for value in row)):
            raise ValueError(f"score_class_counts must contain non-negative integers with shape [{dimensions}, {num_classes}]")
        totals = [sum(row) for row in counts]
        if min(totals) < 1 or len(set(totals)) != 1:
            raise ValueError("score_class_counts must have equal positive totals across dimensions")
        config.score_class_counts = [list(row) for row in counts]
    config.score_max_length = getattr(config, "score_max_length", 512)
    if (isinstance(config.score_max_length, bool)
            or not isinstance(config.score_max_length, int)
            or not 2 <= config.score_max_length <= config.max_position_embeddings):
        raise ValueError("score_max_length must be an integer within the backbone context window")
    config.score_model_version = version
    config.score_num_dimensions = dimensions
    config.score_values = values
    config.score_num_classes = num_classes
    # D independent score distributions, each ordered by score_values.
    config.num_labels = dimensions * num_classes


def per_dimension_score_loss(
    logits: torch.Tensor,
    labels: torch.Tensor,
    *,
    boundary_weight: float = 0.0,
    ordinal_weight: float = 0.0,
    score_values: Optional[list[int]] = None,
) -> torch.Tensor:
    """Return [batch, D] exact-label CE plus optional auxiliary losses.

    Legacy boundary groups use class indices (0,1), (2), (3,4) only for 1..5.
    New score scales require boundary_weight=0. There is no additional head
    and inference always uses the complete categorical argmax.
    Log-sum-exp avoids underflow for confident mixed-precision predictions.
    Within-group mistakes still pay the complete exact-label CE penalty.
    """
    float_logits = logits.float()
    num_classes = logits.shape[-1]
    if score_values is not None and len(validate_score_values(score_values)) != num_classes:
        raise ValueError("score_values must match the logits class axis")
    if boundary_weight and (num_classes != len(LEGACY_SCORE_VALUES)
                            or score_values is not None and list(score_values) != list(LEGACY_SCORE_VALUES)):
        raise ValueError("boundary_weight is only defined for the legacy score scale 1..5")
    per_dimension = F.cross_entropy(
        float_logits.reshape(-1, num_classes), labels.reshape(-1), reduction="none"
    ).reshape(labels.shape)
    if boundary_weight:
        log_probs = float_logits.log_softmax(-1)
        group_log_probs = torch.stack((
            log_probs[..., :2].logsumexp(-1),
            log_probs[..., 2],
            log_probs[..., 3:].logsumexp(-1),
        ), dim=-1)
        group_labels = (labels >= 2).long() + (labels >= 3).long()
        boundary = F.nll_loss(
            group_log_probs.reshape(-1, 3), group_labels.reshape(-1), reduction="none"
        ).reshape(labels.shape)
        per_dimension = per_dimension + boundary_weight * boundary
    if ordinal_weight:
        predicted_cdf = float_logits.softmax(-1).cumsum(-1)[..., :-1]
        true_cdf = F.one_hot(labels, num_classes).float().cumsum(-1)[..., :-1]
        per_dimension = per_dimension + ordinal_weight * (predicted_cdf - true_cdf).square().mean(-1)
    return per_dimension


class ModernBertForFiveScores(ModernBertPreTrainedModel):
    """Shared ModernBERT + Linear(hidden, D*K); logits have shape [batch, D, K].

    The original class name remains import-compatible with five-dimensional
    version-1 projects. New projects can use ``ModernBertForMultiScores``.
    """

    config_class = ModernBertConfig
    # Our loss is a mean over samples and dimensions. Trainer must perform its
    # normal gradient-accumulation scaling, not assume we consume item counts.
    accepts_loss_kwargs = False

    def __init__(self, config: ModernBertConfig):
        validate_score_config(config)
        super().__init__(config)
        self.num_dimensions = config.score_num_dimensions
        self.num_classes = config.score_num_classes
        self.score_values = list(config.score_values)
        self.model = ModernBertModel(config)
        self.dropout = nn.Dropout(config.score_dropout)
        self.classifier = nn.Linear(config.hidden_size, self.num_dimensions * self.num_classes)
        self.register_buffer(
            "dimension_weights",
            torch.tensor(config.score_dim_weights, dtype=torch.float32),
            persistent=False,
        )
        self.register_buffer(
            "class_weights", torch.tensor(config.score_class_weights, dtype=torch.float32),
            persistent=False,
        )
        self.post_init()

    def _init_weights(self, module):
        super()._init_weights(module)
        # ModernBERT 4.57 initializes classifier weights only for its built-in
        # task classes. Explicitly initialize our new head as well, including
        # from_pretrained's missing-parameter/meta-device initialization path.
        if module is getattr(self, "classifier", None):
            std = self.config.initializer_range
            cutoff = getattr(self.config, "initializer_cutoff_factor", 2.0)
            nn.init.trunc_normal_(module.weight, mean=0.0, std=std, a=-cutoff * std, b=cutoff * std)
            if module.bias is not None:
                nn.init.zeros_(module.bias)

    def get_input_embeddings(self):
        return self.model.get_input_embeddings()

    def set_input_embeddings(self, value):
        self.model.set_input_embeddings(value)

    def forward(
        self,
        input_ids: Optional[torch.Tensor] = None,
        attention_mask: Optional[torch.Tensor] = None,
        labels: Optional[torch.Tensor] = None,
        position_ids: Optional[torch.Tensor] = None,
        output_attentions: Optional[bool] = None,
        output_hidden_states: Optional[bool] = None,
        return_dict: Optional[bool] = None,
    ):
        return_dict = self.config.use_return_dict if return_dict is None else return_dict
        if input_ids is None or input_ids.ndim != 2:
            raise ValueError("input_ids must have shape [batch, sequence_length]")
        if attention_mask is None:
            attention_mask = input_ids.ne(self.config.pad_token_id).long()
        if attention_mask.shape != input_ids.shape:
            raise ValueError("attention_mask must match input_ids")

        output = self.model(
            input_ids=input_ids,
            attention_mask=attention_mask,
            position_ids=position_ids,
            output_attentions=output_attentions,
            output_hidden_states=output_hidden_states,
            return_dict=True,
        )
        hidden = output.last_hidden_state
        if self.config.score_pooling == "cls":
            # All supplied tokenizers/collators use right padding.
            pooled = hidden[:, 0]
        else:
            mask = attention_mask.unsqueeze(-1).to(torch.float32)
            # Accumulate in FP32 even under BF16/FP16 autocast.
            pooled = (hidden.float() * mask).sum(1) / mask.sum(1).clamp_min(1)
            pooled = pooled.to(hidden.dtype)

        logits = self.classifier(self.dropout(pooled)).reshape(
            input_ids.shape[0], self.num_dimensions, self.num_classes
        )
        loss = None
        if labels is not None:
            if labels.shape != logits.shape[:2]:
                raise ValueError(f"labels must have shape [batch, {self.num_dimensions}]")
            if labels.dtype != torch.long:
                raise ValueError(f"labels must be torch.int64 class indices in [0, {self.num_classes - 1}]")
            # The CPU data pipeline validates every target. Avoid GPU .item()
            # synchronizations on the hot path; CE also checks index validity.
            if labels.device.type == "cpu" and ((labels < 0).any() or (labels >= self.num_classes).any()):
                raise ValueError(f"labels must contain class indices in [0, {self.num_classes - 1}]")
            per_dimension = per_dimension_score_loss(
                logits, labels,
                boundary_weight=self.config.score_boundary_weight,
                ordinal_weight=self.config.score_ordinal_weight,
                score_values=self.score_values,
            )
            # Per-dimension class weights are normalized against training
            # frequencies when created, not against the current mini-batch.
            selected_class_weights = self.class_weights.float().unsqueeze(0).expand(
                labels.shape[0], -1, -1
            ).gather(-1, labels.unsqueeze(-1)).squeeze(-1)
            per_dimension = per_dimension * selected_class_weights
            weights = self.dimension_weights.float()
            loss = (per_dimension * weights).sum(-1).div(weights.sum()).mean()

        if not return_dict:
            result = (logits,)
            if output_hidden_states:
                result += (output.hidden_states,)
            if output_attentions:
                result += (output.attentions,)
            return ((loss,) + result) if loss is not None else result
        return SequenceClassifierOutput(
            loss=loss,
            logits=logits,
            hidden_states=output.hidden_states,
            attentions=output.attentions,
        )


# Keep the checkpoint architecture/class import stable while exposing a name
# that makes the configurable number of dimensions explicit.
ModernBertForMultiScores = ModernBertForFiveScores
