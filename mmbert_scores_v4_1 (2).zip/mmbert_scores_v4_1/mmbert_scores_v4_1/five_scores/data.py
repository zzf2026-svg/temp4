"""Strict input validation and memory-mapped datasets for configurable scoring.

On disk scores use the configured score values. Model labels are class indices.
Large inputs should use JSONL, CSV, or Parquet; a JSON array is read into memory.
"""

from __future__ import annotations

import csv
import hashlib
import json
import numbers
from pathlib import Path
import sys
import unicodedata
from typing import TYPE_CHECKING, Any, Iterator, Mapping, Sequence

from .schema import (
    DEFAULT_DIMENSION_NAMES, LEGACY_SCORE_VALUES,
    validate_dimension_names, validate_num_dimensions, validate_score_values,
)

if TYPE_CHECKING:
    from datasets import Dataset

DEFAULT_NUM_DIMENSIONS = len(DEFAULT_DIMENSION_NAMES)


def resolve_dimension_schema(
    *, num_dimensions: int | None = None, dimension_names: Sequence[str] | None = None
) -> tuple[int, list[str] | None]:
    """Resolve the default seven dimensions or explicitly supplied count/names.

    Names, when supplied, define both the count and the semantic label order.
    Supplying a separate count is optional; if present it must agree.
    """
    names = validate_dimension_names(dimension_names) if dimension_names is not None else None
    count = (
        validate_num_dimensions(num_dimensions)
        if num_dimensions is not None
        else len(names) if names is not None else DEFAULT_NUM_DIMENSIONS
    )
    if names is not None and len(names) != count:
        raise ValueError(f"num_dimensions={count} does not match {len(names)} dimension_names")
    return count, names


def normalized_text(text: str) -> str:
    """Conservative duplicate key: NFC, normalized line endings, outer trim.

    Internal whitespace and letter case are preserved. This detects exact
    normalized duplicates, not semantic similarity or paraphrases.
    """
    return unicodedata.normalize("NFC", text.replace("\r\n", "\n").replace("\r", "\n")).strip()


def text_digest(text: str) -> bytes:
    return hashlib.sha256(normalized_text(text).encode("utf-8")).digest()


def parse_scores(
    value: Any, *, num_dimensions: int | None = None,
    score_values: Sequence[int] | None = None, location: str = "row",
) -> list[int]:
    """Parse a D-element label array, including JSON arrays in CSV cells.

    Integer strings are allowed for CSV columns. Booleans, fractional values,
    floating-point labels, missing values, and out-of-range scores are rejected.
    """
    num_dimensions, _ = resolve_dimension_schema(num_dimensions=num_dimensions)
    allowed = validate_score_values(LEGACY_SCORE_VALUES if score_values is None else score_values)
    allowed_strings = {str(score) for score in allowed}
    if isinstance(value, str):
        try:
            value = json.loads(value)
        except json.JSONDecodeError as exc:
            raise ValueError(f"{location}: scores must be a JSON array of {num_dimensions} integers") from exc
    if not isinstance(value, (list, tuple)) or len(value) != num_dimensions:
        raise ValueError(f"{location}: expected exactly {num_dimensions} scores, each an integer in {allowed}")
    parsed: list[int] = []
    for dimension, score in enumerate(value, start=1):
        if isinstance(score, str):
            score = score.strip()
            if score not in allowed_strings:
                raise ValueError(f"{location}, dimension {dimension}: expected an integer in {allowed}")
            score = int(score)
        if isinstance(score, bool) or not isinstance(score, numbers.Integral):
            raise ValueError(f"{location}, dimension {dimension}: scores must be integers, not {type(score).__name__}")
        if score not in allowed:
            raise ValueError(f"{location}, dimension {dimension}: score {score} is not one of {allowed}")
        parsed.append(int(score))
    return parsed


def validate_score_columns(score_columns: Sequence[str], num_dimensions: int) -> tuple[str, ...]:
    """Validate scalar-label column names without silently rewriting headers."""
    num_dimensions = validate_num_dimensions(num_dimensions)
    if (
        not isinstance(score_columns, (list, tuple))
        or len(score_columns) != num_dimensions
        or any(not isinstance(column, str) or not column.strip() for column in score_columns)
        or len(set(score_columns)) != num_dimensions
    ):
        raise ValueError(f"score_columns must contain {num_dimensions} distinct, nonempty column names")
    return tuple(score_columns)


def canonical_record(
    row: Mapping[str, Any],
    *,
    text_column: str = "text",
    scores_column: str = "scores",
    score_columns: Sequence[str] | None = None,
    num_dimensions: int | None = None,
    dimension_names: Sequence[str] | None = None,
    score_values: Sequence[int] | None = None,
    location: str = "row",
) -> dict[str, Any]:
    """Extract and validate text and labels without changing the original text."""
    num_dimensions, names = resolve_dimension_schema(num_dimensions=num_dimensions, dimension_names=dimension_names)
    allowed = validate_score_values(LEGACY_SCORE_VALUES if score_values is None else score_values)
    if not isinstance(row, Mapping):
        raise ValueError(f"{location}: expected an object/record")
    if "score_values" in row:
        declared_scores = validate_score_values(row["score_values"])
        if declared_scores != allowed:
            raise ValueError(f"{location}: declared score_values {declared_scores} do not match expected {allowed}")
    if "dimension_names" in row:
        try:
            declared_names = validate_dimension_names(row["dimension_names"])
        except ValueError as exc:
            raise ValueError(f"{location}: invalid declared dimension_names: {exc}") from exc
        if len(declared_names) != num_dimensions:
            raise ValueError(f"{location}: declared dimension_names must contain {num_dimensions} names")
        if names is not None and declared_names != names:
            raise ValueError(
                f"{location}: declared dimension_names/order {declared_names} do not match expected {names}; "
                "reconvert the source with the intended dimension order instead of relabeling arrays"
            )
    text = row.get(text_column)
    if not isinstance(text, str) or not text.strip():
        raise ValueError(f"{location}: '{text_column}' must be a nonempty string")
    if score_columns is not None:
        score_columns = validate_score_columns(score_columns, num_dimensions)
        absent = [column for column in score_columns if column not in row]
        if absent:
            raise ValueError(f"{location}: missing score columns {absent}")
        raw_scores = [row[column] for column in score_columns]
    else:
        if scores_column not in row:
            raise ValueError(f"{location}: missing scores column '{scores_column}'")
        raw_scores = row[scores_column]
    return {"text": text, "scores": parse_scores(raw_scores, num_dimensions=num_dimensions, score_values=allowed, location=location)}


def is_failed_teacher_scores(scores: Sequence[int]) -> bool:
    """Identify the project's failed-teacher sentinel after label validation.

    Every configured dimension must be 3. A legitimate row with one or several
    3 scores is retained. This predicate applies only to teacher labels, never
    to model predictions or unlabeled inference inputs.
    """
    return bool(len(scores)) and all(score == 3 for score in scores)


def _filter_report(source: Path, exclude_all_three: bool) -> dict[str, Any]:
    if not isinstance(exclude_all_three, bool):
        raise ValueError("exclude_all_three must be a boolean")
    return {
        "source": str(source), "exclude_all_three": exclude_all_three,
        "input_rows": 0, "excluded_all_three": 0, "retained_rows": 0,
    }


def _report_filter_counts(report: Mapping[str, Any]) -> None:
    print(
        f"Labels {report['source']}: input_rows={report['input_rows']}, "
        f"excluded_all_three={report['excluded_all_three']}, retained_rows={report['retained_rows']}",
        file=sys.stderr,
    )


def iter_labeled_records(
    path: str | Path,
    *,
    text_column: str = "text",
    scores_column: str = "scores",
    score_columns: Sequence[str] | None = None,
    num_dimensions: int | None = None,
    dimension_names: Sequence[str] | None = None,
    score_values: Sequence[int] | None = None,
    exclude_all_three: bool = True,
    filter_report: dict[str, Any] | None = None,
) -> Iterator[tuple[int, dict[str, Any], dict[str, Any]]]:
    """Yield source row number, unchanged source record, and canonical labels.

    This is the labeled evaluation/reporting path: filtering and score order
    match training while source IDs and other columns remain available. The
    optional report is updated during iteration and final after exhaustion.
    No valid rows is an error, including an input consisting only of failures.
    """
    source = Path(path).expanduser().resolve()
    num_dimensions, names = resolve_dimension_schema(num_dimensions=num_dimensions, dimension_names=dimension_names)
    allowed = validate_score_values(LEGACY_SCORE_VALUES if score_values is None else score_values)
    if score_columns is not None:
        score_columns = validate_score_columns(score_columns, num_dimensions)
    report = _filter_report(source, exclude_all_three)
    if filter_report is not None:
        filter_report.clear()
        filter_report.update(report)
        report = filter_report
    for row_number, raw in iter_source_records(source):
        canonical = canonical_record(
            raw, text_column=text_column, scores_column=scores_column, score_columns=score_columns,
            num_dimensions=num_dimensions, dimension_names=names,
            score_values=allowed,
            location=f"{source.name}: record/line {row_number}",
        )
        report["input_rows"] += 1
        if exclude_all_three and 3 in allowed and is_failed_teacher_scores(canonical["scores"]):
            report["excluded_all_three"] += 1
            continue
        report["retained_rows"] += 1
        yield row_number, raw, canonical
    _report_filter_counts(report)
    if report["retained_rows"] == 0:
        raise ValueError(f"{source.name}: no valid labeled rows remain (excluded_all_three={report['excluded_all_three']})")


def iter_source_records(path: str | Path) -> Iterator[tuple[int, dict[str, Any]]]:
    """Yield (one-based record or line number, record) with bounded working RAM.

    JSONL is streamed line by line, CSV row by row, and Parquet in Arrow batches.
    JSON (.json) expects a top-level array and is the only non-streaming format.
    Blank JSONL lines are ignored; malformed records are never silently skipped.
    """
    source = Path(path).expanduser().resolve()
    if not source.is_file():
        raise FileNotFoundError(f"Input file does not exist: {source}")
    suffix = source.suffix.lower()
    if suffix in {".jsonl", ".ndjson"}:
        with source.open("r", encoding="utf-8-sig") as handle:
            for line_number, line in enumerate(handle, start=1):
                if not line.strip():
                    continue
                try:
                    row = json.loads(line)
                except json.JSONDecodeError as exc:
                    raise ValueError(f"{source.name}: line {line_number}: invalid JSON ({exc.msg})") from exc
                if not isinstance(row, dict):
                    raise ValueError(f"{source.name}: line {line_number}: expected a JSON object")
                yield line_number, row
    elif suffix == ".json":
        with source.open("r", encoding="utf-8-sig") as handle:
            rows = json.load(handle)
        if not isinstance(rows, list):
            raise ValueError(f"{source.name}: .json input must contain a top-level array; use JSONL for large files")
        for index, row in enumerate(rows, start=1):
            if not isinstance(row, dict):
                raise ValueError(f"{source.name}: record {index}: expected an object")
            yield index, row
    elif suffix == ".csv":
        # The stdlib default is too small for long text fields.
        csv.field_size_limit(100 * 1024 * 1024)
        with source.open("r", encoding="utf-8-sig", newline="") as handle:
            reader = csv.DictReader(handle)
            fields = reader.fieldnames
            if not fields or len(fields) != len(set(fields)):
                raise ValueError(f"{source.name}: CSV needs nonempty, unique column headers")
            for row_number, row in enumerate(reader, start=1):
                if None in row:
                    raise ValueError(f"{source.name}: record {row_number}: more cells than CSV headers")
                yield row_number, dict(row)
    elif suffix == ".parquet":
        try:
            import pyarrow.parquet as pq
        except ImportError as exc:
            raise ImportError("Parquet requires pyarrow, which is installed with datasets") from exc
        row_number = 0
        parquet_file = pq.ParquetFile(source)
        try:
            for batch in parquet_file.iter_batches(batch_size=4096):
                for row in batch.to_pylist():
                    row_number += 1
                    yield row_number, row
        finally:
            parquet_file.close()
    else:
        raise ValueError(f"Unsupported extension '{suffix}'; use .jsonl, .json, .csv, or .parquet")


def _canonical_file_generator(
    paths: list[str],
    text_column: str,
    scores_column: str,
    score_columns: tuple[str, ...] | None,
    num_dimensions: int,
    dimension_names: tuple[str, ...] | None,
    source_signature: tuple[int, int],
    score_values: tuple[int, ...] = LEGACY_SCORE_VALUES,
) -> Iterator[dict[str, Any]]:
    # Included in the HF fingerprint so replacing a file at the same path does
    # not silently reuse its former cached data.
    del source_signature
    for path in paths:
        for row_number, row in iter_source_records(path):
            yield canonical_record(
                row,
                text_column=text_column,
                scores_column=scores_column,
                score_columns=score_columns,
                num_dimensions=num_dimensions,
                dimension_names=dimension_names,
                score_values=score_values,
                location=f"{Path(path).name}: record/line {row_number}",
            )


def load_labeled_dataset(
    path: str | Path,
    text_column: str = "text",
    scores_column: str = "scores",
    score_columns: Sequence[str] | None = None,
    num_proc: int | None = None,
    *,
    num_dimensions: int | None = None,
    dimension_names: Sequence[str] | None = None,
    score_values: Sequence[int] | None = None,
    exclude_all_three: bool = True,
    filter_report: dict[str, Any] | None = None,
) -> "Dataset":
    """Validate an input file and build a disk-backed Arrow Dataset.

    Returns canonical ``text`` and ``scores`` columns only. All D disk scores
    keep their configured numeric values. Metadata is not fed to the model. ``num_proc`` is accepted
    for API consistency; a single source file is read by a single generator.
    Tokenization can use multiple processes in ``get_tokenized_dataset``.
    Failed all-3 teacher labels are excluded by default, with explicit counts.
    The optional ``filter_report`` dict receives those counts even on a cached
    dataset load. Individual 3 labels in otherwise valid rows are retained.
    """
    num_dimensions, names = resolve_dimension_schema(num_dimensions=num_dimensions, dimension_names=dimension_names)
    allowed = validate_score_values(LEGACY_SCORE_VALUES if score_values is None else score_values)
    if num_proc is not None and num_proc < 1:
        raise ValueError("num_proc must be a positive integer")
    if score_columns is not None:
        score_columns = validate_score_columns(score_columns, num_dimensions)
    source = Path(path).expanduser().resolve()
    report = _filter_report(source, exclude_all_three)
    if not source.is_file():
        raise FileNotFoundError(f"Input file does not exist: {source}")
    stat = source.stat()
    from datasets import Dataset, Features, Sequence as HFSequence, Value

    features = Features({"text": Value("string"), "scores": HFSequence(Value("int64"), length=num_dimensions)})
    dataset = Dataset.from_generator(
        _canonical_file_generator,
        features=features,
        gen_kwargs={
            "paths": [str(source)],
            "text_column": text_column,
            "scores_column": scores_column,
            "score_columns": tuple(score_columns) if score_columns is not None else None,
            "num_dimensions": num_dimensions,
            "dimension_names": tuple(names) if names is not None else None,
            "score_values": tuple(allowed),
            "source_signature": (stat.st_size, stat.st_mtime_ns),
        },
        num_proc=1,
    )
    report["input_rows"] = len(dataset)
    if exclude_all_three and 3 in allowed and len(dataset):
        dataset = dataset.filter(
            _keep_valid_teacher_batch, input_columns=["scores"], batched=True,
            desc="Exclude failed all-3 teacher labels",
        )
    report["retained_rows"] = len(dataset)
    report["excluded_all_three"] = report["input_rows"] - len(dataset)
    if filter_report is not None:
        filter_report.clear()
        filter_report.update(report)
    _report_filter_counts(report)
    if not len(dataset):
        raise ValueError(f"{source.name}: no valid labeled rows remain (excluded_all_three={report['excluded_all_three']})")
    return dataset


def _keep_valid_teacher_batch(scores: list[list[int]]) -> list[bool]:
    return [not is_failed_teacher_scores(row) for row in scores]


def get_tokenized_dataset(
    dataset: "Dataset",
    tokenizer: Any,
    max_length: int,
    num_proc: int | None = None,
    *,
    num_dimensions: int | None = None,
    dimension_names: Sequence[str] | None = None,
    score_values: Sequence[int] | None = None,
) -> "Dataset":
    """Validate, tokenize, and map configured scores to class indices 0..K-1.

    ``length`` supports length grouping and must be removed by the collator.
    Raw text is removed from the tokenized dataset to reduce resident metadata.
    """
    num_dimensions, names = resolve_dimension_schema(num_dimensions=num_dimensions, dimension_names=dimension_names)
    allowed = validate_score_values(LEGACY_SCORE_VALUES if score_values is None else score_values)
    score_to_index = {score: index for index, score in enumerate(allowed)}
    if max_length < 2:
        raise ValueError("max_length must be at least 2")
    if num_proc is not None and num_proc < 1:
        raise ValueError("num_proc must be a positive integer")
    if not {"text", "scores"}.issubset(dataset.column_names):
        raise ValueError("Expected a canonical dataset with text and scores columns")
    if len(dataset) == 0:
        raise ValueError("Cannot tokenize an empty dataset")

    def tokenize(batch: dict[str, list[Any]], indices: list[int]) -> dict[str, Any]:
        labels: list[list[int]] = []
        for offset, row_index in enumerate(indices):
            raw_row = {"text": batch["text"][offset], "scores": batch["scores"][offset]}
            if "dimension_names" in batch:
                raw_row["dimension_names"] = batch["dimension_names"][offset]
            if "score_values" in batch:
                raw_row["score_values"] = batch["score_values"][offset]
            row = canonical_record(
                raw_row,
                num_dimensions=num_dimensions,
                dimension_names=names,
                score_values=allowed,
                location=f"dataset row {row_index} (zero-based)",
            )
            labels.append([score_to_index[score] for score in row["scores"]])
        encoded = tokenizer(
            batch["text"],
            truncation=True,
            max_length=max_length,
            padding=False,
            return_attention_mask=True,
        )
        input_ids = encoded["input_ids"]
        return {
            "input_ids": input_ids,
            "attention_mask": encoded.get("attention_mask", [[1] * len(ids) for ids in input_ids]),
            "labels": labels,
            "length": [len(ids) for ids in input_ids],
        }

    return dataset.map(
        tokenize,
        batched=True,
        batch_size=1000,
        with_indices=True,
        num_proc=num_proc if num_proc is not None and num_proc > 1 else None,
        remove_columns=dataset.column_names,
        desc=f"Tokenizing (max_length={max_length})",
    )
