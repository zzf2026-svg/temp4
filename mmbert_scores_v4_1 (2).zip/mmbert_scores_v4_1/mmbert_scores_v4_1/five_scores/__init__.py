"""One mmBERT encoder with configurable dimensions and discrete score values."""

__version__ = "4.1.0"
