"""Small, strict YAML/JSON configuration loader (paths are relative to the CWD)."""

from __future__ import annotations

from copy import deepcopy
import json
import math
from pathlib import Path

import yaml

from five_scores.schema import (
    DEFAULT_DIMENSION_NAMES, DEFAULT_SCORE_VALUES, LEGACY_SCORE_VALUES, NEW_DIMENSION_NAMES,
    validate_dimension_names, validate_num_dimensions, validate_score_values,
)


DEFAULTS = {
    "model": {
        "name_or_path": "jhu-clsp/mmBERT-small",
        "revision": "main",
        "dimension_names": list(NEW_DIMENSION_NAMES),
        "score_values": list(DEFAULT_SCORE_VALUES),
        "num_dimensions": None,
        "pooling": "mean",
        "dropout": 0.1,
        "dimension_weights": None,
        "boundary_weight": 0.0,
        "ordinal_weight": 0.0,
        "class_weight_mode": "none",
        "class_weights": None,
        "attn_implementation": "sdpa",
    },
    "data": {
        "train_file": "data/train.jsonl",
        "validation_file": "data/validation.jsonl",
        "replay_file": None,
        "text_column": "text",
        "scores_column": "scores",
        "score_columns": None,
        "text_template_file": None,
        "max_length": 512,
        "num_proc": 4,
        "max_train_samples": None,
        "max_eval_samples": None,
        "exclude_all_three": False,
        "validation_ratio": 0.05,
        "test_ratio": 0.05,
    },
    "conversion": {
        "sheet_name": "Sheet1",
        "header_row": 1,
        "csv_encoding": "utf-8-sig",
        "csv_delimiter": ",",
        "text_columns": ["scene_description", "pain_analysis", "solution"],
        "text_labels": {
            "scene_description": "场景描述", "pain_analysis": "痛点分析", "solution": "解决方案",
        },
        "required_text_columns": ["scene_description", "pain_analysis", "solution"],
        "score_columns": None,
        "id_column": "row_id",
        "group_column": None,
        "status_column": None,
        "accepted_statuses": [],
        "exclude_all_three": False,
        "metadata_columns": [],
        "header_overrides": {4: {"expected": "novelty_score", "name": "solution"}},
    },
    "training": {
        "output_dir": "outputs/mmbert-scores-v4",
        "seed": 42,
        "num_train_epochs": 2.0,
        "max_steps": -1,
        "per_device_train_batch_size": 16,
        "per_device_eval_batch_size": 32,
        "gradient_accumulation_steps": 4,
        "learning_rate": 2e-5,
        "head_learning_rate": 1e-4,
        "weight_decay": 0.01,
        "warmup_ratio": 0.03,
        "lr_scheduler_type": "cosine",
        "precision": "auto",
        "use_cpu": False,
        "gradient_checkpointing": False,
        "eval_strategy": "epoch",
        "eval_steps": 1000,
        "save_steps": 1000,
        "logging_steps": 50,
        "save_total_limit": 2,
        "early_stopping_patience": 3,
        "metric_for_best_model": "all_dimensions_accuracy",
        "greater_is_better": None,
        "dataloader_num_workers": 4,
        "group_by_length": True,
        "max_grad_norm": 1.0,
        "tf32": True,
        "torch_compile": False,
        "resume_from_checkpoint": None,
        "stage": "standard",
        "freeze_backbone": False,
        "replay_weight": 0.0,
    },
}


def validate_config(config: dict) -> dict:
    """Resolve the shared schema and reject inconsistent inexpensive options."""
    model, data, training = (config[section] for section in ("model", "data", "training"))
    names = validate_dimension_names(model["dimension_names"])
    count = len(names)
    declared = model.get("num_dimensions")
    if declared is not None and validate_num_dimensions(declared) != count:
        raise ValueError("model.num_dimensions must match len(model.dimension_names)")
    model["dimension_names"] = names
    model["num_dimensions"] = count
    values = validate_score_values(model["score_values"])
    model["score_values"] = values
    num_classes = len(values)
    weights = model.get("dimension_weights")
    if weights is None:
        weights = [1.0] * count
    if not isinstance(weights, (list, tuple)) or len(weights) != count:
        raise ValueError("model.dimension_weights must be null or contain one weight per dimension")
    if any(isinstance(weight, bool) or not isinstance(weight, (int, float))
           or not math.isfinite(weight) or weight <= 0 for weight in weights):
        raise ValueError("model.dimension_weights must contain finite positive numbers")
    model["dimension_weights"] = [float(weight) for weight in weights]
    for key in ("boundary_weight", "ordinal_weight"):
        value = model[key]
        if (isinstance(value, bool) or not isinstance(value, (int, float))
                or not math.isfinite(value) or value < 0):
            raise ValueError(f"model.{key} must be finite and non-negative")
        model[key] = float(value)
    if model["boundary_weight"] and values != list(LEGACY_SCORE_VALUES):
        raise ValueError("model.boundary_weight is only defined for legacy scores [1, 2, 3, 4, 5]; "
                         "set it to 0 for the new score scale. No business boundary groups were supplied.")
    mode = model["class_weight_mode"]
    if mode not in {"none", "sqrt_inverse", "manual"}:
        raise ValueError("model.class_weight_mode must be none, sqrt_inverse or manual")
    class_weights = model["class_weights"]
    if mode == "manual":
        if (not isinstance(class_weights, (list, tuple)) or len(class_weights) != count
                or any(not isinstance(row, (list, tuple)) or len(row) != num_classes for row in class_weights)):
            raise ValueError(f"Manual model.class_weights must have shape [num_dimensions, {num_classes}]")
        if any(isinstance(weight, bool) or not isinstance(weight, (int, float))
               or not math.isfinite(weight) or weight <= 0
               for row in class_weights for weight in row):
            raise ValueError("model.class_weights must contain finite positive numbers")
        model["class_weights"] = [[float(weight) for weight in row] for row in class_weights]
    elif class_weights is not None:
        raise ValueError("Set model.class_weight_mode=manual when supplying model.class_weights")
    for section in ("data", "conversion"):
        if not isinstance(config[section]["exclude_all_three"], bool):
            raise ValueError(f"{section}.exclude_all_three must be true or false")
    columns = data.get("score_columns")
    if columns is not None and len(validate_dimension_names(columns)) != count:
        raise ValueError("data.score_columns must match the configured dimension count")
    for key in ("max_train_samples", "max_eval_samples"):
        value = data[key]
        if value is not None and (isinstance(value, bool) or not isinstance(value, int) or value < 1):
            raise ValueError(f"data.{key} must be a positive integer or null (all available rows)")
    ratios = [data["validation_ratio"], data["test_ratio"]]
    if any(isinstance(value, bool) or not isinstance(value, (int, float))
           or not math.isfinite(value) or not 0 <= value < 1 for value in ratios) or sum(ratios) >= 1:
        raise ValueError("data.validation_ratio/test_ratio must be in [0,1), with sum below 1")
    if training["eval_strategy"] not in {"epoch", "steps"}:
        raise ValueError("training.eval_strategy must be 'epoch' or 'steps'")
    if training["eval_strategy"] == "steps" and training["save_steps"] != training["eval_steps"]:
        raise ValueError("For steps evaluation, save_steps must equal eval_steps so every candidate best model is saved")
    if isinstance(training["seed"], bool) or not isinstance(training["seed"], int) or training["seed"] < 0:
        raise ValueError("training.seed must be a non-negative integer")
    metric = training["metric_for_best_model"]
    if not isinstance(metric, str) or not metric.strip() or metric != metric.strip():
        raise ValueError("training.metric_for_best_model must be a nonempty metric name without surrounding whitespace")
    if training["greater_is_better"] is not None and not isinstance(training["greater_is_better"], bool):
        raise ValueError("training.greater_is_better must be true, false or null (infer direction)")
    if training["stage"] not in {"standard", "pseudo", "expert"}:
        raise ValueError("training.stage must be standard, pseudo or expert")
    if not isinstance(training["freeze_backbone"], bool):
        raise ValueError("training.freeze_backbone must be true or false")
    replay_weight = training["replay_weight"]
    if (isinstance(replay_weight, bool) or not isinstance(replay_weight, (int, float))
            or not math.isfinite(replay_weight) or replay_weight < 0):
        raise ValueError("training.replay_weight must be finite and non-negative")
    training["replay_weight"] = float(replay_weight)
    replay_file = data["replay_file"]
    if replay_file is not None and (not isinstance(replay_file, str) or not replay_file.strip()):
        raise ValueError("data.replay_file must be a nonempty JSONL path or null")
    if replay_weight > 0 and not replay_file:
        raise ValueError("A positive training.replay_weight requires data.replay_file")
    return config


def load_config(path: str | Path) -> dict:
    path = Path(path)
    with path.open(encoding="utf-8") as handle:
        # JSON's 2e-05 notation is a number, but PyYAML's YAML 1.1 resolver
        # can turn it into a string. Resolved Trainer configs are JSON files.
        supplied = (json.load(handle) if path.suffix.lower() == ".json" else yaml.safe_load(handle)) or {}
    if not isinstance(supplied, dict):
        raise ValueError("Configuration root must be a mapping")
    result = deepcopy(DEFAULTS)
    # An explicit old dimension schema without a scale is a legacy config.
    # New configurations always write score_values, preventing ambiguous reuse.
    supplied_model = supplied.get("model", {})
    legacy = isinstance(supplied_model, dict) and (
        supplied_model.get("score_values") == list(LEGACY_SCORE_VALUES)
        or "score_values" not in supplied_model and "dimension_names" in supplied_model
        and supplied_model["dimension_names"] != list(NEW_DIMENSION_NAMES)
    )
    if legacy:
        # Keep unmarked old schemas on their original data/template defaults.
        # In particular, never attach the new workbook's physical D-column
        # override to a legacy/custom CSV conversion.
        from five_scores.excel import DEFAULT_CONVERSION

        result["model"]["score_values"] = list(LEGACY_SCORE_VALUES)
        result["model"]["dimension_names"] = list(DEFAULT_DIMENSION_NAMES)
        result["model"]["boundary_weight"] = 0.2
        result["data"]["exclude_all_three"] = True
        result["conversion"] = deepcopy(DEFAULT_CONVERSION)
    for section, values in supplied.items():
        if section not in result:
            raise ValueError(f"Unknown config section: {section}")
        if not isinstance(values, dict):
            raise ValueError(f"Config section {section} must be a mapping")
        extra = set(values) - set(result[section])
        if extra:
            raise ValueError(f"Unknown {section} options: {sorted(extra)}")
        result[section].update(values)
    return validate_config(result)
