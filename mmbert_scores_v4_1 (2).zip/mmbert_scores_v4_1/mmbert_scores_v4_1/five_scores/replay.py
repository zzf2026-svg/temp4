"""Source-separated replay, data separation checks, and training provenance.

Replay sampling deliberately happens in Trainer.compute_loss, in the training
process, rather than a dataset worker or collator. PyTorch's CPU RNG is already
saved/restored in Trainer checkpoints; there is no second hidden random state.
"""

from __future__ import annotations

from datetime import datetime, timezone
import hashlib
from pathlib import Path
import uuid

from .data import iter_labeled_records, text_digest


def file_fingerprint(path):
    source = Path(path).expanduser().resolve()
    if not source.is_file():
        raise FileNotFoundError(f"Input file does not exist: {source}")
    before = source.stat()
    digest = hashlib.sha256()
    with source.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    after = source.stat()
    if (before.st_size, before.st_mtime_ns) != (after.st_size, after.st_mtime_ns):
        raise ValueError(f"File changed while calculating its fingerprint: {source}")
    return {"path": str(source), "sha256": digest.hexdigest(), "size_bytes": after.st_size}


def checkpoint_identity(source, revision=None, resolved_revision=None):
    """Hash the *source*, before new-run metadata is written to its config."""
    path = Path(source).expanduser()
    identity = {
        "name_or_path": str(path.resolve()) if path.exists() else str(source),
        "requested_revision": revision,
        "resolved_revision": resolved_revision,
    }
    if path.is_dir():
        filenames = {"config.json", "model.safetensors.index.json", "pytorch_model.bin.index.json",
                     "tokenizer.json", "tokenizer_config.json", "special_tokens_map.json",
                     "vocab.txt", "vocab.json", "merges.txt", "tokenizer.model"}
        files = sorted({item for item in path.iterdir() if item.is_file() and (
            item.name in filenames or item.name.endswith(".safetensors")
            or (item.name.startswith("pytorch_model") and item.name.endswith(".bin"))
        )})
        identity["files"] = {
            item.name: {key: value for key, value in file_fingerprint(item).items() if key != "path"}
            for item in files
        }
    return identity


def _group_keys(record, location):
    """Canonical inputs use top-level group_id; also honor metadata.group_id."""
    values = []
    if "group_id" in record:
        values.append(record["group_id"])
    metadata = record.get("metadata")
    if isinstance(metadata, dict) and "group_id" in metadata:
        values.append(metadata["group_id"])
    keys = set()
    for value in values:
        if isinstance(value, bool) or not isinstance(value, (str, int)) or (isinstance(value, str) and not value.strip()):
            raise ValueError(f"{location}: group_id must be a nonempty string or integer")
        # Match the alignment preparer's cross-file identity policy.
        keys.add(str(value).strip())
    return keys


def validate_alignment_separation(data_options, model_options):
    """Check whole source files, before caps/filtering, for exact/group leakage.

    This does not claim semantic near-duplicate detection. All expert splits,
    including test, are excluded earlier by prepare_alignment_data.py. This
    standalone training guard can only inspect its own train/validation inputs.
    """
    protected_texts, protected_groups = {}, {}
    report = {"policy": "NFC/LF/outer-trim text SHA256 plus canonical group_id", "splits": {}}
    splits = [("train", data_options["train_file"]), ("validation", data_options["validation_file"])]
    if data_options.get("replay_file"):
        splits.append(("replay", data_options["replay_file"]))
    for split, path in splits:
        is_replay = split == "replay"
        if is_replay and Path(path).suffix.lower() not in {".jsonl", ".ndjson"}:
            raise ValueError("data.replay_file must be canonical JSONL with explicit score_values")
        split_texts, split_groups = set(), set()
        rows = 0
        options = ({"text_column": "text", "scores_column": "scores", "score_columns": None}
                   if is_replay else {key: data_options[key] for key in ("text_column", "scores_column", "score_columns")})
        for number, original, canonical in iter_labeled_records(
            path, **options, dimension_names=model_options["dimension_names"],
            score_values=model_options["score_values"], exclude_all_three=False,
        ):
            location = f"{split}: record/line {number}"
            if is_replay and "score_values" not in original:
                raise ValueError(f"{location}: replay rows must declare score_values explicitly")
            digest = text_digest(canonical["text"])
            if digest in protected_texts:
                raise ValueError(f"{location}: normalized text overlap with {protected_texts[digest]}; "
                                 "rebuild disjoint expert/replay splits before training")
            groups = _group_keys(original, location)
            for group in groups:
                if group in protected_groups:
                    raise ValueError(f"{location}: group_id overlap with {protected_groups[group]}; "
                                     "keep all cases of a group in one split")
            split_texts.add(digest)
            split_groups.update(groups)
            rows += 1
        report["splits"][split] = {"rows": rows, "unique_texts": len(split_texts), "groups": len(split_groups)}
        # Only prior splits are protected: repeated groups within a split are valid.
        protected_texts.update(dict.fromkeys(split_texts, split))
        protected_groups.update(dict.fromkeys(split_groups, split))
    return report


def training_contract(config, world_size=1):
    """Values that must stay fixed for a real resume, including input bytes."""
    model, data, training = (config[key] for key in ("model", "data", "training"))
    files = {split: file_fingerprint(data[key]) if data.get(key) else None
             for split, key in (("train", "train_file"), ("validation", "validation_file"), ("replay", "replay_file"))}
    settings = {key: training[key] for key in (
        "seed", "num_train_epochs", "max_steps", "per_device_train_batch_size", "gradient_accumulation_steps",
        "learning_rate", "head_learning_rate", "weight_decay", "warmup_ratio", "lr_scheduler_type",
        "max_grad_norm", "group_by_length", "dataloader_num_workers", "gradient_checkpointing", "precision",
        "use_cpu", "tf32", "torch_compile", "eval_strategy", "eval_steps", "per_device_eval_batch_size",
        "early_stopping_patience",
    )}
    settings["world_size"] = world_size
    settings["data"] = {key: data[key] for key in (
        "text_column", "scores_column", "score_columns", "max_length", "max_train_samples",
        "max_eval_samples", "exclude_all_three",
    )}
    return {
        "training_stage": training["stage"], "freeze_backbone": training["freeze_backbone"],
        "replay_weight": training["replay_weight"], "data_files": files, "resume_settings": settings,
        "schema": {"dimension_names": model["dimension_names"], "score_values": model["score_values"]},
    }


def validate_resume_provenance(saved, requested):
    if not isinstance(saved, dict) or saved.get("version") != 1:
        raise ValueError("This checkpoint has no verifiable training provenance/input SHA256 fingerprints. "
                         "Warm-start with --model CHECKPOINT and a new output directory instead of resuming it.")
    for field in ("training_stage", "freeze_backbone", "replay_weight", "resume_settings", "schema"):
        if saved.get(field) != requested[field]:
            raise ValueError(f"Resume provenance mismatch for {field}; use the original configuration, "
                             "or warm-start with --model CHECKPOINT and a new output directory")
    for split, current in requested["data_files"].items():
        previous = saved.get("data_files", {}).get(split)
        # Moving unchanged data is safe; replacing its bytes is not.
        if ((previous is None) != (current is None)
                or current is not None and (previous.get("sha256"), previous.get("size_bytes")) !=
                (current["sha256"], current["size_bytes"])):
            raise ValueError(f"Resume data fingerprint mismatch for {split}; restore the original file bytes")


def build_training_provenance(config, source, *, revision=None, resolved_revision=None,
                              saved=None, resume=False, world_size=1):
    contract = training_contract(config, world_size)
    if resume:
        validate_resume_provenance(saved, contract)
        return {**saved, "data_files": contract["data_files"]}
    return {
        "version": 1, "run_id": uuid.uuid4().hex,
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        **contract,
        "source_checkpoint": checkpoint_identity(source, revision, resolved_revision),
        "optimizer_initialization": "fresh",
        "replay_sampling": "torch CPU global RNG, uniform with replacement, training process only",
        "primary_sampling_with_replay": "independent seed+epoch generator; persistent workers disabled",
        "replay_loss": "primary batch mean + replay_weight * same-size replay batch mean",
    }


def clear_source_training_metadata(config):
    """Weights transfer across stages, but fitted label frequencies never do."""
    for field in ("score_class_weight_mode", "score_class_weights", "score_class_counts",
                  "score_training_provenance", "score_training_stage", "score_freeze_backbone", "score_replay_weight"):
        if hasattr(config, field):
            delattr(config, field)


def configure_backbone_trainability(model, freeze_backbone):
    if not isinstance(freeze_backbone, bool):
        raise ValueError("freeze_backbone must be true or false")
    model.model.requires_grad_(not freeze_backbone)
    model.classifier.requires_grad_(True)
    model.config.score_freeze_backbone = freeze_backbone


def validate_replay_runtime(args):
    if args.world_size != 1 or args.n_gpu > 1:
        raise ValueError("Pseudo-label replay supports one training process and at most one GPU. "
                         "Use a single visible GPU (or CPU); ordinary training without replay still supports DDP.")
    if getattr(args, "dataloader_num_workers", 0) != 0:
        raise ValueError("Pseudo-label replay requires training.dataloader_num_workers=0 for reproducible checkpoint resume")
    if args.ignore_data_skip or args.save_only_model:
        raise ValueError("Replay resume requires ignore_data_skip=False and save_only_model=False for RNG/optimizer recovery")


def validate_resume_checkpoint(checkpoint, *, world_size=1, fp16=False):
    """HF silently skips missing optimizer/scheduler files; a resume must not."""
    required = ["config.json", "trainer_state.json", "optimizer.pt", "scheduler.pt"]
    required += (["rng_state.pth"] if world_size == 1 else
                 [f"rng_state_{rank}.pth" for rank in range(world_size)])
    if fp16:
        required.append("scaler.pt")
    missing = [name for name in required if not (Path(checkpoint) / name).is_file()]
    if missing:
        raise ValueError(f"Incomplete Trainer checkpoint: missing {', '.join(missing)}. "
                         "Restore the complete checkpoint, or warm-start with --model and a new output directory.")


def sample_replay_features(dataset, batch_size):
    """Draw in the main process using the RNG managed by Trainer checkpoints."""
    import torch

    if len(dataset) == 0 or batch_size <= 0:
        raise ValueError("Replay pool and current training batch must be nonempty")
    indices = torch.randint(len(dataset), (batch_size,), device="cpu").tolist()
    return [dataset[index] for index in indices]


class EpochSeededSampler:
    """Make primary order reproducible when resuming midway through any epoch.

    Transformers' ordinary LengthGroupedSampler otherwise consumes the global
    RNG before checkpoint RNG restoration. That cannot reconstruct a later
    epoch's permutation when training restarts midway through that epoch.
    Accelerate's DataLoaderShard calls set_epoch on this sampler.
    """

    def __init__(self, sampler, seed):
        self.sampler = sampler
        self.seed = seed
        self.epoch = 0

    def set_epoch(self, epoch):
        # Accelerate 1.10 skip_first_batches wraps the loader at iteration=0
        # during a mid-epoch resume. Do not let that wrapper rewind an epoch
        # already assigned by Trainer; a sampler is newly made for each train().
        self.epoch = max(self.epoch, epoch)

    def __len__(self):
        return len(self.sampler)

    def __iter__(self):
        import torch

        self.sampler.generator = torch.Generator().manual_seed(self.seed + self.epoch)
        return iter(self.sampler)
